<?php 
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit();
}
include '../db.php'; 
include 'functions.php'; // Link the new functions file

// Fetch products once for the dropdown options to reuse in JS cloning
$product_options = "";
$prods = $conn->query("SELECT * FROM products WHERE stock > 0 AND is_deleted = 0 ORDER BY name ASC");
while($p = $prods->fetch_assoc()) {
    $product_options .= sprintf(
        '<option value="%s" data-price="%s" data-stock="%s">%s (%s)</option>',
        $p['id'],
        $p['price'],
        $p['stock'],
        htmlspecialchars($p['name']),
        htmlspecialchars($p['item_code'])
    );
}

// --- 1. Logic for Search, Sort, and Pagination ---
$search = isset($_GET['search']) ? $conn->real_escape_string($_GET['search']) : '';
$sort = isset($_GET['sort']) ? $_GET['sort'] : 'date_desc';
$limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 10;
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
if ($page < 1) $page = 1;

$offset = ($page - 1) * $limit;

$sort_options = [
    'date_desc'   => "date_created DESC",
    'date_asc'    => "date_created ASC",
    'amount_high' => "total_amount DESC",
    'amount_low'  => "total_amount ASC",
    'name_asc'    => "customer_name ASC"
];
$sort_sql = $sort_options[$sort] ?? "date_created DESC";

$status_filter = isset($_GET['status']) ? $conn->real_escape_string($_GET['status']) : '';

// Build WHERE clause
$where_clauses = ["(receipt_no LIKE '%$search%' OR customer_name LIKE '%$search%')"];
if ($status_filter) {
    $where_clauses[] = "status = '$status_filter'";
}
$where_sql = "WHERE " . implode(" AND ", $where_clauses);

// Count total records for pagination
$count_query = "SELECT COUNT(*) as total FROM transactions $where_sql";
$total_records = $conn->query($count_query)->fetch_assoc()['total'];
$total_pages = ceil($total_records / $limit);
if ($page > $total_pages && $total_pages > 0) $page = $total_pages;

// Fetch Transaction History
$history_query = "SELECT * FROM transactions $where_sql ORDER BY $sort_sql LIMIT $limit OFFSET $offset";
$history = $conn->query($history_query);

$start_entry = ($total_records > 0) ? $offset + 1 : 0;
$end_entry = min($offset + $limit, $total_records);

// Calculate Total Amount (All-time Completed Transactions)
$total_amt_res = $conn->query("SELECT SUM(total_amount) as total FROM transactions WHERE status = 'completed'");
$total_all_time = $total_amt_res->fetch_assoc()['total'] ?? 0;
?>

<!DOCTYPE html>
<html lang="en">
<head>
        <meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Transaction System</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="style.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

</head>
<body>

<nav class="navbar">
    <a href="#" class="navbar-brand">IMS ADMIN</a>
    <input type="checkbox" id="nav-toggle" class="nav-toggle">
    <label for="nav-toggle" class="nav-toggle-label"><i class="fa-solid fa-bars"></i></label>
    
    <ul class="navbar-links">
        <li><a href="../Dashboard/dashboard.php"><i class="fa-solid fa-gauge-high"></i> Dashboard</a></li>
        <li class="dropdown">
            <a href="javascript:void(0)" class="dropdown-trigger">
                <i class="fa-solid fa-boxes-stacked"></i> Inventory <i class="fa-solid fa-caret-down"></i>
            </a>
            <div class="dropdown-content">
                <a href="../Products/products.php">All Products</a>
                <a href="../Products/logs.php">Logs</a>
                <a href="../Products/trash.php">Trash</a>
            </div>
        </li>
        <li><a href="../Stores/stores.php"><i class="fa-solid fa-store"></i> Stores</a></li>
        <li class="dropdown">
            <a href="javascript:void(0)" class="active">
                <i class="fa-solid fa-exchange-alt"></i> Transaction <i class="fa-solid fa-caret-down"></i>
            </a>
            <div class="dropdown-content">
                <a href="void_logs.php">Void Logs</a>
                <a href="transaction_logs.php">Transaction Logs</a>
                <a href="sales_report.php">Sales Report</a>
            </div>
        </li>
        <li><a href="../Expenses/expenses.php"><i class="fa-solid fa-wallet"></i> Expenses</a></li>
        <li><a href="../logout.php" class="logout-link"><i class="fa-solid fa-right-from-bracket"></i> Logout</a></li>
    </ul>
</nav>

<?php if (isset($_SESSION['alert_message'])): ?>
    <div id="sys-alert" class="alert alert-<?php echo $_SESSION['alert_type']; ?>" 
         style="padding: 15px; margin-bottom: 20px; border-radius: 4px; text-align: center; 
         <?php echo ($_SESSION['alert_type'] === 'error') ? 'background-color: #f8d7da; color: #721c24;' : 'background-color: #d4edda; color: #155724;'; ?>">
        <?php echo $_SESSION['alert_message']; ?>
    </div>
    <?php unset($_SESSION['alert_message']); unset($_SESSION['alert_type']); ?>
<?php endif; ?>

<div class="controls-row">
    <button class="btn-blue" onclick="openModal()">
        <i class="fa fa-plus"></i> New Transaction
    </button>
</div>
<div id="transactionModal" class="modal-overlay">
    <div class="modal-content">
        <div class="modal-header">
            <h3>New Transaction</h3>
            <span class="close-btn" onclick="closeModal()">&times;</span>
        </div>
        
        <form id="transaction-form" action="process_transaction.php" method="POST" onsubmit="return validateOrder()">
            <div class="modal-body" style="padding: 20px; overflow-y: auto; max-height: 70vh;">


                <div id="item-list">
                    <div class="item-row">


                        <div>
                            <label>Product</label>
                            <select name="product_id[]" class="product-select" onchange="updateRow(this)" required>
                                <option value="" disabled selected>Select Product</option>
                                <?= $product_options ?>
                            </select>
                        </div>


                        <div><label>Stock</label><input type="text" class="row-stock" readonly></div>
                        <div><label>Price</label><input type="text" class="row-price" readonly></div>
                        <div><label>Qty</label><input type="number" name="qty[]" class="row-qty" oninput="calculateRow(this)" value="0"></div>
                        <div><label>Total</label><input type="text" class="row-total" value="0.00" readonly></div>
                        <div><button type="button" class="btn-red" onclick="removeRow(this)"><i class="fa fa-trash"></i></button></div>
                    </div>
                </div>

                <button type="button" class="btn-blue" onclick="addItemRow()" style="margin: 15px 0;">
                    <i class="fa fa-plus"></i> Add Item
                </button>

                <div class="summary-grid">
                    <div><label>VAT %</label><input type="number" step="0.01" name="vat" id="vat" value="0" oninput="calculateGrandTotal()"></div>
                    <div><label>Discount (%)</label><input type="number" step="0.01" name="discount_percent" id="discount_percent" value="0" oninput="syncDiscount('percent')"></div>
                    <div><label>Discount (₱)</label><input type="number" step="0.01" name="discount_val" id="discount_val" value="0" oninput="syncDiscount('val')"></div>
                    <div>
                        <label>Grand Total</label>
                        <div style="font-size: 1.2rem; font-weight: 800; color: var(--primary); padding: 5px 0;">
                            <span id="grand-total-display">₱ 0.00</span>
                        </div>
                        <input type="hidden" name="total_amount" id="total_amount" value="0.00">
                    </div>
                </div>

                <div class="full-row" style="margin-top:20px;">
                    <div><label>Amount Tendered</label><input type="number" step="0.01" name="tendered" id="tendered" required oninput="calculateChange()"></div>
                    <div>
                        <label>Change</label>
                        <div style="font-size: 1.2rem; font-weight: 800; color: var(--text-main); padding: 5px 0;">
                            <span id="change-display">₱ 0.00</span>
                        </div>
                        <input type="hidden" name="change" id="change" value="0.00">
                    </div>
                    <div>
                        <label>Payment Mode</label>
                        <select name="payment_mode">
                            <option value="Cash">Cash</option>
                            <option value="G-Cash">G-Cash</option>
                            <option value="Bank Transfer">Bank Transfer</option>
                        </select>
                    </div>
                </div>


                <div class="full-row">
                    <div>
                        <label>Select Store/Customer</label>
                        <select name="store_id" class="searchable-select">
                            <option value="0">Walk-in Customer</option>
                            <?php
                            $store_list = $conn->query("SELECT id, store_name FROM stores WHERE status = 'Active' ORDER BY store_name ASC");
                            while($st = $store_list->fetch_assoc()) {
                                echo "<option value='{$st['id']}'>".htmlspecialchars($st['store_name'])."</option>";
                            }
                            ?>
                        </select>
                    </div>
                    <div><label>Manual Name</label><input type="text" name="cust_name" placeholder="Enter name"></div>
                    <div><label>Contact Info</label><input type="text" name="cust_phone" placeholder="Phone/Email"></div>
                </div>





            </div>
            <div class="modal-footer" style="padding: 20px; border-top: 1px solid var(--border); text-align: right;">
                <button type="button" class="btn-red" onclick="closeModal()">Cancel</button>
                <button type="submit" class="btn-blue">Confirm Transaction</button>
            </div>
        </form>
    </div>
</div>
<div class="main-layout">
    <div class="table-container">
        <div class="table-header">
            <span style="font-weight: 800; letter-spacing: -0.5px; text-transform: uppercase;">
                <i class="fa fa-boxes"></i> Product Inventory
            </span>
         <form action="" method="GET" style="display: flex; gap: 8px; align-items: center; flex-wrap: wrap;">

                <select name="limit" onchange="this.form.submit()">
                    <option value="10" <?= $limit == 10 ? 'selected' : ''; ?>>10</option>
                    <option value="25" <?= $limit == 25 ? 'selected' : ''; ?>>25</option>
                    <option value="50" <?= $limit == 50 ? 'selected' : ''; ?>>50</option>
                </select>
            
            <select name="sort" onchange="this.form.submit()">
                <option value="date_desc" <?= $sort == 'date_desc' ? 'selected' : ''; ?>>Newest First</option>
                <option value="date_asc" <?= $sort == 'date_asc' ? 'selected' : ''; ?>>Oldest First</option>
                <option value="amount_high" <?= $sort == 'amount_high' ? 'selected' : ''; ?>>Highest Amount</option>
                <option value="amount_low" <?= $sort == 'amount_low' ? 'selected' : ''; ?>>Lowest Amount</option>
                <option value="name_asc" <?= $sort == 'name_asc' ? 'selected' : ''; ?>>Name (A-Z)</option>
            </select>
            
            <form action="" method="GET" style="display: flex; gap: 8px; align-items: center; flex-wrap: wrap;">
                <input type="text" name="search" placeholder="Search..." value="<?= htmlspecialchars($search); ?>">

            <button type="submit" class="btn-blue" style="padding: 8px 15px;">Search</button>
                
                <?php if(!empty($search)): ?>
                    <a href="products.php" style="font-size: 0.8rem; color: var(--primary); text-decoration: none;">Clear</a>
                <?php endif; ?>
            </form>
        </div>
<div class="table-area"> <table>
            <thead>
                <tr>
                    <th>Receipt No</th>
                    <th>Amount</th>
                    <th>Tendered</th>
                    <th>Change</th>
                    <th>Customer</th>
                    <th>Status</th>
                    <th>Date</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if($history && $history->num_rows > 0): ?>
                    <?php while($row = $history->fetch_assoc()): ?>
                    <tr>
                        <td style="font-weight: 700; color: var(--primary);">#<?= $row['receipt_no'] ?></td>
                        <td style="font-weight: 800;">₱<?= number_format($row['total_amount'], 2) ?></td>
                        <td>₱<?= number_format($row['amount_tendered'], 2) ?></td>
                        <td style="color: <?= ($row['change_due'] < 0) ? 'var(--danger)' : 'inherit' ?>;">
                            ₱<?= number_format($row['change_due'], 2) ?>
                        </td>
                        <td><?= htmlspecialchars($row['customer_name'] ?: 'Walk-in') ?></td>
                        <td>
                            <span style="color: <?= ($row['status'] == 'voided') ? 'var(--danger)' : 'var(--success)' ?>; font-weight: 800; font-size: 0.7rem; text-transform: uppercase;">
                                <?= $row['status'] ?: 'Completed' ?>
                            </span>
                        </td>
                        <td style="color: var(--text-muted); font-size: 0.8rem;">
                            <?= date('M d, g:i A', strtotime($row['date_created'])) ?>
                        </td>
                        <td>
                            <a href="print_receipt.php?id=<?= $row['id'] ?>" target="_blank" 
                               style="color: var(--primary); text-decoration:none; font-weight:800; font-size:0.7rem;">
                                RECEIPT
                            </a>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr><td colspan="8" style="text-align:center; padding:30px;">No transactions found.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <div style="display: flex; justify-content: space-between; align-items: center; padding: 15px 20px; background: #f8fafc; border-top: 1px solid var(--border); flex-wrap: wrap; gap: 10px;">
        <div style="font-size: 0.85rem; color: var(--text-muted);">
            Showing <?= $start_entry ?> to <?= $end_entry ?> of <?= $total_records ?> entries
        </div>
        <div class="pagination" style="display: flex; gap: 10px; align-items: center;">
            <?php if($page > 1): ?>
                <a href="?page=<?= $page-1 ?>&limit=<?= $limit ?>&search=<?= urlencode($search) ?>&sort=<?= $sort ?>&status=<?= $status_filter ?>" class="btn-blue" style="padding: 5px 15px; font-size: 0.8rem; text-decoration: none;">Previous</a>
            <?php endif; ?>
            
            <span style="font-size: 0.85rem; font-weight: 600;">Page <?= $page ?> of <?= $total_pages ?></span>
            
            <?php if($page < $total_pages): ?>
                <a href="?page=<?= $page+1 ?>&limit=<?= $limit ?>&search=<?= urlencode($search) ?>&sort=<?= $sort ?>&status=<?= $status_filter ?>" class="btn-blue" style="padding: 5px 15px; font-size: 0.8rem; text-decoration: none;">Next</a>
            <?php endif; ?>
        </div>
    </div>
</div>
</div>
<script src="script.js"></script>
<script>
function openModal() {
    document.getElementById('transactionModal').style.display = "block";
}

function closeModal() {
    document.getElementById('transactionModal').style.display = "none";
}

function voidTransaction(id) {
    let reason = prompt("Enter reason for voiding this transaction:");
    if (reason != null && reason != "") {
        window.location.href = "void_transaction.php?id=" + id + "&reason=" + encodeURIComponent(reason);
    }
}
</script>

</body>
</html>