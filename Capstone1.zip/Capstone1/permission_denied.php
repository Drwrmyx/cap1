<!DOCTYPE html>
<html lang="en">
<head>
        <meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Access Denied</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f4f7f6;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .error-container {
            text-align: center;
            background: white;
            padding: 40px;
            border-radius: 12px;
            box-shadow: 0 10px 25px rgba(0,0,0,0.1);
            max-width: 400px;
            border-top: 5px solid #e74c3c;
        }
        .error-icon {
            font-size: 60px;
            color: #e74c3c;
            margin-bottom: 20px;
        }
        h1 { margin: 0; color: #333; font-size: 24px; }
        p { color: #666; margin: 15px 0; line-height: 1.5; }
        .timer {
            font-weight: bold;
            color: #e74c3c;
            font-size: 18px;
        }
        .btn {
            display: inline-block;
            margin-top: 20px;
            padding: 10px 20px;
            background-color: #3498db;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            transition: background 0.3s;
        }
        .btn:hover { background-color: #2980b9; }
    </style>
</head>
<body>

<div class="error-container">
    <div class="error-icon">
        <i class="fa fa-shield-alt"></i>
    </div>
    <h1>Permission Denied</h1>
    <p>Sorry, you do not have the required administrative privileges to access this page.</p>
    <p>Redirecting you back to the Dashboard in <span id="countdown" class="timer">5</span> seconds...</p>
    <a href="Dashboard/dashboard.php" class="btn">Return to Dashboard Now</a>
</div>

<script>
    // Countdown Logic
    let seconds = 5;
    const display = document.getElementById('countdown');

    const timer = setInterval(() => {
        seconds--;
        display.innerText = seconds;
        if (seconds <= 0) {
            clearInterval(timer);
            window.location.href = 'Dashboard/dashboard.php';
        }
    }, 1000);
</script>

</body>
</html>