<?php
session_start();
include '../db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    try {
        $id    = (int)$_POST['id'];
        $name  = trim($_POST['store_name']);
        $owner = trim($_POST['owner_name']);
        $phone = trim($_POST['contact']);
        $addr  = trim($_POST['address']);
        $brgy  = trim($_POST['barangay']);

        // Logic: If owner name is not inputed, make store name the owner name
        if (empty($owner)) {
            $owner = $name;
        }

        // Validation: Check if contact number is 11 digits and starts with 09
        if (!empty($phone) && !preg_match('/^09[0-9]{9}$/', $phone)) {
            throw new Exception("Invalid contact number. Must be 11 digits starting with 09.");
        }

        $stmt = $conn->prepare("UPDATE stores SET store_name=?, owner_name=?, contact_number=?, address=?, barangay=? WHERE id=?");
        $stmt->bind_param("sssssi", $name, $owner, $phone, $addr, $brgy, $id);

        if ($stmt->execute()) {
            $_SESSION['alert_message'] = "Store information updated successfully!";
            $_SESSION['alert_type'] = "success";
            header("Location: stores.php");
            exit();
        }
    } catch (Exception $e) {
        $_SESSION['alert_message'] = $e->getMessage();
        $_SESSION['alert_type'] = "error";
        header("Location: stores.php");
        exit();
    }
}