    function openAddModal() {
        document.getElementById('addModal').style.display = 'block';
    }

    function openEditModal(store) {
        document.getElementById('edit_id').value = store.id;
        document.getElementById('edit_name').value = store.store_name;
        document.getElementById('edit_owner').value = store.owner_name;
        document.getElementById('edit_contact').value = store.contact_number;
        document.getElementById('edit_address').value = store.address;
        document.getElementById('edit_barangay').value = store.barangay;
        document.getElementById('editModal').style.display = 'block';
    }

    function closeModals() {
        document.getElementById('addModal').style.display = 'none';
        document.getElementById('editModal').style.display = 'none';
    }

    window.onclick = function(event) {
        if (event.target.className === 'modal') {
            closeModals();
        }
    }

// Replace the mobile menu section in script.js
document.addEventListener('DOMContentLoaded', () => {
    const dropdowns = document.querySelectorAll('.dropdown');
    
    dropdowns.forEach(dropdown => {
        const trigger = dropdown.querySelector('a');
        
        trigger.addEventListener('click', function(e) {
            if (window.innerWidth <= 1024) {
                // Prevent navigation to category headers
                e.preventDefault(); 
                
                const isOpened = dropdown.classList.contains('show-mobile');
                
                // Close other open dropdowns first
                dropdowns.forEach(d => d.classList.remove('show-mobile'));
                
                // Toggle current selection
                if (!isOpened) {
                    dropdown.classList.add('show-mobile');
                }
            }
        });
    });
});