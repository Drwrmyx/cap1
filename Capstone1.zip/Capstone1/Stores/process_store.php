<?php
session_start();
include '../db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    try {
        $name  = trim($_POST['store_name']);
        $owner = trim($_POST['owner_name']);
        $phone = trim($_POST['contact']);
        $addr  = trim($_POST['address']);
        $brgy  = trim($_POST['barangay']);

        // Logic: If owner name is not inputed, make store name the owner name
        if (empty($owner)) {
            $owner = $name;
        }

        // Validation: Check if contact number is 11 digits and starts with 09
        if (!empty($phone) && !preg_match('/^09[0-9]{9}$/', $phone)) {
            throw new Exception("Invalid contact number. Must be 11 digits starting with 09.");
        }

        // 3. Ensure required fields aren't just whitespace
        if (empty($name) || empty($brgy)) {
            throw new Exception("Store Name and Barangay are required.");
        }

        $stmt = $conn->prepare("INSERT INTO stores (store_name, owner_name, contact_number, address, barangay) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("sssss", $name, $owner, $phone, $addr, $brgy);

        if ($stmt->execute()) {
            $_SESSION['alert_message'] = "New store registered successfully!";
            $_SESSION['alert_type'] = "success";
            header("Location: stores.php");
            exit();
        }
    } catch (Exception $e) {
        $_SESSION['alert_message'] = $e->getMessage();
        $_SESSION['alert_type'] = "error";
        header("Location: stores.php");
        exit();
    }
}