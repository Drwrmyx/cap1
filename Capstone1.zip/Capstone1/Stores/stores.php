<?php
include '../admin_auth.php';
include '../db.php';

// --- 1. Pagination, Search, and Filter Logic ---
$search = isset($_GET['search']) ? $conn->real_escape_string($_GET['search']) : '';
$brgy_filter = isset($_GET['barangay']) ? $conn->real_escape_string($_GET['barangay']) : '';
$limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 10;
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
if ($page < 1) $page = 1;

$offset = ($page - 1) * $limit;

// WHERE clause for filtering
$where = "WHERE 1=1";
if($search) $where .= " AND (store_name LIKE '%$search%' OR owner_name LIKE '%$search%')";
if($brgy_filter) $where .= " AND barangay = '$brgy_filter'";

// Total records count for pagination
$count_res = $conn->query("SELECT COUNT(*) as total FROM stores $where");
$total_records = $count_res->fetch_assoc()['total'];
$total_pages = ceil($total_records / $limit);
if ($page > $total_pages && $total_pages > 0) $page = $total_pages;

// Fetch data with Limit and Offset
$stores = $conn->query("SELECT * FROM stores $where ORDER BY store_name ASC LIMIT $limit OFFSET $offset");

$barangays = ['168', '169', '170', '171', '174', '175', '177'];

// Calculate Entry info for footer
$start_entry = ($total_records > 0) ? $offset + 1 : 0;
$end_entry = min($offset + $limit, $total_records);
?>

<!DOCTYPE html>
<html lang="en">
<head>
        <meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Store Management</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="style.css"> 
</head>
<body>

<nav class="navbar">
    <a href="#" class="navbar-brand">
    <img src="../Image/MGSLOGO.png" alt="MGS Logo" class="nav-logo">
</a>
    
    <input type="checkbox" id="nav-toggle" class="nav-toggle">
    <label for="nav-toggle" class="nav-toggle-label">
        <i class="fa-solid fa-bars"></i> </label>
    
    <ul class="navbar-links">
        <li><a href="../Dashboard/dashboard.php"><i class="fa-solid fa-gauge-high"></i> Dashboard</a></li>
        
        <li class="dropdown">
            <a href="javascript:void(0)" class="dropdown-trigger">
                <i class="fa-solid fa-boxes-stacked"></i> Inventory <i class="fa-solid fa-caret-down"></i>
            </a>
            <div class="dropdown-content">
                <a href="../Products/products.php">All Products</a>
                <a href="../Products/logs.php">Logs</a>
                <a href="../Products/trash.php">Trash</a>
            </div>
        </li>

        <li><a href="stores.php" class="active"><i class="fa-solid fa-store"></i> Stores</a></li>

        <li class="dropdown">
            <a href="javascript:void(0)" class="dropdown-trigger">
                <i class="fa-solid fa-exchange-alt"></i> Transaction <i class="fa-solid fa-caret-down"></i>
            </a>
             <div class="dropdown-content">
                <a href="../Transactions/transaction.php">Transaction</a>
                <a href="../Transactions/void_logs.php">Void Logs</a>
                <a href="../Transactions/transaction_logs.php">Transaction Logs</a>
                <a href="../Transactions/sales_report.php">Sales Report</a>
            </div>
        </li>

        <li><a href="../Expenses/expenses.php"><i class="fa-solid fa-wallet"></i> Expenses</a></li>

        <li><a href="../logout.php" class="logout-link"><i class="fa-solid fa-right-from-bracket"></i> Logout</a></li>
    </ul>
</nav>

<div class="main-layout">
    <div class="controls-row">
        <button class="btn-blue" onclick="openAddModal()">
            <i class="fa-solid fa-plus"></i> Register New Store
        </button>
    </div>

    <div class="table-container">
        <div class="table-header">
            <span style="font-weight: 800; letter-spacing: -0.5px; text-transform: uppercase;">
                <i class="fa-solid fa-store"></i> Store Directory
            </span>
         <form action="" method="GET" style="display: flex; gap: 8px; align-items: center; flex-wrap: wrap;">
                <select name="limit" onchange="this.form.submit()">
                    <option value="10" <?= $limit == 10 ? 'selected' : ''; ?>>10</option>
                    <option value="25" <?= $limit == 25 ? 'selected' : ''; ?>>25</option>
                    <option value="50" <?= $limit == 50 ? 'selected' : ''; ?>>50</option>
                </select>

                <select name="barangay" onchange="this.form.submit()">
                    <option value="">All Barangays</option>
                    <?php foreach($barangays as $b): ?>
                        <option value="<?= $b ?>" <?= $brgy_filter == $b ? 'selected' : '' ?>>Brgy <?= $b ?></option>
                    <?php endforeach; ?>
                </select>

                <input type="text" name="search" placeholder="Search stores..." value="<?= htmlspecialchars($search); ?>">
                <button type="submit" class="btn-blue" style="padding: 8px 15px;">Search</button>
                
                <?php if(!empty($search) || !empty($brgy_filter)): ?>
                    <a href="stores.php" style="font-size: 0.8rem; color: var(--primary); text-decoration: none;">Clear</a>
                <?php endif; ?>
            </form>
        </div>

        <div class="table-area"> 
            <table>
<thead>
                    <tr>
                        <th>Store Name</th> <th>Owner Name</th>
                        <th>Barangay</th>
                        <th>Contact #</th>
                        <th>Address</th>
                        <th>Actions</th> </tr>
                </thead>
                <tbody>
                    <?php while($s = $stores->fetch_assoc()): ?>
                    <tr>
                        <td style="font-weight: 600;">
                            <?= htmlspecialchars($s['store_name']) ?>
                        </td>
                        <td><?= htmlspecialchars($s['owner_name']) ?></td>
                        <td><span class="badge" style="background:var(--primary);">Brgy <?= htmlspecialchars($s['barangay']) ?></span></td>
                        <td style="font-weight: 700;"><?= htmlspecialchars($s['contact_number']) ?></td>
                        <td class="description-cell"><?= htmlspecialchars($s['address']) ?></td>
                        <td style="white-space: nowrap;">
                            <a href="#" onclick='openEditModal(<?= json_encode($s) ?>)' 
                               style="color: var(--primary); text-decoration:none; font-weight:800; font-size:0.7rem; margin-right:10px;">
                                    <i class="fa fa-pencil"></i>
                            </a>
                            <a href="delete_store.php?id=<?= $s['id'] ?>" onclick="return confirm('Delete?')" 
                               style="color: var(--danger); text-decoration:none; font-weight:800; font-size:0.7rem;">
                                    <i class="fa fa-trash"></i>
                            </a>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>

        <div style="display: flex; justify-content: space-between; align-items: center; padding: 15px 20px; background: #f8fafc; border-top: 1px solid var(--border); flex-wrap: wrap; gap: 10px;">
            <div style="font-size: 0.85rem; color: var(--text-muted);">
                Showing <?= $start_entry ?> to <?= $end_entry ?> of <?= $total_records ?> entries
            </div>
            <div class="pagination" style="display: flex; gap: 10px; align-items: center;">
                <?php if($page > 1): ?>
                    <a href="?page=<?= $page-1 ?>&limit=<?= $limit ?>&search=<?= urlencode($search) ?>&barangay=<?= $brgy_filter ?>" class="btn-blue" style="padding: 5px 15px; font-size: 0.8rem; text-decoration: none;">Previous</a>
                <?php endif; ?>
                
                <span style="font-size: 0.85rem; font-weight: 600;">Page <?= $page ?> of <?= $total_pages ?></span>
                
                <?php if($page < $total_pages): ?>
                    <a href="?page=<?= $page+1 ?>&limit=<?= $limit ?>&search=<?= urlencode($search) ?>&barangay=<?= $brgy_filter ?>" class="btn-blue" style="padding: 5px 15px; font-size: 0.8rem; text-decoration: none;">Next</a>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<div id="addModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">Register New Store</div>
        <form action="process_store.php" method="POST">
            <div class="modal-body">
                <div class="modal-grid"> 
                    <div><label>Store Name</label><input type="text" name="store_name" required></div>
                    <div><label>Owner Name</label><input type="text" name="owner_name" placeholder="Leave blank to use store name"></div>
                    <div><label>Contact #</label>
                        <input type="text" name="contact" pattern="09[0-9]{9}" title="Please enter an 11-digit number starting with 09 (e.g., 09123456789)" required>
                    </div>
                    <div>
                        <label>Barangay</label>
                        <select name="barangay" required>
                            <option value="">Select Brgy</option>
                            <?php foreach($barangays as $b) echo "<option value='$b'>Barangay $b</option>"; ?>
                        </select>
                    </div>
                    <div class="full-width"><label>Address</label><input type="text" name="address"></div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="submit" class="btn-blue">Add Store</button>
                <button type="button" class="btn-red" onclick="closeModals()">Cancel</button>
            </div>
        </form>
    </div>
</div>

<div id="editModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">Edit Store Information</div>
        <form action="process_edit_store.php" method="POST">
            <input type="hidden" name="id" id="edit_id">
            <div class="modal-body">
                <div class="modal-grid">
                    <div><label>Store Name</label><input type="text" name="store_name" id="edit_name" required></div>
                    <div><label>Owner Name</label><input type="text" name="owner_name" id="edit_owner"></div>
                    <div><label>Contact #</label>
                        <input type="text" name="contact" id="edit_contact" pattern="09[0-9]{9}" title="Please enter an 11-digit number starting with 09" required>
                    </div>
                    <div>
                        <label>Barangay</label>
                        <select name="barangay" id="edit_barangay">
                            <?php foreach($barangays as $b) echo "<option value='$b'>Barangay $b</option>"; ?>
                        </select>
                    </div>
                    <div class="full-width"><label>Address</label><input type="text" name="address" id="edit_address"></div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="submit" class="btn-blue">Save Changes</button>
                <button type="button" class="btn-red" onclick="closeModals()">Cancel</button>
            </div>
        </form>
    </div>
</div>

<script src="script.js"></script>

</body>
</html>