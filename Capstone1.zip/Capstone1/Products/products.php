<?php 
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php?error=unauthorized");
    exit();
}
include '../db.php'; 
include 'functions.php';

// --- 1. Logic for Search, Sort, and Pagination ---
$search = isset($_GET['search']) ? $conn->real_escape_string($_GET['search']) : '';
$sort = isset($_GET['sort']) ? $_GET['sort'] : 'name_asc';
$limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 10;
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
if ($page < 1) $page = 1;

$offset = ($page - 1) * $limit;

// Map dropdown values to SQL ORDER BY
$sort_options = [
    'name_asc'      => "name ASC",
    'item_code_asc' => "item_code ASC",
    'price_high'    => "price DESC",
    'qty_high'      => "stock DESC",
    'name_desc'     => "name DESC",
    'item_code_desc'=> "item_code DESC",
    'price_low'     => "price ASC",
    'qty_low'       => "stock ASC"
];
$sort_sql = $sort_options[$sort] ?? "name ASC";

// WHERE clause
$where_sql = "WHERE is_deleted = 0 AND (name LIKE '%$search%' OR item_code LIKE '%$search%')";

// Count total records for pagination
$count_query = "SELECT COUNT(*) as total FROM products $where_sql";
$total_records = $conn->query($count_query)->fetch_assoc()['total'];
$total_pages = ceil($total_records / $limit);
if ($page > $total_pages && $total_pages > 0) $page = $total_pages;

// Main Data Query
$query = "SELECT * FROM products $where_sql ORDER BY $sort_sql LIMIT $limit OFFSET $offset";
$res = $conn->query($query);

$start_entry = ($total_records > 0) ? $offset + 1 : 0;
$end_entry = min($offset + $limit, $total_records);

// Calculate Total Worth
$total_worth_res = $conn->query("SELECT SUM(price * stock) as total FROM products WHERE is_deleted = 0");
$total_worth = $total_worth_res->fetch_assoc()['total'] ?? 0;
?>

<!DOCTYPE html>
<html lang="en">
<head>
        <meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inventory Management</title>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="style.css">
</head>
<body>

<nav class="navbar">
    <a href="#" class="navbar-brand">
    <img src="../Image/MGSLOGO.png" alt="MGS Logo" class="nav-logo">
</a>
    
    <input type="checkbox" id="nav-toggle" class="nav-toggle">
    <label for="nav-toggle" class="nav-toggle-label">
        <i class="fa-solid fa-bars"></i>
    </label>
    
    <ul class="navbar-links">
        <li><a href="../Dashboard/dashboard.php"><i class="fa-solid fa-gauge-high"></i> Dashboard</a></li>
        
        <li class="dropdown">
            <a href="javascript:void(0)" class="active">
                <i class="fa-solid fa-boxes-stacked"></i> Inventory <i class="fa-solid fa-caret-down"></i>
            </a>
            <div class="dropdown-content">
                <a href="../Products/products.php">All Products</a>
                <a href="../Products/logs.php">Logs</a>
                <a href="../Products/trash.php">Trash</a>
            </div>
        </li>

        <li><a href="../Stores/stores.php"><i class="fa-solid fa-store"></i> Stores</a></li>

        <li class="dropdown">
            <a href="javascript:void(0)">
                <i class="fa fa-exchange-alt"></i> Transaction <i class="fa-solid fa-caret-down"></i>
            </a>
             <div class="dropdown-content">
                <a href="../Transactions/transaction.php">Transaction</a>
                <a href="../Transactions/void_logs.php">Void Logs</a>
                <a href="../Transactions/transaction_logs.php">Transaction Logs</a>
                <a href="../Transactions/sales_report.php">Sales Report</a>
            </div>
        </li>

        <li><a href="../Expenses/expenses.php"><i class="fa-solid fa-wallet"></i> Expenses</a></li>

        <li>
            <a href="../logout.php" class="logout-link">
                <i class="fa-solid fa-right-from-bracket"></i> Logout
            </a>
        </li>
    </ul>
</nav>

<?php
// Fetch capacity data
$limit_res = $conn->query("SELECT setting_value FROM settings WHERE setting_key = 'total_inventory_limit'");
$limit = (int)$limit_res->fetch_assoc()['setting_value'];

$current_res = $conn->query("SELECT SUM(stock) as total FROM products WHERE is_deleted = 0");
$current = (int)$current_res->fetch_assoc()['total'];

$percentage = ($current / $limit) * 100;
$bar_color = ($percentage > 90) ? '#e74c3c' : (($percentage > 70) ? '#f1c40f' : '#2ecc71');
?>

<div style="background: white; padding: 15px; border-radius: 8px; margin-bottom: 20px; box-shadow: 0 2px 5px rgba(0,0,0,0.05);">
    <div style="display: flex; justify-content: space-between; margin-bottom: 5px;">
        <span style="font-weight: bold;">Warehouse Capacity</span>
        <span><?php echo $current; ?> / <?php echo $limit; ?> Items</span>
    </div>
    <div style="background: #eee; height: 10px; border-radius: 5px; overflow: hidden;">
        <div style="width: <?php echo $percentage; ?>%; background: <?php echo $bar_color; ?>; height: 100%; transition: width 0.5s;"></div>
    </div>
</div>




<?php if (isset($_SESSION['alert_message'])): ?>
    <div id="sys-alert" class="alert alert-<?php echo $_SESSION['alert_type']; ?>" 
         style="padding: 15px; margin-bottom: 20px; border-radius: 4px; text-align: center; 
         <?php echo ($_SESSION['alert_type'] === 'error') ? 'background-color: #f8d7da; color: #721c24;' : 'background-color: #d4edda; color: #155724;'; ?>">
        
        <?php echo $_SESSION['alert_message']; ?>
        
    </div>
    
    <?php 
    unset($_SESSION['alert_message']); 
    unset($_SESSION['alert_type']);
    ?>
<?php endif; ?>

<div class="controls-row">
    <button class="btn-blue" onclick="openAddModal()">
        <i class="fa fa-plus"></i> Add New Product
    </button>
</div>

<div id="addModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">Add New Product</div>
        <form action="process.php" method="POST" enctype="multipart/form-data">
            <div class="modal-body">
                <div class="modal-grid"> 
                    <div><label>Item Code</label><input type="text" name="item_code" required></div>
                    <div><label>Item Name</label><input type="text" name="name" required></div>
                    <div><label>Initial Quantity</label><input type="number" name="stock" min="0" required></div>
                    <div><label>Unit Price (₱)</label><input type="number" name="price" min="0" step="0.01" required></div>
                    <div>
                        <label>Unit of Measurement (UOM)</label>
                        <select name="uom" required>
                            <option value="">-- Select UOM --</option>
                            <option value="PC">PC (Piece)</option>
                            <option value="CS">CS (Case/Box)</option>
                        </select>
                    </div>
                    <div>
                        <label>Category</label>
                        <select name="category" required>
                            <option value="">-- Select Category --</option>
                            <option value="Cone">Cone</option>
                            <option value="CUP">CUP</option>
                            <option value="bite size">bite size</option>
                            <option value="STICK">STICK</option>
                            <option value="TUBS">TUBS</option>
                        </select>
                    </div>
                    <div class="full-width"><label>Maximum Stock Limit</label><input type="number" name="max_stock" placeholder="0 for no limit" min="0"></div>
                    <div class="full-width"><label>Product Image</label><input type="file" name="product_image" accept="image/*"></div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="submit" name="add_item" class="btn-blue">Add Item</button>
                <button type="button" class="btn-red" onclick="closeModals()">Cancel</button>
            </div>
        </form>
    </div>
</div>

<div class="main-layout">
    <div class="table-container">
        <div class="table-header">
            <span style="font-weight: 800; letter-spacing: -0.5px; text-transform: uppercase;">
                <i class="fa fa-boxes"></i> Product Inventory
            </span>
         <form action="" method="GET" style="display: flex; gap: 8px; align-items: center; flex-wrap: wrap;">

                <select name="limit" onchange="this.form.submit()">
                    <option value="10" <?= $limit == 10 ? 'selected' : ''; ?>>10</option>
                    <option value="25" <?= $limit == 25 ? 'selected' : ''; ?>>25</option>
                    <option value="50" <?= $limit == 50 ? 'selected' : ''; ?>>50</option>
                </select>

                <select name="sort" onchange="this.form.submit()">
                    <?php foreach($sort_options as $key => $val): ?>
                        <option value="<?= $key ?>" <?= $sort == $key ? 'selected' : ''; ?>>
                            <?= ucwords(str_replace(['_', 'asc', 'desc'], [' ', ' (A-Z)', ' (Z-A)'], $key)) ?>
                        </option>
                    <?php endforeach; ?>
                </select>

                <input type="text" name="search" placeholder="Search products..." value="<?= htmlspecialchars($search); ?>">
                <button type="submit" class="btn-blue" style="padding: 8px 15px;">Search</button>
                
                <?php if(!empty($search)): ?>
                    <a href="products.php" style="font-size: 0.8rem; color: var(--primary); text-decoration: none;">Clear</a>
                <?php endif; ?>
            </form>
        </div>
        <div style="overflow-x: auto;">
<table>
    <thead>
        <tr>
            <th>ITEM NAME</th> <th>Image</th>
            <th>SKU</th>
            <th>UOM</th>
        <th>Category</th>
            <th>QTY IN STOCK</th>
            <th>UNIT PRICE</th>
            <th>TOTAL SOLD</th>
            <th>TOTAL EARNED</th>
            <th>UPDATE</th>
            <th>EDIT</th>
            <th>DELETE</th>
        </tr>
    </thead>
    <tbody>
        <?php while($row = $res->fetch_assoc()): ?>
        <tr class="<?= $row['stock'] <= 0 ? 'low-stock' : '' ?>">
            <td style="font-weight: 600; color: var(--primary); min-width: 140px;">
                <?php echo htmlspecialchars($row['name']); ?>
            </td>

            <td style="padding: 8px; text-align: center;">
                <?php 
                    $img_src = (!empty($row['image_path']) && file_exists($row['image_path'])) 
                            ? htmlspecialchars($row['image_path']) 
                            : 'uploads/no-image.jpg';
                ?>
                <img src="<?= $img_src ?>" alt="Product" class="zoomable-img" 
                     style="width: 70px; height: 70px; object-fit: cover; border-radius: 0px;">
            </td>

            <td><?php echo htmlspecialchars($row['item_code']); ?></td>
            <td><?php echo $row['uom']; ?></td>
            <td><?php echo htmlspecialchars($row['category']); ?></td>
            <td><?= $row['stock'] ?></td>
            <td>₱<?= number_format($row['price'], 2) ?></td>
            <td><?= $row['total_sold'] ?></td>
            <td>₱<?= number_format($row['total_earned_on_item'] ?? 0, 2) ?></td>
            
            <td><a href="#" onclick='openUpdateModal(<?= json_encode($row) ?>)' style="color: var(--success);">
                <i class="fa-solid fa-arrows-rotate"></i></a></td>

            <td><a href="#" onclick='openEditModal(<?= json_encode($row) ?>)' style="color: var(--primary);">
                <i class="fa-solid fa-pencil"></i></a></td>

            <td><a href="process_delete.php?id=<?= $row['id'] ?>" onclick="return confirm('Delete?')" style="color: var(--danger);">
                <i class="fa-solid fa-trash"></i></a></td>
        </tr>
        <?php endwhile; ?>
    </tbody>
</table>
    </div>
    
    <!-- Entry Summary and Pagination -->
    <div style="display: flex; justify-content: space-between; align-items: center; padding: 15px 20px; background: #f8fafc; border-top: 1px solid var(--border);">
        <div style="font-size: 0.85rem; color: var(--text-muted);">
            Showing <?= $start_entry ?> to <?= $end_entry ?> of <?= $total_records ?> entries
        </div>
        <div class="pagination" style="display: flex; gap: 10px; align-items: center;">
            <?php if($page > 1): ?>
                <a href="?page=<?= $page-1 ?>&limit=<?= $limit ?>&search=<?= urlencode($search) ?>&sort=<?= $sort ?>" class="btn-blue" style="padding: 5px 15px; font-size: 0.8rem;">Previous</a>
            <?php endif; ?>
            <span style="font-size: 0.85rem; font-weight: 600;">Page <?= $page ?> of <?= $total_pages ?></span>
            <?php if($page < $total_pages): ?>
                <a href="?page=<?= $page+1 ?>&limit=<?= $limit ?>&search=<?= urlencode($search) ?>&sort=<?= $sort ?>" class="btn-blue" style="padding: 5px 15px; font-size: 0.8rem;">Next</a>
            <?php endif; ?>
        </div>
    </div>

</div>

<div id="updateModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">Update Stock</div>
        <form action="process_update.php" method="POST">
            <input type="hidden" name="product_id" id="up_id">
            <div class="modal-body">
                <div class="modal-grid">
                    <div><label>Item Name</label><input type="text" name="item_name" id="up_name" readonly class="readonly-input"></div>
                    <div><label>Item Code</label><input type="text" name="item_code" id="up_code" readonly class="readonly-input"></div>
                    <div><label>Qty in Stock</label><input type="text" name="stock" id="up_stock" readonly class="readonly-input"></div>
                    <div><label>Quantity to Change</label><input type="number" name="new_qty" id="update_qty" min="1" required></div>
                    <div class="full-width"> <label>Update Type</label>
                        <select name="type" required style="width:100%; padding:8px;">
                            <option value=""> </option>
                            <option value="add">Add to Stock</option>
                            <option value="remove">Remove from Stock</option>
                        </select>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="submit" class="btn-blue">Update</button>
                <button type="button" class="btn-red" onclick="closeModals()">Cancel</button>
            </div>
        </form>
    </div>
</div>

<div id="editModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">Edit Item</div>
        <form action="process_edit.php" method="POST" enctype="multipart/form-data">
            <input type="hidden" name="id" id="edit_id">
            <div class="modal-body">
                <div class="modal-grid">
                    <div><label>Item Name</label><input type="text" name="name" id="edit_name" required></div>
                    <div><label>Item Code</label><input type="text" name="item_code" id="edit_code"></div>
                    <div><label>Unit Price</label><input type="number" step="0.01" name="price" id="edit_price" required></div>
                    <div><label>Max Stock Limit</label><input type="number" name="max_stock" id="edit_max_stock" min="0"></div>
                    <div><label>UOM</label>
                        <select name="uom" id="edit_uom" class="form-control" required>
                            <option value="PC">PC</option>
                            <option value="CS">CS</option>
                        </select>
                    </div>
                    <div>
                        <label>Category</label>
                        <select name="category" id="edit_category" required>
                            <option value="Cone">Cone</option>
                            <option value="CUP">CUP</option>
                            <option value="bite size">bite size</option>
                            <option value="STICK">STICK</option>
                            <option value="TUBS">TUBS</option>
                        </select>
                    </div>
                </div>
                <div class="full-width">
                    <label>Change Product Image</label>
                    <input type="file" name="product_image" accept="image/*">
                </div>
            </div>
            <div class="modal-footer">
                <button type="submit" class="btn-blue">Save Changes</button>
                <button type="button" class="btn-red" onclick="closeModals()">Cancel</button>
            </div>
        </form>
    </div>
</div>

<div id="imageZoomModal" class="image-zoom-overlay">
    <span class="close-zoom">&times;</span>
    <img class="zoom-content" id="img01">
    <div id="caption"></div>
</div>
<script src="script.js"></script>

</body>
</html>
