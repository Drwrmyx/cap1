<?php
// functions.php

/**
 * Logs inventory activity to the database.
 */
function log_activity($conn, $product_id, $item_code, $action, $details) {
    $log_stmt = $conn->prepare("INSERT INTO product_logs (product_id, item_code, action_type, description) VALUES (?, ?, ?, ?)");
    $log_stmt->bind_param("isss", $product_id, $item_code, $action, $details);
    $log_stmt->execute();
    $log_stmt->close();
}
?>