<?php
include '../db.php';
include 'functions.php';

if (isset($_POST['add_item'])) {
    // 1. Sanitize Whitespace
    $code = trim($_POST['item_code']);
    $name = trim($_POST['name']);
    $stock = (int)$_POST['stock'];
    $max_stock = (int)$_POST['max_stock']; // Add this line
    $price = (float)$_POST['price'];
    $uom = $_POST['uom'];
    $category = trim($_POST['category']);

    // 2. Value Validation: Prevent Negative Numbers
    if ($stock < 0) {
        die("Validation Error: Stock quantity cannot be negative.");
    }
    if ($max_stock < $stock && $max_stock > 0) {
    die("Validation Error: Max stock cannot be less than initial stock.");
    }   
    if ($price < 0) {
        die("Validation Error: Unit price cannot be negative.");
    }
    
    // 3. Required Field Validation
    if (empty($name)) {
        die("Validation Error: Item Name is required.");
    }

    // 4. Data Integrity: Check for Duplicate Item Code
    // We only check if the user actually typed a code (assuming codes might be optional)
    if (!empty($code)) {
        $check_stmt = $conn->prepare("SELECT id FROM products WHERE item_code = ?");
        $check_stmt->bind_param("s", $code);
        $check_stmt->execute();
        $check_stmt->store_result();
        
        if ($check_stmt->num_rows > 0) {
            die("Data Integrity Error: An item with the code '$code' already exists.");
        }
        $check_stmt->close();
    }



    
// ... [Your existing validation for stock, price, name, and duplicate codes] ...

    // --- SECURE IMAGE UPLOAD LOGIC ---
    $image_path = NULL; // Default to NULL if no image is uploaded

    // Check if a file was uploaded without errors
    if (isset($_FILES['product_image']) && $_FILES['product_image']['error'] === UPLOAD_ERR_OK) {
        
        // Define allowed extensions and MIME types (Including AVIF)
        $allowed_exts = ['jpg', 'jpeg', 'png', 'webp', 'gif', 'avif'];
        $allowed_mimes = ['image/jpeg', 'image/png', 'image/webp', 'image/gif', 'image/avif'];

        $file_tmp = $_FILES['product_image']['tmp_name'];
        $file_name = $_FILES['product_image']['name'];
        $file_size = $_FILES['product_image']['size'];
        
        // Get the actual file extension and MIME type
        $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));
        $file_mime = mime_content_type($file_tmp); // Checks the real file signature, not just the name

        // Validate the file
        if (in_array($file_ext, $allowed_exts) && in_array($file_mime, $allowed_mimes)) {
            // Limit file size to 5MB (5 * 1024 * 1024 bytes)
            if ($file_size <= 5242880) {
                // Create a unique filename so "apple.jpg" doesn't overwrite another "apple.jpg"
                $new_file_name = uniqid('img_', true) . '.' . $file_ext;
                $dest_path = 'uploads/' . $new_file_name;

                // Move the file from temporary storage to the uploads folder
                if (move_uploaded_file($file_tmp, $dest_path)) {
                    $image_path = $dest_path; // Save this path to the database
                } else {
                    die("Server Error: Failed to move uploaded file.");
                }
            } else {
                die("Validation Error: Image file is too large. Maximum size is 5MB.");
            }
        } else {
            die("Validation Error: Invalid file type. Only JPG, PNG, WEBP, GIF, and AVIF are allowed.");
        }
    }

    // --- SECURE INSERT (Updated to include image_path) ---
    // Notice the extra '?' and the 's' added to the bind_param
// Update the query to include image_path and fix the binding
$stmt = $conn->prepare("INSERT INTO products (item_code, uom, category, name, stock, max_stock, price, image_path) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
// Types: s=string, i=integer, d=double
$stmt->bind_param("ssssiids", $code, $uom, $category, $name, $stock, $max_stock, $price, $image_path);
    if ($stmt->execute()) {
        $new_product_id = $conn->insert_id; 
        
        // --- LOGGING LOGIC ---
        $details = "Added new item: $name with initial stock of $stock.";
        log_activity($conn, $new_product_id, $code, 'Item Created', $details);

        $_SESSION['alert_message'] = "New item added successfully!";
        $_SESSION['alert_type'] = "success"; 
        header("Location: products.php");
        exit();
    } else {
        die("Database Error: " . $conn->error);
    }
    
    $stmt->close();
}
?>