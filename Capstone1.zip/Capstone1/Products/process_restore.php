<?php
include '../db.php';
include 'functions.php'; // Remember our centralized logging function!

if (isset($_GET['id'])) {
    $id = (int)$_GET['id'];
    
    // 1. Fetch item details for the log
    $info_stmt = $conn->prepare("SELECT item_code, name FROM products WHERE id = ?");
    $info_stmt->bind_param("i", $id);
    $info_stmt->execute();
    $info_stmt->bind_result($res_code, $res_name);
    $info_stmt->fetch();
    $info_stmt->close();
    
    // 2. Soft Restore: Change is_deleted back to 0
    $stmt = $conn->prepare("UPDATE products SET is_deleted = 0 WHERE id = ?");
    $stmt->bind_param("i", $id);
    
    if ($stmt->execute()) {
        // 3. Log the activity
        $action = 'Item Restored';
        $item_name_log = $res_name ? $res_name : "Unknown Item";
        $details = "Restored item back to active inventory: " . $item_name_log . ".";
        
        log_activity($conn, $id, $res_code, $action, $details);

        // 4. Send success message
        $_SESSION['alert_message'] = "Item successfully restored!";
        $_SESSION['alert_type'] = "success"; 
        header("Location: trash.php");
        exit();
    } else {
        die("Error restoring item.");
    }
}
?>