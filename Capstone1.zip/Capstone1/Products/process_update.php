<?php
include '../db.php';
include 'functions.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = (int)$_POST['product_id'];
    $type = $_POST['type']; 
    $qty_change = (int)$_POST['new_qty']; 
    
    if ($qty_change <= 0) {
        die("Error: Quantity must be greater than zero.");
    }

    if ($type === 'add') {
        $stmt = $conn->prepare("UPDATE products SET stock = stock + ? WHERE id = ?");
        $stmt->bind_param("ii", $qty_change, $id);
    } elseif ($type === 'remove') {
        $stmt = $conn->prepare("UPDATE products SET stock = stock - ? WHERE id = ? AND stock >= ?");
        $stmt->bind_param("iii", $qty_change, $id, $qty_change);
    } else {
        die("Error: Invalid update type selected.");
    }

// ... [Existing code to get $id, $type, $qty_change] ...

if ($type === 'add') {
    // 1. Get Current Stock, Max Stock, and Global Limit
    $limit_query = $conn->query("SELECT stock, max_stock FROM products WHERE id = $id");
    $product = $limit_query->fetch_assoc();
    
    $global_res = $conn->query("SELECT setting_value FROM settings WHERE setting_key = 'total_inventory_limit'");
    $global_limit = (int)$global_res->fetch_assoc()['setting_value'];
    
    $total_current_res = $conn->query("SELECT SUM(stock) as total FROM products WHERE is_deleted = 0");
    $total_current_stock = (int)$total_current_res->fetch_assoc()['total'];

    // 2. CHECK: Per-Product Maximum
    if ($product['max_stock'] > 0 && ($product['stock'] + $qty_change) > $product['max_stock']) {
        $_SESSION['alert_message'] = "Cannot add stock. It would exceed the maximum limit of " . $product['max_stock'] . " for this item.";
        $_SESSION['alert_type'] = "error";
        header("Location: products.php");
        exit();
    }

    // 3. CHECK: Global Warehouse Capacity
    if (($total_current_stock + $qty_change) > $global_limit) {
        $_SESSION['alert_message'] = "Warehouse Full! This update would exceed your total capacity of $global_limit items.";
        $_SESSION['alert_type'] = "error";
        header("Location: products.php");
        exit();
    }

    // If both checks pass, proceed with the update
    $stmt = $conn->prepare("UPDATE products SET stock = stock + ? WHERE id = ?");
    $stmt->bind_param("ii", $qty_change, $id);
}
// ... [rest of your update/remove logic] ...



    if ($stmt->execute()) {
        if ($stmt->affected_rows > 0) {
            
            // 1. Fetch BOTH the item code AND the item name from the database
            $info_stmt = $conn->prepare("SELECT item_code, name FROM products WHERE id = ?");
            $info_stmt->bind_param("i", $id);
            $info_stmt->execute();
            // Bind the results to two separate variables
            $info_stmt->bind_result($true_item_code, $item_name); 
            $info_stmt->fetch();
            $info_stmt->close();

            // 2. --- LOGGING LOGIC START ---
            // --- LOGGING LOGIC ---
            $action = ($type === 'add') ? 'Stock Increased' : 'Stock Decreased';
            $details = "Quantity changed by $qty_change for item: $item_name.";
            log_activity($conn, $id, $true_item_code, $action, $details);
            // --- LOGGING LOGIC END ---

            // Replace header("Location: products.php?success=stock_updated"); with this:
            $_SESSION['alert_message'] = "Stock quantity updated!";
            $_SESSION['alert_type'] = "success";
            header("Location: products.php");
            exit();
        } else {
            die("Error: Cannot remove more items than are currently in stock.");
        }
    } else {
        echo "Database Error: " . $stmt->error;
    }
    $stmt->close();
}
?>