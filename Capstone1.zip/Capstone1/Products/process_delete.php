<?php
include '../db.php';
include 'functions.php';

// Enable mysqli exceptions so we can catch them cleanly
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

if (isset($_GET['id'])) {
    $id = (int)$_GET['id'];
    
    // 1. Fetch item details BEFORE deleting it so we can log it
    $info_stmt = $conn->prepare("SELECT item_code, name FROM products WHERE id = ?");
    $info_stmt->bind_param("i", $id);
    $info_stmt->execute();
    $info_stmt->bind_result($del_code, $del_name);
    $info_stmt->fetch();
    $info_stmt->close();
    
    // 2. Prepare the Soft Delete statement
    $stmt = $conn->prepare("UPDATE products SET is_deleted = 1 WHERE id = ?");
    $stmt->bind_param("i", $id);
    
    // 3. Execute the soft deletion
    if ($stmt->execute()) {
        // --- LOGGING LOGIC ---
        $action = 'Item Deleted';
        $item_name_log = $del_name ? $del_name : "Unknown Item";
        $details = "Removed item from active inventory: " . $item_name_log . ".";
        
        log_activity($conn, $id, $del_code, $action, $details);

        $_SESSION['alert_message'] = "Item has been removed from inventory.";
        $_SESSION['alert_type'] = "error"; 
        header("Location: products.php");
        exit();
    } else {
        // You no longer need the complex try/catch block for foreign keys 
        // because you aren't actually deleting the row anymore!
        die("Error removing item.");
    }
    
    $stmt->close();
}
?>