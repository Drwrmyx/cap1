<?php
include '../db.php';
include 'functions.php';

// session_start(); // Only uncomment if it's NOT already in your db.php

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = (int)$_POST['id'];
    $uom = $_POST['uom'];            // New
$category = trim($_POST['category']);
    $max_stock = (int)$_POST['max_stock']; // Add this line
    $name = trim($_POST['name']);
    $code = trim($_POST['item_code']);
    $price = (float)$_POST['price'];

    // 1. GUARD: Check if price is negative
    if ($price < 0) {
        $_SESSION['alert_message'] = "Error: Price cannot be a negative value.";
        $_SESSION['alert_type'] = "error";
        header("Location: products.php");
        exit();
    }

    $image_path = null;
    $upload_success = false;

    // 2. HANDLE IMAGE UPDATE
    if (isset($_FILES['product_image']) && $_FILES['product_image']['error'] === UPLOAD_ERR_OK) {
        
        $allowed_exts = ['jpg', 'jpeg', 'png', 'webp', 'gif', 'avif'];
        $file_tmp = $_FILES['product_image']['tmp_name'];
        $file_name = $_FILES['product_image']['name'];
        $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));

        if (in_array($file_ext, $allowed_exts)) {
            // Create unique name
            $new_file_name = uniqid('img_', true) . '.' . $file_ext;
            $dest_path = 'uploads/' . $new_file_name;

            if (move_uploaded_file($file_tmp, $dest_path)) {
                $image_path = $dest_path;
                $upload_success = true;

                // CLEANUP: Fetch and delete the old image file from the server
                $old_img_query = $conn->prepare("SELECT image_path FROM products WHERE id = ?");
                $old_img_query->bind_param("i", $id);
                $old_img_query->execute();
                $old_img_query->bind_result($old_path);
                $old_img_query->fetch();
                $old_img_query->close();

                if (!empty($old_path) && file_exists($old_path)) {
                    unlink($old_path); // Physically deletes the old file
                }
            }
        }
    }

    // 3. SECURE UPDATE (Conditional SQL)
    // Update the SQL queries to include max_stock
// 3. SECURE UPDATE (Conditional SQL)
if ($upload_success) {
    // There are 8 placeholders (?) here
    $stmt = $conn->prepare("UPDATE products SET name=?, item_code=?, uom=?, category=?, price=?, max_stock=?, image_path=? WHERE id=?");
    
    // There must be 8 type characters: s (name), s (code), s (uom), s (category), d (price), i (max_stock), s (path), i (id)
    $stmt->bind_param("ssssdisi", $name, $code, $uom, $category, $price, $max_stock, $image_path, $id); 
} else {
    // There are 7 placeholders (?) here
    $stmt = $conn->prepare("UPDATE products SET name=?, item_code=?, uom=?, category=?, price=?, max_stock=? WHERE id=?");
    
    // There must be 7 type characters: s (name), s (code), s (uom), s (category), d (price), i (max_stock), i (id)
    $stmt->bind_param("ssssdii", $name, $code, $uom, $category, $price, $max_stock, $id);
}

    if ($stmt->execute()) {
        // 4. LOGGING LOGIC
        log_activity($conn, $id, $code, 'Item Edited', "Updated details for item: $name.");

        $_SESSION['alert_message'] = "Item details updated!";
        $_SESSION['alert_type'] = "success"; 
        header("Location: products.php");
        exit();
    } else {
        $_SESSION['alert_message'] = "Database Error: " . $stmt->error;
        $_SESSION['alert_type'] = "error";
        header("Location: products.php");
        exit();
    }
}
?>