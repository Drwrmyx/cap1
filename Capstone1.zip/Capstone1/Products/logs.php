<?php 
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php?error=unauthorized");
    exit();
}
include '../db.php'; 
include 'functions.php';

// Get Filter Parameters
$search = isset($_GET['search']) ? $conn->real_escape_string($_GET['search']) : '';
$limit  = isset($_GET['limit']) ? (int)$_GET['limit'] : 50;
$sort   = isset($_GET['sort']) ? $_GET['sort'] : 'created_at DESC';
$page   = isset($_GET['page']) ? (int)$_GET['page'] : 1;
if ($page < 1) $page = 1;

$action_filter = isset($_GET['action']) ? $conn->real_escape_string($_GET['action']) : '';

// Valid sorting options
$allowed_sorts = [
    'created_at DESC' => 'Newest First',
    'created_at ASC'  => 'Oldest First',
    'item_code ASC'   => 'Item Code (A-Z)',
];

// Build the WHERE clause dynamically
$where_clauses = [];

// Search filter
if (!empty($search)) {
    $where_clauses[] = "(item_code LIKE '%$search%' OR description LIKE '%$search%')";
}

// Action Type filter
if (!empty($action_filter)) {
    $where_clauses[] = "action_type = '$action_filter'";
}

$where_sql = !empty($where_clauses) ? "WHERE " . implode(' AND ', $where_clauses) : "";

// Pagination Calculations
$count_query = "SELECT COUNT(*) as total FROM product_logs $where_sql";
$total_records = $conn->query($count_query)->fetch_assoc()['total'];
$total_pages = ceil($total_records / $limit);
if ($page > $total_pages && $total_pages > 0) $page = $total_pages;
$offset = ($page - 1) * $limit;

// Final Query
$query = "SELECT * FROM product_logs $where_sql ORDER BY $sort LIMIT $limit OFFSET $offset";
$result = $conn->query($query);

$start_entry = ($total_records > 0) ? $offset + 1 : 0;
$end_entry = min($offset + $limit, $total_records);
?>

<!DOCTYPE html>
<html lang="en">
<head>
        <meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Activity Logs - IMS</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>

<nav class="navbar">
    <a href="#" class="navbar-brand">
    <img src="../Image/MGSLOGO.png" alt="MGS Logo" class="nav-logo">
</a>
    
    <input type="checkbox" id="nav-toggle" class="nav-toggle">
    <label for="nav-toggle" class="nav-toggle-label">
        <i class="fa-solid fa-bars"></i>
    </label>
    
    <ul class="navbar-links">
        <li><a href="../Dashboard/dashboard.php"><i class="fa-solid fa-gauge-high"></i> Dashboard</a></li>
        
        <li class="dropdown">
            <a href="javascript:void(0)" class="active">
                <i class="fa-solid fa-boxes-stacked"></i> Inventory <i class="fa-solid fa-caret-down"></i>
            </a>
            <div class="dropdown-content">
                <a href="../Products/products.php">All Products</a>
                <a href="../Products/logs.php">Logs</a>
                <a href="../Products/trash.php">Trash</a>
            </div>
        </li>

        <li><a href="../Stores/stores.php"><i class="fa-solid fa-store"></i> Stores</a></li>

        <li class="dropdown">
            <a href="javascript:void(0)">
                <i class="fa fa-exchange-alt"></i> Transaction <i class="fa-solid fa-caret-down"></i>
            </a>
             <div class="dropdown-content">
                <a href="../Transactions/transaction.php">Transaction</a>
                <a href="../Transactions/void_logs.php">Void Logs</a>
                <a href="../Transactions/transaction_logs.php">Transaction Logs</a>
                <a href="../Transactions/sales_report.php">Sales Report</a>
            </div>
        </li>

        <li><a href="../Expenses/expenses.php"><i class="fa-solid fa-wallet"></i> Expenses</a></li>

        <li>
            <a href="../logout.php" class="logout-link">
                <i class="fa-solid fa-right-from-bracket"></i> Logout
            </a>
        </li>
    </ul>
</nav>

<div class="main-layout">
    <div class="table-container">
        <div class="table-header">
            <span style="font-weight: 800; letter-spacing: -0.5px; text-transform: uppercase;">
                <i class="fa fa-boxes"></i> Product Inventory
            </span>
         <form action="" method="GET" style="display: flex; gap: 8px; align-items: center; flex-wrap: wrap;">

                <select name="limit" onchange="this.form.submit()">
                    <option value="10" <?= $limit == 10 ? 'selected' : ''; ?>>10</option>
                    <option value="25" <?= $limit == 25 ? 'selected' : ''; ?>>25</option>
                    <option value="50" <?= $limit == 50 ? 'selected' : ''; ?>>50</option>
                </select>

                <select name="action" onchange="this.form.submit()">
                    <option value="">Actions</option>
                    <option value="Item Created" <?php echo $action_filter == 'Item Created' ? 'selected' : ''; ?>>Created</option>
                    <option value="Item Edited" <?php echo $action_filter == 'Item Edited' ? 'selected' : ''; ?>>Edited</option>
                    <option value="Item Deleted" <?php echo $action_filter == 'Item Deleted' ? 'selected' : ''; ?>>Deleted</option>
                    <option value="Stock Increased" <?php echo $action_filter == 'Stock Increased' ? 'selected' : ''; ?>>Stock +</option>
                    <option value="Stock Decreased" <?php echo $action_filter == 'Stock Decreased' ? 'selected' : ''; ?>>Stock -</option>
                </select>

                <input type="text" name="search" placeholder="Search products..." value="<?= htmlspecialchars($search); ?>">
                <button type="submit" class="btn-blue" style="padding: 8px 15px;">Search</button>
                
                <?php if(!empty($search)): ?>
                    <a href="products.php" style="font-size: 0.8rem; color: var(--primary); text-decoration: none;">Clear</a>
                <?php endif; ?>
            </form>
        </div>
        <div style="overflow-x: auto;">
<table>
                <thead>
                    <tr>
                        <th>Item Code</th>
                        <th>Date & Time</th>
                        <th>Action</th>
                        <th>Description</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    if ($result->num_rows > 0) {
                        while ($row = $result->fetch_assoc()) {
                            $date = date("M j, Y, g:i a", strtotime($row['created_at']));
                            
                            // Visual color coding for actions
                            $bg = "#64748b"; 
                            $act = $row['action_type'];
                            if ($act == 'Item Created') $bg = "var(--success)";
                            if ($act == 'Item Deleted') $bg = "var(--danger)";
                            if ($act == 'Item Edited') $bg = "var(--primary)";
                            if ($act == 'Item Restored') $bg = "#8b5cf6"; // Purple
                            if ($act == 'Stock Increased') $bg = "#f59e0b"; // Orange
                            if ($act == 'Stock Decreased') $bg = "#eab308"; // Yellow

                            echo "<tr>
                                    <td style='font-weight: 700; color: var(--text-main);'>" . htmlspecialchars($row['item_code']) . "</td>
                                    <td style='color: var(--text-muted); font-size: 0.85rem;'>$date</td>
                                    <td style='color: $bg; padding:4px 8px; border-radius:4px; font-size:0.75rem; font-weight:bold;'>$act</td>
                                    <td class='description-cell' style='font-size:0.85rem;'>" . htmlspecialchars($row['description']) . "</td>
                                  </tr>";
                        }
                    } else {
                        echo "<tr><td colspan='4' style='text-align: center; padding: 30px; color: var(--text-muted);'>No matching logs found.</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>

        <!-- Pagination and Summary Footer -->
        <div style="display: flex; justify-content: space-between; align-items: center; padding: 15px 20px; background: #f8fafc; border-top: 1px solid var(--border);">
            <div style="font-size: 0.85rem; color: var(--text-muted);">
                Showing <?= $start_entry ?> to <?= $end_entry ?> of <?= $total_records ?> entries
            </div>
            <div class="pagination" style="display: flex; gap: 10px; align-items: center;">
                <?php if($page > 1): ?>
                    <a href="?page=<?= $page-1 ?>&limit=<?= $limit ?>&search=<?= urlencode($search) ?>&sort=<?= urlencode($sort) ?>&action=<?= urlencode($action_filter) ?>" class="btn-blue" style="padding: 5px 15px; font-size: 0.8rem; text-decoration: none;">Previous</a>
                <?php endif; ?>
                <span style="font-size: 0.85rem; font-weight: 600;">Page <?= $page ?> of <?= $total_pages ?></span>
                <?php if($page < $total_pages): ?>
                    <a href="?page=<?= $page+1 ?>&limit=<?= $limit ?>&search=<?= urlencode($search) ?>&sort=<?= urlencode($sort) ?>&action=<?= urlencode($action_filter) ?>" class="btn-blue" style="padding: 5px 15px; font-size: 0.8rem; text-decoration: none;">Next</a>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<script src="script.js"></script>
</body>
</html>