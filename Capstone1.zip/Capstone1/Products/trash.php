<?php 
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php?error=unauthorized");
    exit();
}
include '../db.php'; 

// Get Filter Parameters
$search = isset($_GET['search']) ? $conn->real_escape_string($_GET['search']) : '';
$limit  = isset($_GET['limit']) ? (int)$_GET['limit'] : 25;
$sort   = isset($_GET['sort']) ? $_GET['sort'] : 'name ASC';
$page   = isset($_GET['page']) ? (int)$_GET['page'] : 1;
if ($page < 1) $page = 1;


// Valid sorting options
$allowed_sorts = [
    'name ASC'      => 'Name (A-Z)',
    'name DESC'     => 'Name (Z-A)',
    'item_code ASC' => 'Item Code',
    'price DESC'    => 'Price (High-Low)'
];
if (!array_key_exists($sort, $allowed_sorts)) { $sort = 'name ASC'; }

// WHERE clause for deleted items
$where_sql = "WHERE is_deleted = 1 AND (name LIKE '%$search%' OR item_code LIKE '%$search%')";

// Count total records for pagination
$count_query = "SELECT COUNT(*) as total FROM products $where_sql";
$total_records = $conn->query($count_query)->fetch_assoc()['total'];
$total_pages = ceil($total_records / $limit);
if ($page > $total_pages && $total_pages > 0) $page = $total_pages;
$offset = ($page - 1) * $limit;

// Build Query for deleted items only
$query = "SELECT * FROM products $where_sql ORDER BY $sort LIMIT $limit OFFSET $offset";
$result = $conn->query($query);

$start_entry = ($total_records > 0) ? $offset + 1 : 0;
$end_entry = min($offset + $limit, $total_records);
?>

<!DOCTYPE html>
<html lang="en">
<head>
        <meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Trash Bin - IMS</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>

<nav class="navbar">
    <a href="#" class="navbar-brand">
    <img src="../Image/MGSLOGO.png" alt="MGS Logo" class="nav-logo">
</a>
    
    <input type="checkbox" id="nav-toggle" class="nav-toggle">
    <label for="nav-toggle" class="nav-toggle-label">
        <i class="fa-solid fa-bars"></i>
    </label>
    
    <ul class="navbar-links">
        <li><a href="../Dashboard/dashboard.php"><i class="fa-solid fa-gauge-high"></i> Dashboard</a></li>
        
        <li class="dropdown">
            <a href="javascript:void(0)" class="active">
                <i class="fa-solid fa-boxes-stacked"></i> Inventory <i class="fa-solid fa-caret-down"></i>
            </a>
            <div class="dropdown-content">
                <a href="../Products/products.php">All Products</a>
                <a href="../Products/logs.php">Logs</a>
                <a href="../Products/trash.php">Trash</a>
            </div>
        </li>

        <li><a href="../Stores/stores.php"><i class="fa-solid fa-store"></i> Stores</a></li>

        <li class="dropdown">
            <a href="javascript:void(0)">
                <i class="fa fa-exchange-alt"></i> Transaction <i class="fa-solid fa-caret-down"></i>
            </a>
             <div class="dropdown-content">
                <a href="../Transactions/transaction.php">Transaction</a>
                <a href="../Transactions/void_logs.php">Void Logs</a>
                <a href="../Transactions/transaction_logs.php">Transaction Logs</a>
                <a href="../Transactions/sales_report.php">Sales Report</a>
            </div>
        </li>

        <li><a href="../Expenses/expenses.php"><i class="fa-solid fa-wallet"></i> Expenses</a></li>

        <li>
            <a href="../logout.php" class="logout-link">
                <i class="fa-solid fa-right-from-bracket"></i> Logout
            </a>
        </li>
    </ul>
</nav>

<div class="main-layout">
    <div class="table-container">
        <div class="table-header">
            <span style="font-weight: 800; letter-spacing: -0.5px; text-transform: uppercase;">
                <i class="fa fa-boxes"></i> Deleted Products
            </span>
         <form action="" method="GET" style="display: flex; gap: 8px; align-items: center; flex-wrap: wrap;">

                <select name="limit" onchange="this.form.submit()">
                    <option value="10" <?= $limit == 10 ? 'selected' : ''; ?>>10</option>
                    <option value="25" <?= $limit == 25 ? 'selected' : ''; ?>>25</option>
                    <option value="50" <?= $limit == 50 ? 'selected' : ''; ?>>50</option>
                </select>

                <select name="sort" onchange="this.form.submit()">
                    <?php foreach($allowed_sorts as $val => $label): ?>
                        <option value="<?= $val ?>" <?= $sort == $val ? 'selected' : ''; ?>><?= $label ?></option>
                    <?php endforeach; ?>
                </select>

                <input type="text" name="search" placeholder="Search products..." value="<?= htmlspecialchars($search); ?>">
                <button type="submit" class="btn-blue" style="padding: 8px 15px;">Search</button>
                
                <?php if(!empty($search)): ?>
                    <a href="products.php" style="font-size: 0.8rem; color: var(--primary); text-decoration: none;">Clear</a>
                <?php endif; ?>
            </form>
        </div>
        <div style="overflow-x: auto;">
            <table>
                <thead>
                    <tr>
                        <th>Product Name</th>
                        <th>Item Code</th>
                        <th>Image</th>
                        <th>Price</th>
                        <th style="text-align: right;">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    if ($result->num_rows > 0) {
                        while ($row = $result->fetch_assoc()) {
                            $img = !empty($row['image']) ? $row['image'] : 'no-image.jpg';
                            echo "<tr>
                                    <td>" . htmlspecialchars($row['name']) . "</td>
                                    <td style='font-weight: 700; color: var(--text-main);'>{$row['item_code']}</td>
                                    <td><img src='uploads/$img' class='zoomable-img' style='width:40px; height:40px; object-fit:cover; border-radius:4px;'></td>
                                    <td style='color: var(--text-muted);'>₱" . number_format($row['price'], 2) . "</td>
                                    <td style='text-align: right;'>
                                        <a href='process_restore.php?id={$row['id']}' class='btn-blue' 
                                           style='background: var(--success); padding: 6px 12px; font-size: 0.8rem;'
                                           onclick=\"return confirm('Restore this item to active inventory?');\">
                                            <i class='fa fa-undo'></i> 
                                        </a>
                                    </td>
                                  </tr>";
                        }
                    } else {
                        echo "<tr><td colspan='5' style='text-align: center; padding: 40px; color: var(--text-muted);'>No deleted items found.</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>

        <!-- Pagination and Summary Footer -->
        <div style="display: flex; justify-content: space-between; align-items: center; padding: 15px 20px; background: #f8fafc; border-top: 1px solid var(--border);">
        <div style="font-size: 0.85rem; color: var(--text-muted);">
            Showing <?= $start_entry ?> to <?= $end_entry ?> of <?= $total_records ?> entries
        </div>
        <div class="pagination" style="display: flex; gap: 10px; align-items: center;">
            <?php if($page > 1): ?>
                <a href="?page=<?= $page-1 ?>&limit=<?= $limit ?>&search=<?= urlencode($search) ?>&sort=<?= $sort ?>" class="btn-blue" style="padding: 5px 15px; font-size: 0.8rem;">Previous</a>
            <?php endif; ?>
            <span style="font-size: 0.85rem; font-weight: 600;">Page <?= $page ?> of <?= $total_pages ?></span>
            <?php if($page < $total_pages): ?>
                <a href="?page=<?= $page+1 ?>&limit=<?= $limit ?>&search=<?= urlencode($search) ?>&sort=<?= $sort ?>" class="btn-blue" style="padding: 5px 15px; font-size: 0.8rem;">Next</a>
            <?php endif; ?>
        </div>
    </div>
    </div>
</div>

<div id="imageZoomModal" class="image-zoom-overlay">
    <span class="close-zoom">&times;</span>
    <img class="zoom-content" id="img01">
</div>

<script src="script.js"></script>
</body>
</html>