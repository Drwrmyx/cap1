// script.js

// 1. Declare variables globally (at the top of script.js) to store chart instances
let earningsChartInstance = null;
let paymentPieInstance = null;

// Navigation helper
function changeYear(year) {
    window.location.href = '?year=' + year;
}

function loadCharts() {
    const earningsCanvas = document.getElementById('earningsChart');
    const paymentCanvas = document.getElementById('paymentPie');
    
    if (!earningsCanvas || !paymentCanvas) return;

    const ctxEarnings = earningsCanvas.getContext('2d');
    const ctxPayment = paymentCanvas.getContext('2d');

    // 2. Destroy the existing Earnings Chart if it exists
    if (earningsChartInstance) {
        earningsChartInstance.destroy();
    }

    // 3. Destroy the existing Payment Pie Chart if it exists
    if (paymentPieInstance) {
        paymentPieInstance.destroy();
    }

    // 4. Create the new Earnings Chart and store it in the variable
    earningsChartInstance = new Chart(ctxEarnings, {
        type: 'line',
        data: {
            labels: dashboardData.months,
            datasets: [{
                label: 'Revenue',
                data: dashboardData.earnings,
                borderColor: '#4f46e5',
                backgroundColor: 'rgba(79, 70, 229, 0.1)',
                fill: true,
                tension: 0.4
            }, {
                label: 'Expenses',
                data: dashboardData.expenses,
                borderColor: '#ef4444',
                backgroundColor: 'rgba(239, 68, 68, 0.1)',
                fill: true,
                tension: 0.4
            }]
        },
    options: {
        responsive: true,
        maintainAspectRatio: false, // Allows the chart to fit the container height
        scales: {
            y: { beginAtZero: true }
        }
    }
});

// 5. Create the new Payment Pie Chart and store it in the variable
paymentPieInstance = new Chart(ctxPayment, {
        type: 'pie',
        data: {
            labels: ['Cash', 'POS', 'Transfer'],
            datasets: [{
                data: dashboardData.paymentData,
                backgroundColor: ['#22c55e', '#4f46e5', '#f59e0b']
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false
        }
    });
}

// Initialize charts on page load
document.addEventListener('DOMContentLoaded', loadCharts);

// Enhanced Mobile Dropdown Logic
document.addEventListener('DOMContentLoaded', () => {
    const dropdowns = document.querySelectorAll('.dropdown');
    
    dropdowns.forEach(dropdown => {
        // We target the main link (trigger) inside the dropdown li
        const trigger = dropdown.querySelector('.dropdown-trigger, a:first-child');
        
        if (trigger) {
            trigger.addEventListener('click', function(e) {
                // Only run this logic on mobile/tablet widths
                if (window.innerWidth <= 1024) {
                    
                    // 1. Prevent the page from jumping/navigating
                    e.preventDefault(); 
                    
                    // 2. Check if this specific one is already open
                    const isOpened = dropdown.classList.contains('show-mobile');
                    
                    // 3. Close ALL other dropdowns first (The Accordion Effect)
                    dropdowns.forEach(d => d.classList.remove('show-mobile'));
                    
                    // 4. If the one we clicked wasn't open, open it now
                    if (!isOpened) {
                        dropdown.classList.add('show-mobile');
                    }
                }
            });
        }
    });
});