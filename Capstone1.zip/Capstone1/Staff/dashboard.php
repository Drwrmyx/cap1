<?php 
include '../staff_auth.php'; 
include '../db.php'; 

// --- DATE & FILTER LOGIC ---
$available_years_res = $conn->query("SELECT DISTINCT YEAR(date_created) as year FROM transactions ORDER BY year DESC");
$years = [];
while($row = $available_years_res->fetch_assoc()) { $years[] = $row['year']; }
$selected_year = isset($_GET['year']) ? (int)$_GET['year'] : (count($years) > 0 ? $years[0] : date('Y'));

// --- OPERATIONAL KPI DATA ---
$today = date('Y-m-d');
// Only completed sales for today
$total_sales_today = $conn->query("SELECT COUNT(*) as total FROM transactions WHERE DATE(date_created) = '$today' AND status = 'completed'")->fetch_assoc()['total'] ?? 0;
// Only completed transactions all-time
$all_time_total = $conn->query("SELECT COUNT(*) as total FROM transactions WHERE status = 'completed'")->fetch_assoc()['total'] ?? 0;

$items_in_stock = $conn->query("SELECT SUM(stock) as total FROM products")->fetch_assoc()['total'] ?? 0;
$low_stock_count = $conn->query("SELECT COUNT(*) as total FROM products WHERE stock <= 15")->fetch_assoc()['total'] ?? 0;

$total_products = $conn->query("SELECT COUNT(*) as count FROM products WHERE is_deleted = 0")->fetch_assoc()['count'];
// --- FINANCIAL KPI DATA (NEW) ---
$sales_res = $conn->query("SELECT SUM(total_amount) as total FROM transactions WHERE status = 'completed'");
$total_revenue = $sales_res->fetch_assoc()['total'] ?? 0;

$expense_res = $conn->query("SELECT SUM(amount) as total FROM expenses");
$total_expenses = $expense_res->fetch_assoc()['total'] ?? 0;

$net_profit = $total_revenue - $total_expenses;

// --- Chart Data (Monthly Earnings & Expenses) ---
$months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

// 1. Fetch Monthly Earnings
$monthly_earnings = array_fill(0, 12, 0);
$earn_query = $conn->query("SELECT MONTH(date_created) as m, SUM(total_amount) as s FROM transactions WHERE YEAR(date_created) = $selected_year AND status = 'completed' GROUP BY m");
while($er = $earn_query->fetch_assoc()) { $monthly_earnings[$er['m']-1] = $er['s']; }

// 2. Fetch Monthly Expenses (NEW)
$monthly_expenses = array_fill(0, 12, 0);
$exp_query = $conn->query("SELECT MONTH(expense_date) as m, SUM(amount) as s FROM expenses WHERE YEAR(expense_date) = $selected_year GROUP BY m");
while($ex = $exp_query->fetch_assoc()) { $monthly_expenses[$ex['m']-1] = $ex['s']; }

// 3. Fetch Payment Methods
$pay_cash = $conn->query("SELECT COUNT(*) FROM transactions WHERE mode_of_payment='Cash' AND YEAR(date_created) = $selected_year AND status = 'completed'")->fetch_row()[0];
$pay_pos = $conn->query("SELECT COUNT(*) FROM transactions WHERE mode_of_payment='POS' AND YEAR(date_created) = $selected_year AND status = 'completed'")->fetch_row()[0];
$pay_transfer = $conn->query("SELECT COUNT(*) FROM transactions WHERE mode_of_payment='Transfer' AND YEAR(date_created) = $selected_year AND status = 'completed'")->fetch_row()[0];
?>

<!DOCTYPE html>
<html lang="en">
<head>
        <meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Management Dashboard</title>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="../Dashboard/style.css">
</head>
<body>

<nav class="navbar">
    <a href="#" class="navbar-brand">
    <img src="../Image/MGSLOGO.png" alt="MGS Logo" class="nav-logo">
</a>
    
    <input type="checkbox" id="nav-toggle" class="nav-toggle">
    <label for="nav-toggle" class="nav-toggle-label">
        <i class="fa-solid fa-bars"></i>
    </label>
    
<ul class="navbar-links">
    <li><a href="dashboard.php" class="active">Dashboard</a></li>

    <li><a href="transaction.php">Transaction</a></li>

    <li><a href="../logout.php">Logout</a></li>
</ul>
</nav>



<div class="kpi-row">
        <div class="kpi-card" style="color: black;">
            <i class="fa fa-box" style="color: black;"></i>
            <h1><?= $total_products ?></h1>
            <p>Total Products</p>
        </div>
        <div class="kpi-card" style="color: black;">
            <i class="fa fa-receipt" style="color: black;"></i>
            <h1><?= $all_time_total ?></h1>
            <p>Total Transactions</p>
        </div>
        <div class="kpi-card" style="color: black;">
            <i class="fa fa-boxes" style="color: black;"></i>
            <h1><?= $items_in_stock ?></h1>
            <p>Current Stock</p>
        </div>
        <div class="kpi-card " style="color: black;">
            <i class="fa fa-exclamation-triangle" style="color: black;"></i>
            <h1><?= $low_stock_count ?></h1>
            <p>Low Stock Alert</p>
        </div>
    </div>

    <div class="kpi-row" style="margin-top: 20px;">
        <div class="kpi-card" style="color: black;">
            <i class="fa fa-shopping-basket" style="color: black;"></i>
            <h1><?= $total_sales_today ?></h1>
            <p>Sales Today</p>
        </div>
        <div class="kpi-card" style="color: black;">
            <i class="fa fa-money-bill-wave" style="color: black;"></i>
            <h1>₱<?= number_format($total_revenue, 2) ?></h1>
            <p>Total Revenue</p>
        </div>
        <div class="kpi-card" style="color: black;">
            <i class="fa fa-wallet" style="color: black;"></i>
            <h1>₱<?= number_format($total_expenses, 2) ?></h1>
            <p>Total Expenses</p>
        </div>
        <div class="kpi-card" style="color: black;">
            <i class="fa fa-chart-line" style="color: black;"></i>
            <h1>₱<?= number_format($net_profit, 2) ?></h1>
            <p>Net Profit</p>
        </div>

    </div>

    <div class="top-bar">
        <div>
            <label style="font-weight:bold;">Select Account Year: </label>
            <select onchange="changeYear(this.value)">
                <?php foreach($years as $yr): ?>
                    <option value="<?= $yr ?>" <?= ($yr == $selected_year) ? 'selected' : '' ?>><?= $yr ?></option>
                <?php endforeach; ?>
                <?php if(count($years) == 0): ?><option><?= date('Y') ?></option><?php endif; ?>
            </select>
        </div>
    </div>


<div class="main-grid">
        <div class="chart-container">
            <h4>Earnings vs Expenses (<?= $selected_year ?>)</h4> <canvas id="earningsChart"></canvas>
        </div>
        <div class="pie-container">
            <h4>Payments (%)</h4>
            <canvas id="paymentPie"></canvas>
        </div>
    </div>

    <div class="table-area" style="margin-bottom: 20px;">
        <div class="table-header" style="background: #d9534f;">
            <i class="fa fa-list"></i> Critical Stock Alert (Items to Reorder)
        </div>
        <table>
            <thead>
                <tr>
                    <th>Item Code</th>
                    <th>Product Name</th>
                    <th>Current Stock</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php 
                // UPDATED: Threshold set to 15
                $threshold = 15;
                $critical_sql = "SELECT item_code, name, stock FROM products WHERE stock <= $threshold ORDER BY stock ASC";
                $critical_res = $conn->query($critical_sql);

                if ($critical_res && $critical_res->num_rows > 0) {
                    while($row = $critical_res->fetch_assoc()) {
                        // Logic for labels
                        if ($row['stock'] == 0) {
                            $status_label = 'OUT OF STOCK';
                            $label_bg = '#000';
                        } elseif ($row['stock'] <= 5) {
                            $status_label = 'CRITICAL';
                            $label_bg = '#d9534f';
                        } else {
                            $status_label = 'LOW STOCK';
                            $label_bg = '#f0ad4e'; // Orange for 6-15 items
                        }
                        ?>
                        <tr>
                            <td><strong><?= htmlspecialchars($row['item_code']) ?></strong></td>
                            <td><?= htmlspecialchars($row['name']) ?></td>
                            <td style="color: <?= ($row['stock'] <= 5) ? '#d9534f' : '#333' ?>; font-weight: bold;">
                                <?= $row['stock'] ?>
                            </td>
                            <td>
                                <span style="background: <?= $label_bg ?>; color: white; padding: 2px 8px; border-radius: 3px; font-size: 10px; font-weight: bold;">
                                    <?= $status_label ?>
                                </span>
                            </td>
                        </tr>
                        <?php
                    }
                } else {
                    echo '<tr><td colspan="4" style="text-align:center; padding: 20px; color: #777;">Stock levels are healthy (All items above 15).</td></tr>';
                }
                ?>
            </tbody>
        </table>
    </div>

    <div class="report-grid">
        <div class="table-area">
            <div class="table-header"><i class="fa fa-fire" style="color: #e67e22;"></i> High in Demand</div>
            <table>
                <thead><tr><th>Item</th><th>Qty Sold</th></tr></thead>
                <tbody>
                <?php 
                $high_demand = $conn->query("SELECT name, total_sold FROM products ORDER BY total_sold DESC LIMIT 5");
                while($r = $high_demand->fetch_assoc()) echo "<tr><td>{$r['name']}</td><td>{$r['total_sold']}</td></tr>"; 
                ?>
                </tbody>
            </table>
        </div>
        <div class="table-area">
            <div class="table-header"><i class="fa fa-money-bill-trend-up" style="color: #27ae60;"></i> Highest Earning</div>
            <table>
                <thead><tr><th>Item</th><th>Total Earned</th></tr></thead>
                <tbody>
                    <?php $earn = $conn->query("SELECT name, total_earned_on_item FROM products ORDER BY total_earned_on_item DESC LIMIT 5");
                    while($r = $earn->fetch_assoc()) echo "<tr><td>{$r['name']}</td><td>₱".number_format($r['total_earned_on_item'], 2)."</td></tr>"; ?>
                </tbody>
            </table>
        </div>
    </div>

    <div class="report-grid">
        <div class="table-area">
            <div class="table-header"><i class="fa fa-arrow-trend-down" style="color: #e74c3c;"></i> Low in Demand</div>
            <table>
                <thead><tr><th>Item</th><th>Qty Sold</th></tr></thead>
                <tbody>
                    <?php $low_demand = $conn->query("SELECT name, total_sold FROM products ORDER BY total_sold ASC LIMIT 5");
                    while($r = $low_demand->fetch_assoc()) echo "<tr><td>{$r['name']}</td><td>{$r['total_sold']}</td></tr>"; ?>
                </tbody>
            </table>
        </div>
        <div class="table-area">
            <div class="table-header"><i class="fa fa-money-bill-transfer" style="color: #95a5a6;"></i> Lowest Earning</div>
            <table>
                <thead><tr><th>Item</th><th>Total Earned</th></tr></thead>
                <tbody>
                    <?php $low_earn = $conn->query("SELECT name, total_earned_on_item FROM products ORDER BY total_earned_on_item ASC LIMIT 5");
                    while($r = $low_earn->fetch_assoc()) echo "<tr><td>{$r['name']}</td><td>₱".number_format($r['total_earned_on_item'], 2)."</td></tr>"; ?>
                </tbody>
            </table>
        </div>
    </div>

    <div class="table-area" style="margin-top: 24px;">
        <div class="table-header"><i class="fa fa-calculator"></i> Daily Profit & Loss (Last 5 Days)</div>
        <table>
            <thead>
                <tr><th>Date</th><th>Sales</th><th>Expenses</th><th>Net Profit</th></tr>
            </thead>
            <tbody>
                <?php 
                $daily_pn_l = $conn->query("
                    SELECT date_summary.d, IFNULL(sales.total_sales, 0) as total_sales, IFNULL(expenses.total_expenses, 0) as total_expenses
                    FROM (SELECT DATE(date_created) as d FROM transactions WHERE status = 'completed' UNION SELECT expense_date as d FROM expenses) as date_summary
                    LEFT JOIN (SELECT DATE(date_created) as d, SUM(total_amount) as total_sales FROM transactions WHERE status = 'completed' GROUP BY d) sales ON date_summary.d = sales.d
                    LEFT JOIN (SELECT expense_date as d, SUM(amount) as total_expenses FROM expenses GROUP BY expense_date) expenses ON date_summary.d = expenses.d
                    WHERE YEAR(date_summary.d) = $selected_year ORDER BY date_summary.d DESC LIMIT 5
                ");
                while($row = $daily_pn_l->fetch_assoc()): 
                    $daily_net = $row['total_sales'] - $row['total_expenses']; ?>
                    <tr>
                        <td><strong><?= date('M d, Y', strtotime($row['d'])) ?></strong></td>
                        <td style="color: #27ae60;">₱<?= number_format($row['total_sales'], 2) ?></td>
                        <td style="color: #e74c3c;">₱<?= number_format($row['total_expenses'], 2) ?></td>
                        <td style="font-weight: bold; color: <?= ($daily_net >= 0) ? '#2980b9' : '#e74c3c' ?>;">₱<?= number_format($daily_net, 2) ?></td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>

    <div class="report-grid">
        <div class="table-area">
            <div class="table-header"><i class="fa fa-calendar-week"></i> Weekly Performance (Top 5 Days)</div>
            <table>
                <thead><tr><th>Day</th><th>Trans</th><th>Earned</th></tr></thead>
                <tbody>
                    <?php 
                    $days_rep = $conn->query("SELECT DAYNAME(date_created) as day, COUNT(*) as c, SUM(total_amount) as s FROM transactions WHERE status = 'completed' AND YEAR(date_created) = $selected_year GROUP BY day ORDER BY s DESC LIMIT 5");
                    while($r = $days_rep->fetch_assoc()): ?>
                        <tr><td><?php echo $r['day']; ?></td><td><?php echo $r['c']; ?></td><td>₱<?php echo number_format($r['s'], 2); ?></td></tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
        <div class="table-area">
            <div class="table-header"><i class="fa fa-calendar-alt"></i> Monthly Summary (Last 5 Months)</div>
            <table>
                <thead><tr><th>Month</th><th>Trans</th><th>Earned</th></tr></thead>
                <tbody>
                    <?php 
                    $months_rep = $conn->query("SELECT MONTHNAME(date_created) as m, COUNT(*) as c, SUM(total_amount) as s FROM transactions WHERE status = 'completed' AND YEAR(date_created) = $selected_year GROUP BY m ORDER BY MONTH(date_created) DESC LIMIT 5");
                    while($r = $months_rep->fetch_assoc()): ?>
                        <tr><td><?php echo $r['m']; ?></td><td><?php echo $r['c']; ?></td><td>₱<?php echo number_format($r['s'], 2); ?></td></tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>

    <div class="table-area" style="margin-top: 24px;">
        <div class="table-header"><i class="fa fa-history"></i> Yearly Summary (Last 5 Years)</div>
        <table>
            <thead><tr><th>Year</th><th>Total Transactions</th><th>Total Earned</th></tr></thead>
            <tbody>
                <?php 
                $years_rep = $conn->query("SELECT YEAR(date_created) as y, COUNT(*) as c, SUM(total_amount) as s FROM transactions WHERE status = 'completed' GROUP BY y ORDER BY y DESC LIMIT 5");
                while($r = $years_rep->fetch_assoc()): ?>
                    <tr><td><strong><?php echo $r['y']; ?></strong></td><td><?php echo $r['c']; ?> trans.</td><td>₱<?php echo number_format($r['s'], 2); ?></td></tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script>
        const dashboardData = {
            months: <?= json_encode($months) ?>,
            earnings: <?= json_encode($monthly_earnings) ?>,
            expenses: <?= json_encode($monthly_expenses) ?>,
            paymentData: [<?= "$pay_cash, $pay_pos, $pay_transfer" ?>]
        };
    </script>
    <script src="../Dashboard/script.js"></script>
</body>
</html>