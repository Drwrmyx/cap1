<?php
// Capstone1/Expenses/process_expense.php
session_start();
include '../db.php';
include '../auth.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id   = isset($_POST['id']) ? (int)$_POST['id'] : 0;
    $date = $_POST['expense_date'];
    $cat  = $_POST['category'];
    $amt  = floatval($_POST['amount']);
    $desc = trim($_POST['description']);

    if ($amt <= 0) {
        $_SESSION['alert_message'] = "Amount must be greater than zero.";
        $_SESSION['alert_type'] = "error";
    } else {
        if ($id > 0) {
            // Update existing record
            $stmt = $conn->prepare("UPDATE expenses SET category=?, amount=?, description=?, expense_date=? WHERE id=?");
            $stmt->bind_param("sdssi", $cat, $amt, $desc, $date, $id);
            $msg = "Expense updated successfully!";
        } else {
            // Insert new record
            $stmt = $conn->prepare("INSERT INTO expenses (category, amount, description, expense_date) VALUES (?, ?, ?, ?)");
            $stmt->bind_param("sdss", $cat, $amt, $desc, $date);
            $msg = "Expense recorded successfully!";
        }
        
        if ($stmt->execute()) {
            $_SESSION['alert_message'] = $msg;
            $_SESSION['alert_type'] = "success";
        }
    }
    header("Location: expenses.php");
    exit();
}
?>