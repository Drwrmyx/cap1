<?php
// Capstone1/Expenses/delete_expense.php
session_start();
include '../db.php';
include '../auth.php';

if (isset($_GET['id'])) {
    $id = (int)$_GET['id'];
    $stmt = $conn->prepare("DELETE FROM expenses WHERE id = ?");
    $stmt->bind_param("i", $id);

    if ($stmt->execute()) {
        $_SESSION['alert_message'] = "Expense deleted successfully!";
        $_SESSION['alert_type'] = "success";
    } else {
        $_SESSION['alert_message'] = "Error deleting record: " . $conn->error;
        $_SESSION['alert_type'] = "error";
    }
}
header("Location: expenses.php");
exit();
?>