/**
 * EXPENSES MODULE SCRIPT
 */

/**
 * Opens the Add Expense Modal and resets all fields to default.
 */
function openAddModal() { 
    const modal = document.getElementById('addModal');
    if (!modal) return;

    // Reset Title and Button Text
    document.getElementById('modalTitle').innerText = "Record New Expense";
    document.getElementById('submitBtn').innerText = "Save Expense";

    // Clear hidden ID and input fields
    document.getElementById('expense_id').value = "";
    document.getElementById('exp_desc').value = "";
    document.getElementById('exp_amt').value = "";
    
    // Set default date to today
    const today = new Date().toISOString().split('T')[0];
    document.getElementById('exp_date').value = today;

    modal.style.display = 'block'; 
}

/**
 * Opens the Edit Expense Modal and populates it with existing data.
 * @param {Object} data - The expense record from the database.
 */
function openEditModal(data) {
    const modal = document.getElementById('addModal');
    if (!modal) return;

    // Update Title and Button Text
    document.getElementById('modalTitle').innerText = "Edit Expense";
    document.getElementById('submitBtn').innerText = "Update Expense";

    // Populate fields with existing record data
    document.getElementById('expense_id').value = data.id;
    document.getElementById('exp_date').value = data.expense_date;
    document.getElementById('exp_cat').value = data.category;
    document.getElementById('exp_amt').value = data.amount;
    document.getElementById('exp_desc').value = data.description;

    modal.style.display = 'block';
}

/**
 * Closes the expense modal.
 */
function closeModal() { 
    const modal = document.getElementById('addModal');
    if (modal) modal.style.display = 'none'; 
}

/**
 * Close modal if the user clicks outside of the modal content box.
 */
window.onclick = function(event) {
    const modal = document.getElementById('addModal');
    if (event.target == modal) {
        closeModal();
    }
}

/**
 * Mobile Dropdown Accordion Logic
 * Shared across Dashboard, Products, and Stores
 */
document.addEventListener('DOMContentLoaded', () => {
    const dropdowns = document.querySelectorAll('.dropdown');
    
    dropdowns.forEach(dropdown => {
        const trigger = dropdown.querySelector('a');
        
        if (trigger) {
            trigger.addEventListener('click', function(e) {
                if (window.innerWidth <= 1024) {
                    // Prevent navigation so the menu can expand
                    e.preventDefault(); 
                    
                    const isOpened = dropdown.classList.contains('show-mobile');
                    
                    // Close other open dropdowns (Accordion Effect)
                    dropdowns.forEach(d => d.classList.remove('show-mobile'));
                    
                    // Toggle current selection
                    if (!isOpened) {
                        dropdown.classList.add('show-mobile');
                    }
                }
            });
        }
    });
});