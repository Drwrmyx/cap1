<?php
include '../admin_auth.php'; 
include '../db.php';

// --- Filter & Pagination Logic ---
$search = isset($_GET['search']) ? $conn->real_escape_string($_GET['search']) : '';
$limit  = isset($_GET['limit']) ? (int)$_GET['limit'] : 10;
$sort   = isset($_GET['sort']) ? $_GET['sort'] : 'expense_date DESC';
$page   = isset($_GET['page']) ? (int)$_GET['page'] : 1;
if ($page < 1) $page = 1;

$cat_filter = isset($_GET['category']) ? $conn->real_escape_string($_GET['category']) : '';
$month_filter = isset($_GET['month']) ? $conn->real_escape_string($_GET['month']) : '';

$allowed_sorts = [
    'expense_date DESC' => 'Newest First',
    'expense_date ASC'  => 'Oldest First',
    'amount DESC'       => 'Highest Amount',
    'amount ASC'        => 'Lowest Amount',
];

$where_clauses = ["1=1"];
if (!empty($search)) {
    $where_clauses[] = "(description LIKE '%$search%' OR category LIKE '%$search%')";
}
if (!empty($cat_filter)) {
    $where_clauses[] = "category = '$cat_filter'";
}
if (!empty($month_filter)) {
    $where_clauses[] = "expense_date LIKE '$month_filter%'";
}

$where_sql = implode(' AND ', $where_clauses);

// Pagination Calculations
$count_query = "SELECT COUNT(*) as total FROM expenses WHERE $where_sql";
$total_records = $conn->query($count_query)->fetch_assoc()['total'];
$total_pages = ceil($total_records / $limit);
if ($page > $total_pages && $total_pages > 0) $page = $total_pages;
$offset = ($page - 1) * $limit;

// Main Data Query
$query = "SELECT * FROM expenses WHERE $where_sql ORDER BY $sort LIMIT $limit OFFSET $offset";
$result = $conn->query($query);

// Filtered Total Calculation
$total_query = $conn->query("SELECT SUM(amount) as total FROM expenses WHERE $where_sql");
$filtered_total = $total_query->fetch_assoc()['total'] ?? 0;

$start_entry = ($total_records > 0) ? $offset + 1 : 0;
$end_entry = min($offset + $limit, $total_records);

$categories = ['Payroll', 'Fuel', 'Gate Fee', 'Utilities', 'Maintenance', 'Other'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
        <meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Expense Management</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="style.css"> 
</head>
<body>

<nav class="navbar">
    <a href="#" class="navbar-brand">
    <img src="../Image/MGSLOGO.png" alt="MGS Logo" class="nav-logo">
</a>
    <input type="checkbox" id="nav-toggle" class="nav-toggle">
    <label for="nav-toggle" class="nav-toggle-label"><i class="fa-solid fa-bars"></i></label>
    
    <ul class="navbar-links">
        <li><a href="../Dashboard/dashboard.php"><i class="fa-solid fa-gauge-high"></i> Dashboard</a></li>
        <li class="dropdown">
            <a href="javascript:void(0)" class="dropdown-trigger">
                <i class="fa-solid fa-boxes-stacked"></i> Inventory <i class="fa-solid fa-caret-down"></i>
            </a>
            <div class="dropdown-content">
                <a href="../Products/products.php">All Products</a>
                <a href="../Products/logs.php">Logs</a>
                <a href="../Products/trash.php">Trash</a>
            </div>
        </li>
        <li><a href="../Stores/stores.php"><i class="fa-solid fa-store"></i> Stores</a></li>
        <li class="dropdown">
            <a href="javascript:void(0)">
                <i class="fa-solid fa-exchange-alt"></i> Transaction <i class="fa-solid fa-caret-down"></i>
            </a>
            <div class="dropdown-content">
                <a href="../Transactions/transaction.php">Transaction</a>
                <a href="../Transactions/void_logs.php">Void Logs</a>
                <a href="../Transactions/transaction_logs.php">Transaction Logs</a>
                <a href="../Transactions/sales_report.php">Sales Report</a>
            </div>
            </div>
        </li>
        <li><a href="expenses.php" class="active"><i class="fa-solid fa-wallet" ></i> Expenses</a></li>
        <li><a href="../logout.php" class="logout-link"><i class="fa-solid fa-right-from-bracket"></i> Logout</a></li>
    </ul>
</nav>

<div class="main-layout">
    <?php if (isset($_SESSION['alert_message'])): ?>
        <div class="alert-container">
            <div id="sys-alert" class="sys-alert <?= ($_SESSION['alert_type'] === 'error') ? 'alert-error' : 'alert-success'; ?>">
                <i class="fa <?= ($_SESSION['alert_type'] === 'error') ? 'fa-exclamation-circle' : 'fa-check-circle'; ?>"></i>
                <?= $_SESSION['alert_message']; ?>
            </div>
        </div>
        <script>setTimeout(() => { document.getElementById('sys-alert').style.display = 'none'; }, 3000);</script>
        <?php unset($_SESSION['alert_message']); unset($_SESSION['alert_type']); ?>
    <?php endif; ?>

    <div class="controls-row">
        <button class="btn btn-blue" onclick="openAddModal()">
            <i class="fa fa-plus"></i> Add New Expense
        </button>
    </div>

    <div class="table-container">
        <div class="table-header">
            <span style="font-weight: 800; letter-spacing: -0.5px; text-transform: uppercase;">
                <i class="fa fa-boxes"></i> Product Inventory
            </span>
         <form action="" method="GET" style="display: flex; gap: 8px; align-items: center; flex-wrap: wrap;">
                <input type="month" name="month" value="<?= $month_filter ?>" onchange="this.form.submit()">

                <select name="limit" onchange="this.form.submit()">
                    <option value="10" <?= $limit == 10 ? 'selected' : ''; ?>>10</option>
                    <option value="25" <?= $limit == 25 ? 'selected' : ''; ?>>25</option>
                    <option value="50" <?= $limit == 50 ? 'selected' : ''; ?>>50</option>
                </select>


                <select name="category" onchange="this.form.submit()">
                    <option value="">Categories</option>
                    <?php foreach($categories as $cat): ?>
                        <option value="<?= $cat ?>" <?= $cat_filter == $cat ? 'selected' : '' ?>><?= $cat ?></option>
                    <?php endforeach; ?>
                </select>


                <select name="sort" onchange="this.form.submit()">
                    <?php foreach($allowed_sorts as $val => $label): ?>
                        <option value="<?= $val; ?>" <?= $sort == $val ? 'selected' : ''; ?>><?= $label; ?></option>
                    <?php endforeach; ?>
                </select>

                <input type="text" name="search" placeholder="Search products..." value="<?= htmlspecialchars($search); ?>">
                <button type="submit" class="btn-blue" style="padding: 8px 15px;">Search</button>
                
                <?php if(!empty($search)): ?>
                    <a href="products.php" style="font-size: 0.8rem; color: var(--primary); text-decoration: none;">Clear</a>
                <?php endif; ?>
            </form>
        </div>
        <div style="overflow-x: auto;">
            <table>
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Category</th>
                        <th>Description</th>
                        <th>Amount</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while($row = $result->fetch_assoc()): ?>
                    <tr>
                        <td><?= date('M d, Y', strtotime($row['expense_date'])) ?></td>
                        <td><span class="badge" style="background: #e2e8f0; color: #475569; padding: 4px 8px; border-radius: 5px; font-size: 0.75rem; font-weight: 700;"><?= $row['category'] ?></span></td>
                        <td><?= htmlspecialchars($row['description']) ?></td>
                        <td style="font-weight: 700;">₱<?= number_format($row['amount'], 2) ?></td>
                        <td>
                            <a href="javascript:void(0)" onclick='openEditModal(<?php echo json_encode($row); ?>)' style="color: var(--primary);">
                                <i class="fa fa-pencil"></i>
                            </a>
                            <a href="delete_expense.php?id=<?= $row['id'] ?>" onclick="return confirm('Delete record?')" style="color: var(--danger);"><i class="fa fa-trash"></i></a>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>

        <!-- Pagination and Summary Footer -->
        <div style="display: flex; justify-content: space-between; align-items: center; padding: 15px 20px; background: #f8fafc; border-top: 1px solid var(--border);">
            <div style="font-size: 0.85rem; color: var(--text-muted);">
                Showing <?= $start_entry ?> to <?= $end_entry ?> of <?= $total_records ?> entries
            </div>
            <div class="pagination" style="display: flex; gap: 10px; align-items: center;">
                <?php if($page > 1): ?>
                    <a href="?page=<?= $page-1 ?>&limit=<?= $limit ?>&search=<?= urlencode($search) ?>&sort=<?= urlencode($sort) ?>&category=<?= urlencode($cat_filter) ?>&month=<?= urlencode($month_filter) ?>" class="btn-blue" style="padding: 5px 15px; font-size: 0.8rem; text-decoration: none;">Previous</a>
                <?php endif; ?>
                <span style="font-size: 0.85rem; font-weight: 600;">Page <?= $page ?> of <?= $total_pages ?></span>
                <?php if($page < $total_pages): ?>
                    <a href="?page=<?= $page+1 ?>&limit=<?= $limit ?>&search=<?= urlencode($search) ?>&sort=<?= urlencode($sort) ?>&category=<?= urlencode($cat_filter) ?>&month=<?= urlencode($month_filter) ?>" class="btn-blue" style="padding: 5px 15px; font-size: 0.8rem; text-decoration: none;">Next</a>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<div id="addModal" class="modal">
    <div class="modal-content">
        <div class="modal-header" id="modalTitle">Record New Expense</div>
        
        <form action="process_expense.php" method="POST">
            <input type="hidden" name="id" id="expense_id">
            
            <div class="modal-body">
                <div class="modal-grid">
                    <div>
                        <label>Date</label>
                        <input type="date" name="expense_date" id="exp_date" value="<?= date('Y-m-d') ?>" required>
                    </div>
                    <div>
                        <label>Category</label>
                        <select name="category" id="exp_cat" required>
                            <?php foreach($categories as $cat) echo "<option value='$cat'>$cat</option>"; ?>
                        </select>
                    </div>
                    <div class="full-width">
                        <label>Amount (₱)</label>
                        <input type="number" step="0.01" name="amount" id="exp_amt" min="0.01" required>
                    </div>
                    <div class="full-width">
                        <label>Description</label>
                        <input type="text" name="description" id="exp_desc" placeholder="Optional details...">
                    </div>
                </div>
            </div>

            <div class="modal-footer">
                <button type="button" class="btn btn-red" onclick="closeModal()">Cancel</button>
                <button type="submit" class="btn btn-blue" id="submitBtn">Save Expense</button>
            </div>
        </form>
    </div>
</div>

<div id="addModal" class="modal">
    <div class="modal-content">
        <div class="modal-header" id="modalTitle">Record New Expense</div>
        <form action="process_expense.php" method="POST">
            <input type="hidden" name="id" id="expense_id">
            
            <div class="modal-grid" style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px; margin-top: 15px;">
                <div>
                    <label>Date</label>
                    <input type="date" name="expense_date" id="exp_date" value="<?= date('Y-m-d') ?>" required>
                </div>
                <div>
                    <label>Category</label>
                    <select name="category" id="exp_cat" required>
                        <?php foreach($categories as $cat) echo "<option value='$cat'>$cat</option>"; ?>
                    </select>
                </div>
                <div style="grid-column: span 2;">
                    <label>Amount (₱)</label>
                    <input type="number" step="0.01" name="amount" id="exp_amt" min="0.01" required>
                </div>
                <div style="grid-column: span 2;">
                    <label>Description</label>
                    <input type="text" name="description" id="exp_desc" placeholder="Optional details...">
                </div>
            </div>
            <div class="modal-footer" style="margin-top: 20px; text-align: right;">
                <button type="button" class="btn btn-red" onclick="closeModal()">Cancel</button>
                <button type="submit" class="btn btn-blue" id="submitBtn">Save Expense</button>
            </div>
        </form>
    </div>
</div>

<script src="script.js"></script>

</body>
</html>