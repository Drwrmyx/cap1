<?php
session_start();
// If not logged in OR role is not staff, kick them out
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'staff') {
    header("Location: ../../login.php");
    exit();
}
?>