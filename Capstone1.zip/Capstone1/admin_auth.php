<?php
include 'auth.php'; // Ensure they are logged in

if ($_SESSION['role'] !== 'admin') {
    // Point this to the exact path of your new error page
    header("Location: /Capstone1/permission_denied.php");
    exit();
}
?>