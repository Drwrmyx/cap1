<?php
// Transactions/functions.php

/**
 * Generates a unique Receipt Number
 */
function generateReceiptNo() {
    return "REC-" . strtoupper(substr(uniqid(), 7));
}

/**
 * Formats a number into Philippine Peso format
 */
function formatPeso($amount) {
    return "₱" . number_format($amount, 2);
}

/**
 * Logs a transaction event (e.g., Voiding or New Sale)
 * Note: You would need a 'transaction_audit' table for this
 */
function logTransactionActivity($conn, $tx_id, $action, $user) {
    // Optional: Add logic here to record who did what to which transaction
}
?>

<?php
// Transactions/functions.php

/**
 * Calculates the VAT amount based on a subtotal and percentage
 */
function calculateVATAmount($subtotal, $vatPercent) {
    if ($vatPercent <= 0) return 0;
    return $subtotal * ($vatPercent / 100);
}

// ... your other functions (formatPeso, generateReceiptNo) ...