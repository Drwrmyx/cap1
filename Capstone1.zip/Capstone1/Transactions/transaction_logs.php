<?php
include '../admin_auth.php';
include '../db.php'; 
include 'functions.php';

// Filter logic
$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$status = isset($_GET['status']) ? $_GET['status'] : '';
$date   = isset($_GET['date']) ? $_GET['date'] : '';
$limit  = isset($_GET['limit']) ? (int)$_GET['limit'] : 10;
$sort   = isset($_GET['sort']) ? $_GET['sort'] : 'date_desc';
$page   = isset($_GET['page']) ? (int)$_GET['page'] : 1;
if ($page < 1) $page = 1;

$offset = ($page - 1) * $limit;

$sort_options = [
    'date_desc'   => "t.date_created DESC",
    'date_asc'    => "t.date_created ASC",
    'amount_high' => "t.total_amount DESC",
    'amount_low'  => "t.total_amount ASC",
    'name_asc'    => "t.customer_name ASC"
];
$sort_sql = $sort_options[$sort] ?? "t.date_created DESC";

$where_clauses = ["1=1"];
$params = [];
$types = "";

if (!empty($search)) {
    $where_clauses[] = "(t.receipt_no LIKE ? OR t.customer_name LIKE ?)";
    $search_param = "%$search%";
    $params[] = &$search_param; $params[] = &$search_param;
    $types .= "ss";
}
if (!empty($status)) {
    $where_clauses[] = "t.status = ?";
    $params[] = &$status;
    $types .= "s";
}
if (!empty($date)) {
    $where_clauses[] = "DATE(t.date_created) = ?";
    $params[] = &$date;
    $types .= "s";
}
$where_sql = implode(" AND ", $where_clauses);

// Count total records for pagination
$count_stmt = $conn->prepare("SELECT COUNT(*) as total FROM transactions t WHERE $where_sql");
if (!empty($params)) { $count_stmt->bind_param($types, ...$params); }
$count_stmt->execute();
$total_records = $count_stmt->get_result()->fetch_assoc()['total'];
$total_pages = ceil($total_records / $limit);
if ($page > $total_pages && $total_pages > 0) $page = $total_pages;

$start_entry = ($total_records > 0) ? $offset + 1 : 0;
$end_entry = min($offset + $limit, $total_records);

// Final query with sorting and pagination
$query_str = "SELECT t.*, u.username as staff_name 
              FROM transactions t 
              LEFT JOIN users u ON t.user_id = u.id 
              WHERE $where_sql 
              ORDER BY $sort_sql 
              LIMIT $limit OFFSET $offset";

$stmt = $conn->prepare($query_str);
if (!empty($params)) { $stmt->bind_param($types, ...$params); }
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
        <meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Transaction Logs</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="style.css">
    <style>
        .badge { padding: 4px 8px; border-radius: 4px; font-size: 0.75rem; font-weight: bold; color: white; }
        .badge-completed { background-color: var(--success); }
        .badge-voided { background-color: var(--danger); }
    </style>
</head>
<body>

<nav class="navbar">
    <a href="#" class="navbar-brand">
    <img src="../Image/MGSLOGO.png" alt="MGS Logo" class="nav-logo">
</a>
    
    <input type="checkbox" id="nav-toggle" class="nav-toggle">
    <label for="nav-toggle" class="nav-toggle-label">
        <i class="fa-solid fa-bars"></i>
    </label>
    
    <ul class="navbar-links">
        <li><a href="../Dashboard/dashboard.php"><i class="fa-solid fa-gauge-high"></i> Dashboard</a></li>
        
        <li class="dropdown">
            <a href="javascript:void(0)" >
                <i class="fa-solid fa-boxes-stacked"></i> Inventory <i class="fa-solid fa-caret-down"></i>
            </a>
            <div class="dropdown-content">
                <a href="../Products/products.php">All Products</a>
                <a href="../Products/logs.php">Logs</a>
                <a href="../Products/trash.php">Trash</a>
            </div>
        </li>

        <li><a href="../Stores/stores.php"><i class="fa-solid fa-store"></i> Stores</a></li>

        <li class="dropdown">
            <a href="javascript:void(0)" class="active">
                <i class="fa fa-exchange-alt"></i> Transaction <i class="fa-solid fa-caret-down"></i>
            </a>
            <div class="dropdown-content">
                <a href="../Transactions/transaction.php">Transaction</a>
                <a href="../Transactions/void_logs.php">Void Logs</a>
                <a href="../Transactions/transaction_logs.php">Transaction Logs</a>
                <a href="../Transactions/sales_report.php">Sales Report</a>
            </div>
        </li>

        <li><a href="../Expenses/expenses.php"><i class="fa-solid fa-wallet"></i> Expenses</a></li>

        <li>
            <a href="../logout.php" class="logout-link">
                <i class="fa-solid fa-right-from-bracket"></i> Logout
            </a>
        </li>
    </ul>
</nav>

<div class="main-layout">
    <div class="table-container">
        <div class="table-header">
            <span style="font-weight: 800; letter-spacing: -0.5px; text-transform: uppercase;">
                <i class="fa fa-boxes"></i> Transaction History
            </span>
            <form action="" method="GET" style="display: flex; gap: 8px; align-items: center; flex-wrap: wrap;">
                <select name="limit" onchange="this.form.submit()">
                    <option value="10" <?= $limit == 10 ? 'selected' : ''; ?>>10</option>
                    <option value="25" <?= $limit == 25 ? 'selected' : ''; ?>>25</option>
                    <option value="50" <?= $limit == 50 ? 'selected' : ''; ?>>50</option>
                </select>
                <select name="sort" onchange="this.form.submit()">
                    <option value="date_desc" <?= $sort == 'date_desc' ? 'selected' : ''; ?>>Newest First</option>
                    <option value="date_asc" <?= $sort == 'date_asc' ? 'selected' : ''; ?>>Oldest First</option>
                    <option value="amount_high" <?= $sort == 'amount_high' ? 'selected' : ''; ?>>Highest Amount</option>
                    <option value="amount_low" <?= $sort == 'amount_low' ? 'selected' : ''; ?>>Lowest Amount</option>
                    <option value="name_asc" <?= $sort == 'name_asc' ? 'selected' : ''; ?>>Name (A-Z)</option>
                </select>
                <select name="status" onchange="this.form.submit()">
                    <option value="">All Status</option>
                    <option value="completed" <?= $status == 'completed' ? 'selected' : '' ?>>Completed</option>
                    <option value="voided" <?= $status == 'voided' ? 'selected' : '' ?>>Voided</option>
                </select>
                <input type="date" name="date" value="<?= $date ?>" style="width: 130px;">
                <input type="text" name="search" placeholder="Search..." value="<?= htmlspecialchars($search) ?>" style="width: 150px;">
                <button type="submit" class="btn-blue" style="padding: 8px 15px;">Search</button>
                <?php if(!empty($search) || !empty($status) || !empty($date) || $limit != 10): ?>
                    <a href="transaction_logs.php" style="font-size: 0.8rem; color: var(--primary); text-decoration: none;">Clear</a>
                <?php endif; ?>
            </form>
        </div>
        <div class="table-area">
            <table>
                <thead>
                    <tr>
                        <th>Receipt No</th>
                        <th>Amount</th>
                        <th>Tendered</th>
                        <th>Change</th>
                        <th>Customer</th>
                        <th>Status</th>
                        <th>Date&Time</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if($result && $result->num_rows > 0): ?>
                        <?php while($row = $result->fetch_assoc()): ?>
                        <tr>
                            <td style="font-weight: 700; color: var(--primary);">#<?= $row['receipt_no'] ?></td>
                            <td style="font-weight: 800;">₱<?= number_format($row['total_amount'], 2) ?></td>
                            <td>₱<?= number_format($row['amount_tendered'], 2) ?></td>
                            <td style="color: <?= ($row['change_due'] < 0) ? 'var(--danger)' : 'inherit' ?>;">
                                ₱<?= number_format($row['change_due'], 2) ?>
                            </td>
                            <td><?= htmlspecialchars($row['customer_name'] ?: 'Walk-in') ?></td>
                            <td>
                                <span style="color: <?= ($row['status'] == 'voided') ? 'var(--danger)' : 'var(--success)' ?>; font-weight: 800; font-size: 0.7rem; text-transform: uppercase;">
                                    <?= $row['status'] ?: 'Completed' ?>
                                </span>
                            </td>
                            <td style="color: var(--text-muted); font-size: 0.8rem;">
                                <?= date('M d Y, g:i A', strtotime($row['date_created'])) ?>
                            </td>
                            <td>
                                <div style="display: flex; gap: 5px;">
                                    <a href="print_receipt.php?id=<?= $row['id'] ?>" target="_blank" class="btn-blue" style="padding: 5px 12px; font-size: 0.8rem; text-decoration: none;">
                                        <i class="fa fa-print"></i>
                                    </a>
                                    <?php if ($row['status'] == 'completed' && isset($_SESSION['role']) && $_SESSION['role'] == 'admin'): ?>
                                        <button onclick="voidWithReason(<?= $row['id'] ?>)" class="btn-red" style="padding: 5px 12px; font-size: 0.8rem;">
                                            <i class="fa fa-ban"></i>
                                        </button>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr><td colspan="8" style="text-align:center; padding:30px;">No transactions found.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <div style="display: flex; justify-content: space-between; align-items: center; padding: 15px 20px; background: #f8fafc; border-top: 1px solid var(--border);">
            <div style="font-size: 0.85rem; color: var(--text-muted);">
                Showing <?= $start_entry ?> to <?= $end_entry ?> of <?= $total_records ?> entries
            </div>
            <div class="pagination" style="display: flex; gap: 10px; align-items: center;">
                <?php if($page > 1): ?>
                    <a href="?page=<?= $page-1 ?>&limit=<?= $limit ?>&search=<?= urlencode($search) ?>&sort=<?= urlencode($sort) ?>&status=<?= urlencode($status) ?>&date=<?= urlencode($date) ?>" class="btn-blue" style="padding: 5px 15px; font-size: 0.8rem; text-decoration: none;">Previous</a>
                <?php endif; ?>
                <span style="font-size: 0.85rem; font-weight: 600;">Page <?= $page ?> of <?= $total_pages ?></span>
                <?php if($page < $total_pages): ?>
                    <a href="?page=<?= $page+1 ?>&limit=<?= $limit ?>&search=<?= urlencode($search) ?>&sort=<?= urlencode($sort) ?>&status=<?= urlencode($status) ?>&date=<?= urlencode($date) ?>" class="btn-blue" style="padding: 5px 15px; font-size: 0.8rem; text-decoration: none;">Next</a>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<script>
function voidWithReason(id) {
    let reason = prompt("Enter reason for voiding this transaction:");
    if (reason && confirm("Are you sure? This will restore stock levels and mark the transaction as voided.")) {
        window.location.href = "void_transaction.php?id=" + id + "&reason=" + encodeURIComponent(reason);
    }
}
</script>
</body>
</html>