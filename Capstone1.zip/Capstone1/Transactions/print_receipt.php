<?php
include '../db.php';
include 'functions.php'; 

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

// Fetch with Role join to fix 'staff_name' error
$stmt = $conn->prepare("SELECT t.*, u.role 
                        FROM transactions t 
                        JOIN users u ON t.user_id = u.id 
                        WHERE t.id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$res = $stmt->get_result();

if ($res->num_rows == 0) {
    die("Error: Transaction not found.");
}
$data = $res->fetch_assoc();

$items_query = "SELECT ti.*, p.name 
                FROM transaction_items ti 
                JOIN products p ON ti.product_id = p.id 
                WHERE ti.transaction_id = $id";
$items_res = $conn->query($items_query);
?>
<!DOCTYPE html>
<html lang="en">
<head>
        <meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Receipt - <?php echo $data['receipt_no']; ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        :root {
            --receipt-width: 380px;
        }

        body {
            background: #f0f2f5;
            font-family: 'Courier New', Courier, monospace;
            margin: 0;
            padding: 20px;
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        /* Responsive Container */
        #receipt-print-area {
            width: 95%; /* Responsive on mobile */
            max-width: var(--receipt-width); /* Fixed look on desktop */
            background: #fff;
            padding: 25px;
            box-shadow: 0 10px 25px rgba(0,0,0,0.1);
            border-radius: 2px;
            position: relative;
            box-sizing: border-box;
            overflow: visible; /* Prevents cropping */
        }

        /* Branding Styles */
        .text-center { text-align: center; }
        .text-right { text-align: right; }
        .divider { border-top: 1px dashed #000; margin: 15px 0; width: 100%; }
        
        h2 { margin: 5px 0; text-transform: uppercase; letter-spacing: 1px; }
        p { margin: 2px 0; font-size: 14px; }

        table { width: 100%; border-collapse: collapse; font-size: 14px; }
        th { border-bottom: 1px solid #000; padding: 8px 0; text-align: left; }
        td { padding: 6px 0; vertical-align: top; }

        .grand-total { font-size: 18px; font-weight: bold; }
        
        .void-stamp {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%) rotate(-35deg);
            color: rgba(255, 0, 0, 0.15);
            font-size: 55px;
            font-weight: bold;
            border: 8px solid rgba(255, 0, 0, 0.15);
            padding: 15px;
            z-index: 10;
            pointer-events: none;
            white-space: nowrap;
        }

        /* Action Buttons Wrapper */
        .receipt-actions {
            margin-top: 30px;
            width: 100%;
            max-width: var(--receipt-width);
            display: flex;
            flex-direction: column;
            gap: 10px;
        }

        .btn {
            padding: 12px;
            border-radius: 6px;
            text-decoration: none;
            text-align: center;
            font-family: sans-serif;
            font-weight: bold;
            cursor: pointer;
            border: none;
            transition: 0.2s;
        }

        .btn-print { background: #10b981; color: #fff; font-size: 16px; }
        .btn-print:hover { background: #059669; }
        .btn-secondary { background: #64748b; color: #fff; }

        /* CRITICAL PRINT FIXES */
        @media print {
            @page {
                margin: 0; /* Removes browser header/footer */
                size: auto;
            }
            body {
                background: white;
                padding: 0;
                margin: 0;
                display: block;
            }
            .no-print {
                display: none !important;
            }
            #receipt-print-area {
                width: 100% !important;
                max-width: none !important;
                box-shadow: none !important;
                border: none !important;
                margin: 0 !important;
                padding: 10mm; /* Standard margin for paper */
            }
            /* Ensures everything is visible and not clipped */
            html, body, #receipt-print-area {
                height: auto;
                overflow: visible !important;
            }
        }
    </style>
</head>
<body>

    <div id="receipt-print-area">
        <?php if(isset($data['status']) && $data['status'] == 'voided'): ?>
            <div class="void-stamp">VOIDED</div>
        <?php endif; ?>

        <div class="text-center">
            <h2>POS SYSTEM</h2>
            <p>Official Receipt</p>
        </div>
        
        <div class="divider"></div>
        
        <table>
            <tr><td>Receipt No:</td><td class="text-right"><strong>#<?php echo $data['receipt_no']; ?></strong></td></tr>
            <tr><td>Date:</td><td class="text-right"><?php echo date('M d, Y H:i', strtotime($data['date_created'])); ?></td></tr>
            <tr><td>In-Charge:</td><td class="text-right" style="text-transform: capitalize;"><?php echo htmlspecialchars($data['role']); ?></td></tr>
        </table>
        
        <div class="divider"></div>

        <table>
            <thead>
                <tr>
                    <th>Item Description</th>
                    <th style="text-align:center;">Qty</th>
                    <th class="text-right">Total</th>
                </tr>
            </thead>
            <tbody>
                <?php while($item = $items_res->fetch_assoc()): ?>
                <tr>
                    <td><?php echo htmlspecialchars($item['name']); ?></td>
                    <td style="text-align:center;"><?php echo $item['quantity']; ?></td>
                    <td class="text-right">₱<?php echo number_format($item['quantity'] * $item['price_at_sale'], 2); ?></td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
        
        <div class="divider"></div>
        
        <table>
            <tr class="grand-total">
                <td>GRAND TOTAL:</td>
                <td class="text-right">₱<?php echo number_format($data['total_amount'], 2); ?></td>
            </tr>
            <tr>
                <td>Cash Tendered:</td>
                <td class="text-right">₱<?php echo number_format($data['amount_tendered'], 2); ?></td>
            </tr>
            <tr>
                <td><strong>Change:</strong></td>
                <td class="text-right"><strong>₱<?php echo number_format($data['change_due'], 2); ?></strong></td>
            </tr>
            <tr style="font-size: 12px; color: #555;">
                <td style="padding-top:10px;">VAT Amount:</td>
                <td class="text-right" style="padding-top:10px;">₱<?php echo number_format($data['vat_amount'], 2); ?></td>
            </tr>
        </table>
        
        <div class="divider"></div>
        
        <div class="text-center" style="font-size: 12px; margin-top: 15px;">
            <p>Customer: <?php echo htmlspecialchars($data['customer_name']); ?></p>
            <p>*** THANK YOU! ***</p>
        </div>
    </div>

    <div class="receipt-actions no-print">
        <button class="btn btn-print" onclick="window.print()">
            <i class="fa fa-print"></i> PRINT RECEIPT
        </button>
        <div style="display: flex; gap: 10px;">
            <a href="transaction.php" class="btn btn-secondary" style="flex: 1;">New Sale</a>
            <a href="transaction_logs.php" class="btn btn-secondary" style="flex: 1;">View Logs</a>
        </div>
    </div>

</body>
</html>