/**
 * TRANSACTION SYSTEM SCRIPT
 */

// Modal Controls
function openModal() {
    document.getElementById('transactionModal').style.display = 'block';
    document.body.style.overflow = 'hidden'; 
}

function closeModal() {
    document.getElementById('transactionModal').style.display = 'none';
    document.body.style.overflow = 'auto'; 
}

/**
 * Simplified Add Item Function (No Select2)
 */
function addItemRow() {
    const container = document.getElementById('item-list');
    const firstRow = container.querySelector('.item-row');
    
    // 1. Clone the row
    const newRow = firstRow.cloneNode(true);
    
    // 2. Reset all input and select values
    newRow.querySelectorAll('input').forEach(i => {
        i.value = '';
        i.style.borderColor = ''; 
    });
    
    const select = newRow.querySelector('select');
    select.selectedIndex = 0; // Reset to "Select Product" placeholder
    
    newRow.querySelector('.row-qty').value = 0;
    newRow.querySelector('.row-total').value = '0.00';
    
    // 3. Add to page
    container.appendChild(newRow);
    
    updateAvailableOptions();
}

/**
 * Updates price/stock when a product is picked using standard select index
 */
function updateRow(select) {
    const row = select.closest('.item-row');
    const opt = select.options[select.selectedIndex];
    
    // Use dataset for better performance
    const stockField = row.querySelector('.row-stock');
    const priceField = row.querySelector('.row-price');
    const qtyField = row.querySelector('.row-qty');
    
    stockField.value = opt.getAttribute('data-stock') || 0;
    priceField.value = opt.getAttribute('data-price') || 0;
    
    calculateRow(qtyField);
    updateAvailableOptions();
}

/**
 * Hides selected products from other dropdowns to prevent duplicates
 */
/**
 * Hides selected products from other dropdowns to prevent duplicates
 */
function updateAvailableOptions() {
    const selects = document.querySelectorAll('select[name="product_id[]"]');
    const selectedValues = Array.from(selects).map(s => s.value).filter(v => v !== "");

    // CHANGED: selects.each to selects.forEach
    selects.forEach(function(currentSelect) {
        const currentValue = currentSelect.value;
        
        Array.from(currentSelect.options).forEach(option => {
            if (option.value === "") return;
            const isSelectedElsewhere = selectedValues.includes(option.value) && option.value !== currentValue;
            option.disabled = isSelectedElsewhere;
        });
    });
}

function removeRow(btn) {
    // Look ONLY inside the item-list container so we don't count the checkout rows
    const container = document.getElementById('item-list');
    const rows = container.querySelectorAll('.item-row');
    
    if (rows.length > 1) {
        btn.closest('.item-row').remove();
        calculateGrandTotal();
        updateAvailableOptions();
    } else {
        alert("At least one item is required.");
    }
}

/**
 * Calculates the total for a specific row
 */
function calculateRow(input) {
    const row = input.closest('.item-row');
    const qty = parseFloat(row.querySelector('.row-qty').value) || 0;
    const price = parseFloat(row.querySelector('.row-price').value) || 0;
    
    const total = qty * price;
    row.querySelector('.row-total').value = total.toFixed(2);
    
    calculateGrandTotal();
}

/**
 * Synchronizes percentage and value discounts
 */
function syncDiscount(type) {
    const subtotal = Array.from(document.querySelectorAll('.row-total'))
        .reduce((sum, el) => sum + parseFloat(el.value || 0), 0);
    
    const discPercent = document.getElementById('discount_percent');
    const discVal = document.getElementById('discount_val');

    if (type === 'percent') {
        const val = subtotal * (parseFloat(discPercent.value || 0) / 100);
        discVal.value = val.toFixed(2);
    } else {
        const percent = subtotal > 0 ? (parseFloat(discVal.value || 0) / subtotal) * 100 : 0;
        discPercent.value = percent.toFixed(2);
    }
    
    calculateGrandTotal();
}

/**
 * Main calculation engine for the entire transaction
 */
function calculateGrandTotal() {
    const rows = document.querySelectorAll('.row-total');
    let subtotal = 0;
    rows.forEach(r => subtotal += parseFloat(r.value || 0));

    const vatPercent = parseFloat(document.getElementById('vat').value || 0);
    const discountAmt = parseFloat(document.getElementById('discount_val').value || 0);
    
    // Calculate VAT (assuming VAT is added on top of subtotal)
    const vatAmt = subtotal * (vatPercent / 100);
    const grandTotal = (subtotal + vatAmt) - discountAmt;

    // Update Displays
    const totalInput = document.getElementById('total_amount');
    const totalDisplay = document.getElementById('total-display');
    
    totalInput.value = grandTotal.toFixed(2);
    if(totalDisplay) totalDisplay.value = '₱ ' + grandTotal.toLocaleString(undefined, {minimumFractionDigits: 2});

    calculateChange();
}

/**
 * Calculates the change due to the customer
 */
function calculateChange() {
    const grandTotal = parseFloat(document.getElementById('total_amount').value || 0);
    const tendered = parseFloat(document.getElementById('tendered').value || 0);
    const change = tendered - grandTotal;

    // Updates the hidden input for the database
    document.getElementById('change').value = change.toFixed(2);
    
    // Updates the visible read-only input
    const changeDisplay = document.getElementById('change-display');
    if(changeDisplay) {
        // CHANGED: Use .value instead of .innerText
        changeDisplay.value = '₱ ' + (change >= 0 ? change : 0).toLocaleString(undefined, {minimumFractionDigits: 2});
    }
}
// Mobile Dropdown Accordion Logic
document.addEventListener('DOMContentLoaded', () => {
    const dropdowns = document.querySelectorAll('.dropdown');
    
    dropdowns.forEach(dropdown => {
        const trigger = dropdown.querySelector('a');
        
        trigger.addEventListener('click', function(e) {
            if (window.innerWidth <= 1024) {
                // Prevent going to a new page so the menu can open
                e.preventDefault(); 
                
                const isOpened = dropdown.classList.contains('show-mobile');
                
                // Close other open dropdowns
                dropdowns.forEach(d => d.classList.remove('show-mobile'));
                
                // Toggle this one
                if (!isOpened) {
                    dropdown.classList.add('show-mobile');
                }
            }
        });
    });
});