<?php
include '../admin_auth.php';
include '../db.php';

// Only allow Admins to view this page
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit();
}

// Get Filter Parameters
$search = isset($_GET['search']) ? $conn->real_escape_string($_GET['search']) : '';
$limit  = isset($_GET['limit']) ? (int)$_GET['limit'] : 10;
$sort   = isset($_GET['sort']) ? $_GET['sort'] : 'date_desc';
$page   = isset($_GET['page']) ? (int)$_GET['page'] : 1;
if ($page < 1) $page = 1;

$offset = ($page - 1) * $limit;

$sort_options = [
    'date_desc'   => "t.date_created DESC",
    'date_asc'    => "t.date_created ASC",
    'amount_high' => "t.total_amount DESC",
    'amount_low'  => "t.total_amount ASC",
    'name_asc'    => "t.customer_name ASC"
];
$sort_sql = $sort_options[$sort] ?? "t.date_created DESC";

// Build query with search
$where_clauses = ["t.status = 'voided'"];
if (!empty($search)) {
    $where_clauses[] = "(t.receipt_no LIKE '%$search%' OR t.customer_name LIKE '%$search%')";
}
$where_sql = "WHERE " . implode(" AND ", $where_clauses);

// Count total records for pagination
$count_query = "SELECT COUNT(*) as total FROM transactions t $where_sql";
$total_records = $conn->query($count_query)->fetch_assoc()['total'];
$total_pages = ceil($total_records / $limit);
if ($page > $total_pages && $total_pages > 0) $page = $total_pages;

// UPDATED QUERY: Join with users table to get the role using user_id
$query = "SELECT t.*, u.role 
          FROM transactions t 
          JOIN users u ON t.user_id = u.id 
          $where_sql 
          ORDER BY $sort_sql 
          LIMIT $limit OFFSET $offset";
$result = $conn->query($query);

$start_entry = ($total_records > 0) ? $offset + 1 : 0;
$end_entry = min($offset + $limit, $total_records);
?>
<!DOCTYPE html>
<html lang="en">
<head>
        <meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Void Logs - IMS</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>

<nav class="navbar">
    <a href="#" class="navbar-brand">
    <img src="../Image/MGSLOGO.png" alt="MGS Logo" class="nav-logo">
</a>
    
    <input type="checkbox" id="nav-toggle" class="nav-toggle">
    <label for="nav-toggle" class="nav-toggle-label">
        <i class="fa-solid fa-bars"></i>
    </label>
    
    <ul class="navbar-links">
        <li><a href="../Dashboard/dashboard.php"><i class="fa-solid fa-gauge-high"></i> Dashboard</a></li>
        
        <li class="dropdown">
            <a href="javascript:void(0)" >
                <i class="fa-solid fa-boxes-stacked"></i> Inventory <i class="fa-solid fa-caret-down"></i>
            </a>
            <div class="dropdown-content">
                <a href="../Products/products.php">All Products</a>
                <a href="../Products/logs.php">Logs</a>
                <a href="../Products/trash.php">Trash</a>
            </div>
        </li>

        <li><a href="../Stores/stores.php"><i class="fa-solid fa-store"></i> Stores</a></li>

        <li class="dropdown">
            <a href="javascript:void(0)" class="active">
                <i class="fa fa-exchange-alt"></i> Transaction <i class="fa-solid fa-caret-down"></i>
            </a>
            <div class="dropdown-content">
                <a href="../Transactions/transaction.php">Transaction</a>
                <a href="../Transactions/void_logs.php">Void Logs</a>
                <a href="../Transactions/transaction_logs.php">Transaction Logs</a>
                <a href="../Transactions/sales_report.php">Sales Report</a>
            </div>
        </li>

        <li><a href="../Expenses/expenses.php"><i class="fa-solid fa-wallet"></i> Expenses</a></li>

        <li>
            <a href="../logout.php" class="logout-link">
                <i class="fa-solid fa-right-from-bracket"></i> Logout
            </a>
        </li>
    </ul>
</nav>

<div class="main-layout">
    <div class="table-container">
        <div class="table-header">
            <span style="font-weight: 800; letter-spacing: -0.5px; text-transform: uppercase;">
                <i class="fa fa-ban"></i> Voided History
            </span>
            <form action="" method="GET" style="display: flex; gap: 8px; align-items: center; flex-wrap: wrap;">
                
                <select name="limit" onchange="this.form.submit()">
                    <option value="10" <?= $limit == 10 ? 'selected' : ''; ?>>10</option>
                    <option value="25" <?= $limit == 25 ? 'selected' : ''; ?>>25</option>
                    <option value="50" <?= $limit == 50 ? 'selected' : ''; ?>>50</option>
                </select>

                <select name="sort" onchange="this.form.submit()">
                    <option value="date_desc" <?= $sort == 'date_desc' ? 'selected' : ''; ?>>Newest First</option>
                    <option value="date_asc" <?= $sort == 'date_asc' ? 'selected' : ''; ?>>Oldest First</option>
                    <option value="amount_high" <?= $sort == 'amount_high' ? 'selected' : ''; ?>>Highest Amount</option>
                    <option value="amount_low" <?= $sort == 'amount_low' ? 'selected' : ''; ?>>Lowest Amount</option>
                    <option value="name_asc" <?= $sort == 'name_asc' ? 'selected' : ''; ?>>Name (A-Z)</option>
                </select>

                <input type="text" name="search" placeholder="Search..." value="<?= htmlspecialchars($search); ?>" style="width: 180px;">

                <button type="submit" class="btn-blue" style="padding: 8px 15px;">Search</button>
                <?php if(!empty($search)): ?>
                    <a href="void_logs.php" style="font-size: 0.8rem; color: var(--primary); text-decoration: none;">Clear</a>
                <?php endif; ?>
            </form>
        </div>
        <div class="table-area">
            <table>
                <thead>
                    <tr>
                        <th>Receipt No</th>
                        <th>Amount Lost</th>
                        <th>Customer</th>
                        <th>In-Charge</th>
                        <th>Voided Date</th>
                        <th>Reason</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if($result->num_rows > 0): ?>
                        <?php while($row = $result->fetch_assoc()): ?>
                        <tr>
                            <td style="font-weight:bold; color: var(--danger);">#<?= $row['receipt_no'] ?></td>
                            <td style="color: var(--danger); font-weight: 800;">₱<?= number_format($row['total_amount'], 2) ?></td>
                            <td><?= htmlspecialchars($row['customer_name'] ?: 'Walk-in') ?></td>
                            <td style="text-transform: capitalize; font-weight: 600;">
                                <?= htmlspecialchars($row['role']) ?>
                            </td>
                            <td style="color: var(--text-muted); font-size: 0.8rem;">
                                <?= date('M d, Y h:i A', strtotime($row['date_created'])) ?>
                            </td>
                            <td style="font-style: italic; font-size: 0.8rem;"><?= htmlspecialchars($row['void_reason'] ?? 'N/A') ?></td>
                            <td>
                                <a href="print_receipt.php?id=<?= $row['id'] ?>" target="_blank" class="btn-blue" style="padding: 5px 12px; font-size: 0.8rem; text-decoration: none;">
                                    <i class="fa fa-print"></i>
                                </a>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr><td colspan="7" style="text-align: center; padding: 40px;">No voided transactions found.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <div style="display: flex; justify-content: space-between; align-items: center; padding: 15px 20px; background: #f8fafc; border-top: 1px solid var(--border); flex-wrap: wrap; gap: 10px;">
            <div style="font-size: 0.85rem; color: var(--text-muted);">
                Showing <?= $start_entry ?> to <?= $end_entry ?> of <?= $total_records ?> entries
            </div>
            <div class="pagination" style="display: flex; gap: 10px; align-items: center;">
                <?php if($page > 1): ?>
                    <a href="?page=<?= $page-1 ?>&limit=<?= $limit ?>&search=<?= urlencode($search) ?>&sort=<?= urlencode($sort) ?>" class="btn-blue" style="padding: 5px 15px; font-size: 0.8rem; text-decoration: none;">Previous</a>
                <?php endif; ?>
                <span style="font-size: 0.85rem; font-weight: 600;">Page <?= $page ?> of <?= $total_pages ?></span>
                <?php if($page < $total_pages): ?>
                    <a href="?page=<?= $page+1 ?>&limit=<?= $limit ?>&search=<?= urlencode($search) ?>&sort=<?= urlencode($sort) ?>" class="btn-blue" style="padding: 5px 15px; font-size: 0.8rem; text-decoration: none;">Next</a>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

</body>
</html>