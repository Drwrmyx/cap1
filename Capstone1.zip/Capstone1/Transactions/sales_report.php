<?php 
include '../admin_auth.php';
include '../db.php'; 

// Set the date for the report (default to today)
$report_date = isset($_GET['date']) ? $_GET['date'] : date('Y-m-d');

// 1. Fetch Summary Data (Excludes voided transactions)
$summary_query = $conn->prepare("SELECT 
    COUNT(id) as total_tx, 
    SUM(total_amount) as total_sales,
    AVG(total_amount) as avg_value
    FROM transactions 
    WHERE DATE(date_created) = ? AND status = 'completed'");
$summary_query->bind_param("s", $report_date);
$summary_query->execute();
$summary = $summary_query->get_result()->fetch_assoc();

// 2. Fetch Most Sold Items (Only from completed transactions)
$items_query = $conn->prepare("SELECT p.name, SUM(ti.quantity) as qty_sold, SUM(ti.quantity * ti.price_at_sale) as revenue
    FROM transaction_items ti
    JOIN products p ON ti.product_id = p.id
    JOIN transactions t ON ti.transaction_id = t.id
    WHERE DATE(t.date_created) = ? AND t.status = 'completed'
    GROUP BY ti.product_id
    ORDER BY qty_sold DESC LIMIT 5");
$items_query->bind_param("s", $report_date);
$items_query->execute();
$top_items = $items_query->get_result();

// 3. Fetch Transaction List (Shows only completed sales for the revenue table)
$list_query = $conn->prepare("SELECT * FROM transactions 
                             WHERE DATE(date_created) = ? AND status = 'completed' 
                             ORDER BY date_created DESC");
$list_query->bind_param("s", $report_date);
$list_query->execute();
$transactions = $list_query->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
        <meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daily Sales Report - <?= $report_date ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="style.css">
    <style>
        .report-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 20px; margin-bottom: 20px; }
        .stat-card { background: #fff; padding: 20px; border-radius: 8px; border-left: 5px solid #337ab7; box-shadow: 0 2px 5px rgba(0,0,0,0.1); }
        .stat-card h3 { margin: 0; color: #666; font-size: 14px; text-transform: uppercase; }
        .stat-card p { margin: 10px 0 0; font-size: 24px; font-weight: bold; color: #333; }
        @media print { .no-print { display: none; } }

        @media screen and (max-width: 1024px) {
            .report-grid { grid-template-columns: 1fr; }
        }
    </style>
</head>
<body>

<nav class="navbar">
    <a href="#" class="navbar-brand">
    <img src="../Image/MGSLOGO.png" alt="MGS Logo" class="nav-logo">
</a>
    
    <input type="checkbox" id="nav-toggle" class="nav-toggle">
    <label for="nav-toggle" class="nav-toggle-label">
        <i class="fa-solid fa-bars"></i>
    </label>
    
    <ul class="navbar-links">
        <li><a href="../Dashboard/dashboard.php"><i class="fa-solid fa-gauge-high"></i> Dashboard</a></li>
        
        <li class="dropdown">
            <a href="javascript:void(0)" >
                <i class="fa-solid fa-boxes-stacked"></i> Inventory <i class="fa-solid fa-caret-down"></i>
            </a>
            <div class="dropdown-content">
                <a href="../Products/products.php">All Products</a>
                <a href="../Products/logs.php">Logs</a>
                <a href="../Products/trash.php">Trash</a>
            </div>
        </li>

        <li><a href="../Stores/stores.php"><i class="fa-solid fa-store"></i> Stores</a></li>

        <li class="dropdown">
            <a href="javascript:void(0)" class="active">
                <i class="fa fa-exchange-alt"></i> Transaction <i class="fa-solid fa-caret-down"></i>
            </a>
            <div class="dropdown-content">
                <a href="../Transactions/transaction.php">Transaction</a>
                <a href="../Transactions/void_logs.php">Void Logs</a>
                <a href="../Transactions/transaction_logs.php">Transaction Logs</a>
                <a href="../Transactions/sales_report.php">Sales Report</a>
            </div>
        </li>

        <li><a href="../Expenses/expenses.php"><i class="fa-solid fa-wallet"></i> Expenses</a></li>

        <li>
            <a href="../logout.php" class="logout-link">
                <i class="fa-solid fa-right-from-bracket"></i> Logout
            </a>
        </li>
    </ul>
</nav>

<div class="main-layout">
    <div class="table-container">
        <div class="table-header">
            <span style="font-weight: 800; letter-spacing: -0.5px; text-transform: uppercase;">
                <i class="fa fa-chart-line"></i> Sales Report: <?= date('M d, Y', strtotime($report_date)) ?>
            </span>
        </div>

        <div style="padding: 20px;">
            <div class="report-grid">
                <div class="stat-card">
                    <h3>Total Revenue</h3>
                    <p>₱<?= number_format($summary['total_sales'] ?? 0, 2) ?></p>
                </div>
                <div class="stat-card" style="border-left-color: #2ecc71;">
                    <h3>Transactions</h3>
                    <p><?= $summary['total_tx'] ?? 0 ?></p>
                </div>
                <div class="stat-card" style="border-left-color: #f1c40f;">
                    <h3>Avg. Basket Value</h3>
                    <p>₱<?= number_format($summary['avg_value'] ?? 0, 2) ?></p>
                </div>
            </div>

            <div style="display: flex; flex-direction: column; gap: 20px; margin-top: 20px;">
                <div class="table-area">
                    <h4 style="margin-bottom:15px; font-weight: 800; text-transform: uppercase; font-size: 0.8rem; color: var(--text-muted);">
                        <i class="fa fa-list"></i> Transactions Detail
                    </h4>
                    <table>
                        <thead>
                            <tr>
                                <th>Receipt No</th>
                                <th>Customer</th>
                                <th>Time</th>
                                <th>Amount</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if($transactions->num_rows > 0): ?>
                                <?php while($row = $transactions->fetch_assoc()): ?>
                                <tr>
                                    <td style="font-weight:700; color:var(--primary);">#<?= $row['receipt_no'] ?></td>
                                    <td><?= htmlspecialchars($row['customer_name']) ?></td>
                                    <td style="color: var(--text-muted); font-size: 0.8rem;"><?= date('h:i A', strtotime($row['date_created'])) ?></td>
                                    <td style="font-weight: 800;">₱<?= number_format($row['total_amount'], 2) ?></td>
                                </tr>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <tr><td colspan="4" style="text-align:center; padding:30px;">No transactions recorded for this day.</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>

                <div class="table-area">
                    <h4 style="margin-bottom:15px; font-weight: 800; text-transform: uppercase; font-size: 0.8rem; color: var(--text-muted);">
                        <i class="fa fa-star"></i> Best Sellers (Today)
                    </h4>
                    <table>
                        <thead>
                            <tr><th>Item</th><th>Qty</th><th>Rev.</th></tr>
                        </thead>
                        <tbody>
                            <?php while($item = $top_items->fetch_assoc()): ?>
                            <tr>
                                <td style="text-align: left; font-weight: 600;"><?= htmlspecialchars($item['name']) ?></td>
                                <td style="font-weight: 700; color: var(--primary);"><?= $item['qty_sold'] ?></td>
                                <td style="font-weight: 800;">₱<?= number_format($item['revenue'], 2) ?></td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

</body>
</html>