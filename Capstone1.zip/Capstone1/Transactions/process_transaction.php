<?php
session_start(); // CRITICAL: Must be at the very top to get the user_id
include '../db.php';
include 'functions.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // 1. Check if user is logged in
    if (!isset($_SESSION['user_id'])) {
        die("Error: You must be logged in to perform a transaction.");
    }

    $receipt = generateReceiptNo();
    $user_id = $_SESSION['user_id']; // This is the ID we need for the new database structure
    
    $store_id = isset($_POST['store_id']) ? (int)$_POST['store_id'] : 0;
    
    // --- Name Logic ---
    $manual_name = trim($_POST['cust_name']);
    $customer_name = !empty($manual_name) ? $manual_name : ($store_id > 0 ? "Store" : "Walk-in Customer");

    // --- VAT & Totals ---
    $vat_percent = isset($_POST['vat']) ? (float)$_POST['vat'] : 0;
    $total_amount = (float)$_POST['total_amount'];
    
    // Safety check for empty total
    if($total_amount <= 0) {
        die("Error: Transaction total cannot be zero.");
    }

    // --- Payment Details ---
    $tendered = isset($_POST['tendered']) ? (float)$_POST['tendered'] : 0;
    $change   = isset($_POST['change']) ? (float)$_POST['change'] : 0;
    $pay_mode = isset($_POST['payment_mode']) ? $_POST['payment_mode'] : 'Cash';
    
    // FIX: Use null coalescing (??) to prevent "Undefined array key" warnings
    $phone    = $_POST['cust_phone'] ?? ''; 
    $email    = $_POST['cust_email'] ?? '';

    $conn->begin_transaction();

    try {
        // FIXED SQL: Removed 'staff_name', added 'user_id'
        $stmt = $conn->prepare("INSERT INTO transactions (store_id, receipt_no, total_amount, user_id, amount_tendered, change_due, mode_of_payment, customer_name, customer_phone, customer_email) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        
        // Types: i=int, s=string, d=double
        $stmt->bind_param("isdidddsss", $store_id, $receipt, $total_amount, $user_id, $tendered, $change, $pay_mode, $customer_name, $phone, $email);
        
        if (!$stmt->execute()) {
            throw new Exception("Execute failed: " . $stmt->error);
        }
        
        $last_id = $conn->insert_id;

        // --- Record Individual Items ---
        if (isset($_POST['product_id']) && is_array($_POST['product_id'])) {
            foreach ($_POST['product_id'] as $key => $prod_id) {
                $qty = (int)$_POST['qty'][$key];
                if ($qty > 0) {
                    // Get current price
                    $price_query = $conn->prepare("SELECT price FROM products WHERE id = ?");
                    $price_query->bind_param("i", $prod_id);
                    $price_query->execute();
                    $price_res = $price_query->get_result()->fetch_assoc();
                    $current_price = $price_res['price'];

                    // Insert into transaction_items
                    $item_stmt = $conn->prepare("INSERT INTO transaction_items (transaction_id, product_id, quantity, price_at_sale) VALUES (?, ?, ?, ?)");
                    $item_stmt->bind_param("iiid", $last_id, $prod_id, $qty, $current_price);
                    $item_stmt->execute();

                    // Update Stock
                    $update_stmt = $conn->prepare("UPDATE products SET stock = stock - ?, total_sold = total_sold + ? WHERE id = ?");
                    $update_stmt->bind_param("iii", $qty, $qty, $prod_id);
                    $update_stmt->execute();
                }
            }
        }

        $conn->commit();
        header("Location: print_receipt.php?id=" . $last_id);
        exit(); 

    } catch (Exception $e) {
        $conn->rollback();
        die("Transaction failed: " . $e->getMessage());
    }
}
?>