<?php
include '../db.php';
session_start();

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    die("Unauthorized access.");
}

$tx_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$reason = isset($_GET['reason']) ? $_GET['reason'] : 'No reason provided';

if ($tx_id > 0) {
    // Update both the status AND the void_reason
    $stmt = $conn->prepare("UPDATE transactions SET status = 'voided', void_reason = ? WHERE id = ?");
    $stmt->bind_param("si", $reason, $tx_id);
    
    if ($stmt->execute()) {
        header("Location: transaction_logs.php?msg=VoidSuccess");
        exit();
    } else {
        echo "Error: " . $conn->error;
    }
}
?>