-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 25, 2026 at 04:45 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sales_system`
--

-- --------------------------------------------------------

--
-- Table structure for table `expenses`
--

CREATE TABLE `expenses` (
  `id` int(11) NOT NULL,
  `category` enum('Payroll','Fuel','Gate Fee','Utilities','Maintenance','Other') NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `description` text DEFAULT NULL,
  `expense_date` date NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `expenses`
--

INSERT INTO `expenses` (`id`, `category`, `amount`, `description`, `expense_date`, `created_at`) VALUES
(1, 'Fuel', 500.00, 'gas', '2026-03-24', '2026-03-24 20:30:30'),
(2, 'Payroll', 610.00, 'ranz salary', '2026-03-24', '2026-03-24 20:30:55'),
(3, 'Gate Fee', 5.00, '', '2026-03-24', '2026-03-24 20:31:03'),
(4, 'Utilities', 1000.00, '', '2026-03-24', '2026-03-24 20:32:59');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `item_code` varchar(50) DEFAULT NULL,
  `name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `stock` int(11) DEFAULT 0,
  `price` decimal(10,2) NOT NULL,
  `total_sold` int(11) DEFAULT 0,
  `total_earned_on_item` decimal(10,2) DEFAULT 0.00,
  `is_deleted` tinyint(1) DEFAULT 0,
  `image_path` varchar(255) DEFAULT NULL,
  `max_stock` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `item_code`, `name`, `description`, `stock`, `price`, `total_sold`, `total_earned_on_item`, `is_deleted`, `image_path`, `max_stock`) VALUES
(1, '123', 'Cornetto Disc Matcha Crumble', '', 9, 1.00, 98, 917.00, 0, NULL, 0),
(2, '1234', 'Cornetto Cookies & Dream', '', 176, 123.00, 54, 13446.00, 0, NULL, 0),
(3, '555', 'Cornetto Vanilla', '', 114, 32.00, -12, -384.00, 0, NULL, 0),
(4, '6666', 'Cornetto Chocolate', '0', 126, 11.04, 1, 11.04, 0, 'uploads/img_69c26798b06021.23680224.avif', 200),
(5, '11234', 'Cornetto Hazelnut', '', 20, 10.00, 3, 30.00, 0, NULL, 0),
(12, '786', 'Cornetto Disc Black Choco Cookie', '', 110, 123.00, 0, 0.00, 0, 'uploads/img_69c2611468bf83.80922195.avif', 0);

-- --------------------------------------------------------

--
-- Table structure for table `product_logs`
--

CREATE TABLE `product_logs` (
  `id` int(11) NOT NULL,
  `product_id` int(11) DEFAULT NULL,
  `item_code` varchar(100) DEFAULT NULL,
  `action_type` varchar(50) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `product_logs`
--

INSERT INTO `product_logs` (`id`, `product_id`, `item_code`, `action_type`, `description`, `created_at`) VALUES
(1, 4, NULL, 'Stock Increased', 'Quantity changed by 12.', '2026-03-24 07:29:33'),
(2, 4, NULL, 'Stock Decreased', 'Quantity changed by 10.', '2026-03-24 07:29:42'),
(3, 4, '6666', 'Item Edited', 'Updated details for item: Cornetto Chocolate.', '2026-03-24 07:29:54'),
(4, 8, '445', 'Item Deleted', 'Deleted item: Cornetto Disc Black Choco Cookie.', '2026-03-24 07:30:07'),
(5, 4, '6666', 'Stock Increased', 'Quantity changed by 1.', '2026-03-24 07:49:11'),
(6, 9, '786', 'Item Created', 'Added new item: Cornetto Disc Black Choco Cookie with initial stock of 1.', '2026-03-24 07:51:04'),
(7, 9, '786', 'Item Deleted', 'Deleted item: Cornetto Disc Black Choco Cookie.', '2026-03-24 07:51:13'),
(8, 4, '6666', 'Stock Increased', 'Quantity changed by 2.', '2026-03-24 08:26:43'),
(9, 4, '6666', 'Stock Increased', 'Quantity changed by 2 for item: Cornetto Chocolate.', '2026-03-24 08:31:00'),
(10, 10, '786', 'Item Created', 'Added new item: Cornetto Disc Black Choco Cookie with initial stock of 106.', '2026-03-24 08:57:52'),
(11, 10, '786', 'Item Deleted', 'Deleted item: Cornetto Disc Black Choco Cookie.', '2026-03-24 08:58:23'),
(12, 4, '6666', 'Item Edited', 'Updated details for item: Cornetto Chocolate.', '2026-03-24 08:59:59'),
(13, 4, '6666', 'Stock Increased', 'Quantity changed by 2 for item: Cornetto Chocolate.', '2026-03-24 09:00:07'),
(14, 4, '6666', 'Stock Increased', 'Quantity changed by 2 for item: Cornetto Chocolate.', '2026-03-24 09:08:12'),
(15, 4, '6666', 'Item Edited', 'Updated details for item: Cornetto Chocolate.', '2026-03-24 09:09:29'),
(16, 1, '123', 'Item Edited', 'Updated details for item: Cornetto Disc Matcha Crumble.', '2026-03-24 09:10:27'),
(17, 1, '123', 'Item Edited', 'Updated details for item: Cornetto Disc Matcha Crumble.', '2026-03-24 09:10:37'),
(18, 4, '6666', 'Stock Increased', 'Quantity changed by 12 for item: Cornetto Chocolate.', '2026-03-24 09:29:43'),
(19, 4, '6666', 'Item Edited', 'Updated details for item: Cornetto Chocolate.', '2026-03-24 09:29:49'),
(20, 11, '786', 'Item Created', 'Added new item: Cornetto Disc Black Choco Cookie with initial stock of 106.', '2026-03-24 09:30:02'),
(21, 11, '786', 'Item Deleted', 'Deleted item: Cornetto Disc Black Choco Cookie.', '2026-03-24 09:30:07'),
(22, 4, '6666', 'Stock Decreased', 'Quantity changed by 23 for item: Cornetto Chocolate.', '2026-03-24 09:43:29'),
(23, 4, '6666', 'Item Edited', 'Updated details for item: Cornetto Chocolate.', '2026-03-24 09:43:33'),
(24, 5, '11234', 'Item Deleted (Soft)', 'Removed item from active inventory: Cornetto Hazelnut.', '2026-03-24 09:48:57'),
(25, 5, '11234', 'Item Restored', 'Restored item back to active inventory: Cornetto Hazelnut.', '2026-03-24 09:52:26'),
(26, 12, '786', 'Item Created', 'Added new item: Cornetto Disc Black Choco Cookie with initial stock of 110.', '2026-03-24 10:01:56'),
(27, 4, '6666', 'Item Edited', 'Updated details for item: Cornetto Chocolate.', '2026-03-24 10:29:44'),
(28, 5, '11234', 'Item Deleted (Soft)', 'Removed item from active inventory: Cornetto Hazelnut.', '2026-03-24 10:34:22'),
(29, 5, '11234', 'Item Restored', 'Restored item back to active inventory: Cornetto Hazelnut.', '2026-03-24 10:34:27'),
(30, 12, '786', 'Item Deleted (Soft)', 'Removed item from active inventory: Cornetto Disc Black Choco Cookie.', '2026-03-24 10:34:32'),
(31, 12, '786', 'Item Restored', 'Restored item back to active inventory: Cornetto Disc Black Choco Cookie.', '2026-03-24 10:34:38'),
(32, 4, '6666', 'Stock Increased', 'Quantity changed by 11 for item: Cornetto Chocolate.', '2026-03-24 10:55:11'),
(33, 4, '6666', 'Stock Decreased', 'Quantity changed by 3 for item: Cornetto Chocolate.', '2026-03-24 10:55:19'),
(34, 4, '6666', 'Item Edited', 'Updated details for item: Cornetto Chocolate.', '2026-03-24 10:56:19'),
(35, 4, '6666', 'Stock Increased', 'Quantity changed by 3 for item: Cornetto Chocolate.', '2026-03-24 10:56:29'),
(36, 4, '6666', 'Item Edited', 'Updated details for item: Cornetto Chocolate.', '2026-03-24 11:21:49'),
(37, 4, '6666', 'Item Edited', 'Updated details for item: Cornetto Chocolate.', '2026-03-24 11:34:21'),
(38, 4, '6666', 'Stock Increased', 'Quantity changed by 5 for item: Cornetto Chocolate.', '2026-03-24 11:34:40');

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE `settings` (
  `setting_key` varchar(50) NOT NULL,
  `setting_value` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`setting_key`, `setting_value`) VALUES
('total_inventory_limit', '1000');

-- --------------------------------------------------------

--
-- Table structure for table `stores`
--

CREATE TABLE `stores` (
  `id` int(11) NOT NULL,
  `store_name` varchar(255) NOT NULL,
  `owner_name` varchar(255) DEFAULT NULL,
  `contact_number` varchar(20) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `route` varchar(50) DEFAULT NULL,
  `status` enum('Active','Inactive') DEFAULT 'Active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `stores`
--

INSERT INTO `stores` (`id`, `store_name`, `owner_name`, `contact_number`, `address`, `route`, `status`, `created_at`) VALUES
(1, 'andrew store', 'andrew', '', '', '', 'Active', '2026-03-24 22:01:19');

-- --------------------------------------------------------

--
-- Table structure for table `transactions`
--

CREATE TABLE `transactions` (
  `id` int(11) NOT NULL,
  `store_id` int(11) DEFAULT 0,
  `receipt_no` varchar(20) NOT NULL,
  `total_amount` decimal(10,2) NOT NULL,
  `vat_amount` decimal(10,2) DEFAULT 0.00,
  `amount_tendered` decimal(10,2) NOT NULL,
  `change_due` decimal(10,2) NOT NULL,
  `mode_of_payment` varchar(20) DEFAULT NULL,
  `customer_name` varchar(100) DEFAULT NULL,
  `customer_phone` varchar(20) DEFAULT NULL,
  `customer_email` varchar(100) DEFAULT NULL,
  `staff_name` varchar(50) DEFAULT 'Admin Demo',
  `status` enum('completed','voided') DEFAULT 'completed',
  `void_reason` varchar(255) DEFAULT NULL,
  `date_created` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `transactions`
--

INSERT INTO `transactions` (`id`, `store_id`, `receipt_no`, `total_amount`, `vat_amount`, `amount_tendered`, `change_due`, `mode_of_payment`, `customer_name`, `customer_phone`, `customer_email`, `staff_name`, `status`, `void_reason`, `date_created`) VALUES
(1, 0, 'REC-1772199079', 88.00, 0.00, 100.00, 12.00, 'Cash', 'drwe', '09274213543', 'a@gmail.com', 'Admin Demo', 'completed', NULL, '2026-02-27 13:31:19'),
(2, 0, 'REC-1772199142', 88.00, 0.00, 100.00, 12.00, 'Cash', 'drwe', '09274213543', 'a@gmail.com', 'Admin Demo', 'completed', NULL, '2026-02-27 13:32:22'),
(3, 0, 'REC-1772200504', 50.00, 0.00, 50.00, 0.00, 'Cash', 'ff', '09274213547', 'an`@gmail.com', 'Admin Demo', 'completed', NULL, '2026-02-27 13:55:04'),
(4, 0, 'REC-956501', 48.00, 0.00, 70.00, 22.00, 'Cash', 'daa', '09274231456', 'oy@gmail.com', 'Admin Demo', 'completed', NULL, '2026-02-27 13:59:53'),
(5, 0, 'REC-207A54', 16.00, 0.00, 16.00, 0.00, 'Cash', 'An', '09274213540', 'j@gmail.com', 'Admin Demo', 'completed', NULL, '2026-02-27 14:03:46'),
(6, 0, 'REC-C0C412', 20.00, 0.00, 100.00, 80.00, 'Cash', 'Walk-in Customer', '', '', 'Admin Demo', 'completed', NULL, '2026-02-27 14:05:00'),
(7, 0, 'REC-53D486', 40.00, 0.00, 40.00, 0.00, 'Cash', 'Andrew Ramoy', '09274231549', 'a4@gmail.com', 'Admin Demo', 'completed', NULL, '2026-02-27 14:06:13'),
(8, 0, 'REC-5B57A6', 60.00, 0.00, 1000.00, 940.00, 'Cash', 'Andrew Ramoy', '09274231544', 'a4@gmail.com', 'Admin Demo', 'completed', NULL, '2026-02-27 14:07:33'),
(9, 0, 'REC-FCD60C', 47.04, 0.00, 50.00, 2.96, 'Cash', 'Walk-in Customer', '', '', 'Admin Demo', 'completed', NULL, '2026-02-27 14:16:47'),
(10, 0, 'REC-08B744', 39.00, 0.00, 50.00, 11.00, 'Cash', 'Walk-in Customer', '', '', 'Admin Demo', 'completed', NULL, '2026-02-27 16:35:12'),
(11, 0, 'REC-1EFA80', 80.00, 0.00, 80.00, 0.00, 'Cash', 'Walk-in Customer', '', '', 'Admin Demo', 'completed', NULL, '2026-02-27 16:57:05'),
(12, 0, 'REC-B1ED90', 100.00, 0.00, 90.00, -10.00, 'Cash', 'Walk-in Customer', '', '', 'Admin Demo', 'completed', NULL, '2026-02-27 17:13:31'),
(13, 0, 'REC-F2FDF3', 20.40, 0.00, 30.00, 9.60, 'Cash', 'Walk-in Customer', '', '', 'Admin Demo', 'completed', NULL, '2026-02-27 17:15:27'),
(14, 0, 'REC-8EA716', 60.00, 0.00, 60.00, 0.00, 'Cash', 'Walk-in Customer', '', '', 'Admin Demo', 'completed', NULL, '2026-02-27 17:20:56'),
(15, 0, 'REC-4DD35B', 0.00, 0.00, -3.00, 0.00, NULL, 'Walk-in Customer', NULL, NULL, 'Admin Demo', 'completed', NULL, '2026-02-27 17:53:24'),
(16, 0, 'REC-970977', 48.00, 0.00, 60.00, 12.00, 'POS', 'Walk-in Customer', '', '', 'Admin Demo', 'completed', NULL, '2026-02-27 18:00:41'),
(17, 0, 'REC-176648', 62.00, 0.00, 100.00, 38.00, 'Transfer', 'Walk-in Customer', '', '', 'Admin Demo', 'completed', NULL, '2026-02-27 18:01:05'),
(18, 0, 'REC-B31D9B', 30.00, 0.00, 40.00, 10.00, 'Cash', 'Walk-in Customer', '', '', 'Admin Demo', 'completed', NULL, '2026-02-28 12:11:23'),
(19, 0, 'REC-A174D6', 20.00, 0.00, 50.00, 30.00, 'Cash', 'Walk-in Customer', '', '', 'Admin Demo', 'completed', NULL, '2026-02-28 12:15:06'),
(20, 0, 'REC-F94038', 37.60, 0.00, 80.00, 42.40, 'Cash', 'Walk-in Customer', '', '', 'Admin Demo', 'completed', NULL, '2026-02-28 12:35:43'),
(21, 0, 'REC-57D3D7', 483.60, 0.00, 1000.00, 516.40, 'Cash', 'Walk-in Customer', '', '', 'Admin Demo', 'completed', NULL, '2026-02-28 12:39:17'),
(22, 0, 'REC-8BC727', 10.00, 0.00, 70.00, 60.00, 'Cash', 'Walk-in Customer', '', '', 'Admin Demo', 'completed', NULL, '2026-03-24 08:07:36'),
(23, 0, 'REC-82AD04', 7.00, 0.00, 8.00, 1.00, 'Cash', 'Walk-in Customer', '', '', 'Admin Demo', 'completed', NULL, '2026-03-24 12:40:56'),
(24, 0, 'REC-D21B38', 492.00, 0.00, 500.00, 8.00, 'Cash', 'Walk-in Customer', '', '', 'Admin Demo', 'completed', NULL, '2026-03-24 12:45:49'),
(25, 0, 'REC-091CD2', 99.84, 0.00, 100.00, 0.16, 'Cash', 'Walk-in Customer', '', '', 'Admin Demo', 'completed', NULL, '2026-03-24 13:41:52'),
(26, 0, 'REC-56778B', 184.50, 0.00, 150.00, -34.50, 'Cash', 'Walk-in Customer', '', '', 'Admin Demo', 'completed', NULL, '2026-03-24 13:42:29'),
(27, 0, 'REC-8D3E04', 383.76, 0.00, 200.00, -183.76, 'Cash', 'Walk-in Customer', '', '', 'Admin Demo', 'completed', NULL, '2026-03-24 13:48:40'),
(28, 0, 'REC-C03D67', 369.00, 0.00, 700.00, 331.00, 'Cash', 'Walk-in Customer', '', '', 'Admin Demo', 'voided', NULL, '2026-03-24 18:12:12'),
(29, 0, 'REC-31E8DF', 369.00, 0.00, 500.00, 131.00, 'Cash', 'Walk-in Customer', '', '', 'Admin Demo', 'voided', 'Customer Return', '2026-03-24 18:52:03'),
(30, 0, 'REC-255909', 12299.96, 0.00, 15000.00, 2700.04, 'Cash', 'Walk-in Customer', '', '', 'Admin Demo', 'voided', NULL, '2026-03-24 20:35:30'),
(31, 0, 'REC-95C942', 12300.00, 0.00, 12300.00, 0.00, 'POS', 'Walk-in Customer', '', '', 'Admin Demo', 'voided', NULL, '2026-03-24 20:43:05'),
(32, 0, 'REC-E9E9F0', 1104.00, 0.00, 2000.00, 896.00, 'Cash', 'Walk-in Customer', '', '', 'Admin Demo', 'voided', NULL, '2026-03-24 20:44:46'),
(33, 0, 'REC-2A9967', 1230.00, 0.00, 2000.00, 770.00, 'Cash', 'Walk-in Customer', '', '', 'Admin Demo', 'voided', NULL, '2026-03-24 20:50:26'),
(34, 0, 'REC-00A232', 640.00, 0.00, 1000.00, 360.00, 'Cash', 'Walk-in Customer', '', '', 'Admin Demo', 'voided', NULL, '2026-03-24 20:56:00'),
(35, 0, 'REC-99DD60', 576.00, 0.00, 600.00, 24.00, 'Cash', 'Walk-in Customer', '', '', 'Admin Demo', 'voided', 'Customer Return', '2026-03-24 20:57:13'),
(36, 0, 'REC-6BF578', 110.40, 0.00, 150.00, 39.60, 'Cash', 'Walk-in Customer', '', '', 'Admin Demo', 'voided', NULL, '2026-03-24 20:57:58'),
(37, 0, 'REC-B6A12D', 2460.00, 0.00, 3000.00, 540.00, 'Cash', 'Walk-in Customer', '', '', 'Admin Demo', 'voided', NULL, '2026-03-24 21:30:19'),
(38, 0, 'REC-95FAB5', 246.00, 0.00, 300.00, 54.00, 'Cash', 'Walk-in Customer', '', '', 'Admin Demo', 'voided', NULL, '2026-03-24 21:34:17'),
(39, 1, 'REC-16A418', 11.04, 0.00, 20.00, 8.96, 'Cash', 'Walk-in Customer', '', '', 'Admin Demo', 'completed', NULL, '2026-03-24 22:04:01'),
(40, 1, 'REC-C50FDC', 20.00, 0.00, 20.00, 0.00, 'Cash', 'Walk-in Customer', '', '', 'Admin Demo', 'completed', NULL, '2026-03-24 22:06:52'),
(41, 1, 'REC-E2B246', 246.00, 0.00, 250.00, 4.00, 'Cash', 'Walk-in Customer', '', NULL, 'Admin Demo', 'completed', NULL, '2026-03-24 22:15:10'),
(42, 1, 'REC-F75137', 128.00, 0.00, 130.00, 2.00, 'Cash', 'andrew store', '', NULL, 'Admin Demo', 'completed', NULL, '2026-03-24 22:17:51'),
(43, 0, 'REC-BAE547', 246.00, 0.00, 250.00, 4.00, 'Cash', 'Walk-in Customer', '', NULL, 'Admin Demo', 'completed', NULL, '2026-03-24 22:18:19'),
(44, 0, 'REC-D28C54', 123.00, 0.00, 130.00, 7.00, 'Cash', 'ee', '', '', 'Admin Demo', 'completed', NULL, '2026-03-24 22:20:13');

--
-- Triggers `transactions`
--
DELIMITER $$
CREATE TRIGGER `after_transaction_void` AFTER UPDATE ON `transactions` FOR EACH ROW BEGIN
    -- This fires only when a status changes from 'completed' to 'voided'
    IF NEW.status = 'voided' AND OLD.status = 'completed' THEN
        
        -- Automatically update the products table for ALL items in this transaction
        UPDATE products p
        JOIN transaction_items ti ON p.id = ti.product_id
        SET 
            p.stock = p.stock + ti.quantity,
            p.total_sold = p.total_sold - ti.quantity,
            p.total_earned_on_item = p.total_earned_on_item - (ti.quantity * ti.price_at_sale)
        WHERE ti.transaction_id = NEW.id;
        
    END IF;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `transaction_items`
--

CREATE TABLE `transaction_items` (
  `id` int(11) NOT NULL,
  `transaction_id` int(11) DEFAULT NULL,
  `product_id` int(11) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `price_at_sale` decimal(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `transaction_items`
--

INSERT INTO `transaction_items` (`id`, `transaction_id`, `product_id`, `quantity`, `price_at_sale`) VALUES
(1, 12, 1, 10, 10.00),
(2, 13, 1, 2, 10.00),
(3, 14, 4, 4, 15.00),
(4, 16, 2, 6, 8.00),
(5, 17, 3, 1, 32.00),
(6, 17, 1, 3, 10.00),
(7, 18, 1, 3, 10.00),
(8, 19, 1, 2, 10.00),
(9, 20, 1, 4, 10.00),
(10, 21, 1, 49, 10.00),
(11, 22, 5, 1, 10.00),
(12, 23, 1, 4, 1.00),
(13, 23, 1, 3, 1.00),
(14, 24, 2, 2, 123.00),
(15, 24, 2, 2, 123.00),
(16, 25, 3, 3, 32.00),
(17, 26, 2, 1, 123.00),
(18, 27, 2, 3, 123.00),
(19, 28, 2, 3, 123.00),
(20, 29, 2, 3, 123.00),
(21, 30, 2, 100, 123.00),
(22, 31, 2, 100, 123.00),
(23, 32, 4, 100, 11.04),
(24, 33, 2, 10, 123.00),
(25, 34, 3, 20, 32.00),
(26, 35, 3, 18, 32.00),
(27, 36, 4, 10, 11.04),
(28, 37, 2, 20, 123.00),
(29, 38, 2, 2, 123.00),
(30, 39, 4, 1, 11.04),
(31, 40, 5, 2, 10.00),
(32, 41, 2, 2, 123.00),
(33, 42, 3, 4, 32.00),
(34, 43, 2, 2, 123.00),
(35, 44, 2, 1, 123.00);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('admin','staff') NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `role`, `created_at`) VALUES
(1, 'admin', '$2y$10$J9As/JJF5gYDt2hlqq6QWuFwmvscisZGvgnwkM69KvyHq558RN036', 'admin', '2026-03-24 17:55:23'),
(2, 'staff', '$2y$10$j9PWH.yy3xc48IPeOLbOn.kun7SE2.uuZODOQwzIILvT3os88/aTO', 'staff', '2026-03-24 17:55:31');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `expenses`
--
ALTER TABLE `expenses`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `idx_item_code` (`item_code`),
  ADD KEY `idx_product_name` (`name`),
  ADD KEY `idx_search` (`name`,`item_code`);

--
-- Indexes for table `product_logs`
--
ALTER TABLE `product_logs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`setting_key`);

--
-- Indexes for table `stores`
--
ALTER TABLE `stores`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `transactions`
--
ALTER TABLE `transactions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `transaction_items`
--
ALTER TABLE `transaction_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `transaction_id` (`transaction_id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `expenses`
--
ALTER TABLE `expenses`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `product_logs`
--
ALTER TABLE `product_logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- AUTO_INCREMENT for table `stores`
--
ALTER TABLE `stores`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `transactions`
--
ALTER TABLE `transactions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;

--
-- AUTO_INCREMENT for table `transaction_items`
--
ALTER TABLE `transaction_items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `transaction_items`
--
ALTER TABLE `transaction_items`
  ADD CONSTRAINT `transaction_items_ibfk_1` FOREIGN KEY (`transaction_id`) REFERENCES `transactions` (`id`),
  ADD CONSTRAINT `transaction_items_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
