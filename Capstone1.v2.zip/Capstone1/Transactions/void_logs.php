<?php
session_start();
include '../db.php';

// Only allow Admins to view this page
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit();
}

// Fetch only voided transactions
$query = "SELECT * FROM transactions WHERE status = 'voided' ORDER BY date_created DESC";
$result = $conn->query($query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Voided Transactions Log</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="style.css">
</head>
<body>

<nav class="navbar">
    <ul class="navbar-links">
        <li><a href="../Dashboard/dashboard.php"><i class="fa fa-tachometer-alt"></i> Dashboard</a></li>
        <li><a href="transaction_logs.php"><i class="fa fa-history"></i> Back to All Logs</a></li>
    </ul>
</nav>

<div class="table-area">
    <div class="table-header" style="background-color: #e74c3c;">
        <span><i class="fa fa-ban"></i> VOIDED TRANSACTIONS HISTORY</span>
    </div>

    <table>
        <thead>
            <tr>
                <th>Receipt No.</th>
                <th>Voided Date</th>
                <th>Staff in Charge</th>
                <th>Customer</th>
                <th>Amount Lost</th>
                <th>Action</th>
                <th>Reason for Void</th>
            </tr>
        </thead>
        <tbody>
            <?php if($result->num_rows > 0): ?>
                <?php while($row = $result->fetch_assoc()): ?>
                <tr style="background-color: #fff5f5;">
                    <td style="font-weight:bold; color: #c0392b;"><?= $row['receipt_no'] ?></td>
                    <td><?= date('M d, Y | h:i A', strtotime($row['date_created'])) ?></td>
                    <td><?= $row['staff_name'] ?></td>
                    <td><?= htmlspecialchars($row['customer_name']) ?></td>
                    <td style="color: #c0392b; font-weight: bold;">₱<?= number_format($row['total_amount'], 2) ?></td>
                    <td>
                        <a href="print_receipt.php?id=<?= $row['id'] ?>" class="btn btn-blue" style="padding: 5px 10px;">
                            <i class="fa fa-eye"></i> View Details
                        </a>
                    </td>
                    <td style="font-style: italic; color: #666;">
                        <?= htmlspecialchars($row['void_reason'] ?? 'N/A') ?>
                    </td>
                </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr><td colspan="6" align="center">No voided transactions found.</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

</body>
</html>