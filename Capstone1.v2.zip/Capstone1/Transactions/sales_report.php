<?php 
include '../db.php'; 

// Set the date for the report (default to today)
$report_date = isset($_GET['date']) ? $_GET['date'] : date('Y-m-d');

// 1. Fetch Summary Data (Excludes voided transactions)
$summary_query = $conn->prepare("SELECT 
    COUNT(id) as total_tx, 
    SUM(total_amount) as total_sales,
    AVG(total_amount) as avg_value
    FROM transactions 
    WHERE DATE(date_created) = ? AND status = 'completed'");
$summary_query->bind_param("s", $report_date);
$summary_query->execute();
$summary = $summary_query->get_result()->fetch_assoc();

// 2. Fetch Most Sold Items (Only from completed transactions)
$items_query = $conn->prepare("SELECT p.name, SUM(ti.quantity) as qty_sold, SUM(ti.quantity * ti.price_at_sale) as revenue
    FROM transaction_items ti
    JOIN products p ON ti.product_id = p.id
    JOIN transactions t ON ti.transaction_id = t.id
    WHERE DATE(t.date_created) = ? AND t.status = 'completed'
    GROUP BY ti.product_id
    ORDER BY qty_sold DESC LIMIT 5");
$items_query->bind_param("s", $report_date);
$items_query->execute();
$top_items = $items_query->get_result();

// 3. Fetch Transaction List (Shows only completed sales for the revenue table)
$list_query = $conn->prepare("SELECT * FROM transactions 
                             WHERE DATE(date_created) = ? AND status = 'completed' 
                             ORDER BY date_created DESC");
$list_query->bind_param("s", $report_date);
$list_query->execute();
$transactions = $list_query->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Daily Sales Report - <?= $report_date ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="style.css">
    <style>
        .report-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 20px; margin-bottom: 20px; }
        .stat-card { background: #fff; padding: 20px; border-radius: 8px; border-left: 5px solid #337ab7; box-shadow: 0 2px 5px rgba(0,0,0,0.1); }
        .stat-card h3 { margin: 0; color: #666; font-size: 14px; text-transform: uppercase; }
        .stat-card p { margin: 10px 0 0; font-size: 24px; font-weight: bold; color: #333; }
        @media print { .no-print { display: none; } }
    </style>
</head>
<body>

<nav class="navbar no-print">
    <ul class="navbar-links">
        <li><a href="../Dashboard/dashboard.php"><i class="fa fa-tachometer-alt"></i> Dashboard</a></li>
        <li><a href="transaction.php"><i class="fa fa-exchange-alt"></i> Back to Sales</a></li>
    </ul>
</nav>

<div class="table-area">
    <div class="table-header" style="display: flex; justify-content: space-between; align-items: center;">
        <span>SALES REPORT: <?= date('M d, Y', strtotime($report_date)) ?></span>
        <div class="no-print">
            <form method="GET" style="display: inline-block;">
                <input type="date" name="date" value="<?= $report_date ?>" onchange="this.form.submit()">
            </form>
            <button class="btn btn-blue" onclick="window.print()"><i class="fa fa-print"></i> Print Report</button>
        </div>
    </div>

    <div class="report-grid">
        <div class="stat-card">
            <h3>Total Revenue</h3>
            <p>₱<?= number_format($summary['total_sales'] ?? 0, 2) ?></p>
        </div>
        <div class="stat-card" style="border-left-color: #2ecc71;">
            <h3>Transactions</h3>
            <p><?= $summary['total_tx'] ?? 0 ?></p>
        </div>
        <div class="stat-card" style="border-left-color: #f1c40f;">
            <h3>Avg. Basket Value</h3>
            <p>₱<?= number_format($summary['avg_value'] ?? 0, 2) ?></p>
        </div>
    </div>

    <div style="display: grid; grid-template-columns: 2fr 1.2fr; gap: 20px;">
        <div>
            <h4 style="margin-bottom:10px;">Transactions Detail</h4>
            <table>
                <thead>
                    <tr>
                        <th>Receipt No</th>
                        <th>Customer</th>
                        <th>Time</th>
                        <th>Amount</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if($transactions->num_rows > 0): ?>
                        <?php while($row = $transactions->fetch_assoc()): ?>
                        <tr>
                            <td style="font-weight:bold; color:#337ab7;"><?= $row['receipt_no'] ?></td>
                            <td><?= htmlspecialchars($row['customer_name']) ?></td>
                            <td><?= date('H:i A', strtotime($row['date_created'])) ?></td>
                            <td>₱<?= number_format($row['total_amount'], 2) ?></td>
                        </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr><td colspan="4" align="center">No transactions recorded for this day.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <div>
            <h4 style="margin-bottom:10px;">Best Sellers (Today)</h4>
            <table style="font-size: 0.9em;">
                <thead>
                    <tr><th>Item</th><th>Qty</th><th>Rev.</th></tr>
                </thead>
                <tbody>
                    <?php while($item = $top_items->fetch_assoc()): ?>
                    <tr>
                        <td><?= htmlspecialchars($item['name']) ?></td>
                        <td><?= $item['qty_sold'] ?></td>
                        <td>₱<?= number_format($item['revenue'], 2) ?></td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

</body>
</html>