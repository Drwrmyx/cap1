/**
 * TRANSACTION SYSTEM SCRIPT
 */

// Initialize Select2 on existing dropdowns when the page loads
$(document).ready(function() {
    initSelect2($('.product-select'));
});

// Helper to set up Select2 with the "select2:select" event
// Helper function to apply Select2 logic
function initSelect2(element) {
    element.select2({
        placeholder: "Search for a product...",
        allowClear: false, // Change this from true to false
        width: '100%'
    }).on('select2:select', function (e) {
        updateRow(this);
    });
}

// THE FIXED ADD ITEM FUNCTION
function addItemRow() {
    const container = document.getElementById('item-list');
    const firstRow = container.querySelector('.item-row');
    
    // 1. Clone the row
    const newRow = firstRow.cloneNode(true);
    
    // 2. IMPORTANT: Remove any existing Select2 search bar/container from the clone
    const oldSelect2Container = newRow.querySelector('.select2-container');
    if (oldSelect2Container) oldSelect2Container.remove();

    // 3. CLEAN THE SELECT: Remove classes and internal Select2 data
    const select = newRow.querySelector('select');
    $(select).removeClass('select2-hidden-accessible'); // Remove "already initialized" flag
    $(select).removeAttr('data-select2-id');           // Remove Select2 unique ID
    $(select).find('option').removeAttr('data-select2-id').prop('disabled', false).show();
    $(select).val(null); // Reset selection

    // 4. Reset other input fields
    newRow.querySelectorAll('input').forEach(i => {
        i.value = '';
        i.style.borderColor = ''; 
    });
    newRow.querySelector('.row-qty').value = 0;
    newRow.querySelector('.row-total').value = '0.00';
    
    // 5. Add to page and Re-initialize Select2 specifically for this new select
    container.appendChild(newRow);
    initSelect2($(select));
    
    updateAvailableOptions();
}

// Updates the price and stock when a product is picked
function updateRow(select) {
    const row = $(select).closest('.item-row');
    const opt = select.options[select.selectedIndex];
    
    // Pull data from the <option> attributes in transaction.php
    row.find('.row-stock').val($(opt).data('stock') || 0);
    row.find('.row-price').val($(opt).data('price') || 0);
    
    calculateRow(row.find('.row-qty')[0]);
    updateAvailableOptions();
}

// Hides selected products from other dropdowns to prevent duplicates
function updateAvailableOptions() {
    const selects = $('select[name="product_id[]"]');
    const selectedValues = selects.map(function() { return $(this).val(); }).get().filter(v => v !== "");

    selects.each(function() {
        const currentSelect = $(this);
        const currentValue = currentSelect.val();
        
        currentSelect.find('option').each(function() {
            const optionValue = $(this).val();
            if (optionValue === "") return;

            // Disable if picked in another row
            const isSelectedElsewhere = selectedValues.includes(optionValue) && optionValue !== currentValue;
            $(this).prop('disabled', isSelectedElsewhere);
        });
        
        // Refresh Select2 to show/hide the disabled items
        currentSelect.trigger('change.select2');
    });
}

function removeRow(btn) {
    // Check if there's more than one row
    if (document.querySelectorAll('.item-row').length > 1) {
        btn.closest('.item-row').remove();
        
        // Recalculate totals after removal
        calculateGrandTotal();
        
        // NEW: If you are using the "disappearing" searchable logic, 
        // call this to make the item available in other dropdowns again
        if (typeof updateAvailableOptions === "function") {
            updateAvailableOptions();
        }
    } else {
        // Provide feedback so the user knows why it didn't remove
        alert("Transaction must have at least one item.");
    }
}

// Calculates row total and validates against available stock
function calculateRow(input) {
    const row = input.closest('.item-row');
    const qty = parseFloat(input.value) || 0;
    const price = parseFloat(row.querySelector('.row-price').value) || 0;
    const stock = parseFloat(row.querySelector('.row-stock').value) || 0;

    // Safety Check: Prevent selling more than available stock
    if (qty > stock) {
        alert("Error: Quantity exceeds available stock (" + stock + ").");
        input.value = stock;
        input.style.borderColor = "red";
        setTimeout(() => { input.style.borderColor = ""; }, 2000);
        calculateRow(input); 
        return;
    }

    row.querySelector('.row-total').value = (qty * price).toFixed(2);
    calculateGrandTotal();
}

// Synchronizes percentage and flat-value discounts
function syncDiscount(type) {
    let subtotal = 0;
    document.querySelectorAll('.row-total').forEach(i => subtotal += parseFloat(i.value) || 0);
    
    const discP = document.getElementsByName('discount_percent')[0];
    const discV = document.getElementsByName('discount_val')[0];
    
    if (subtotal > 0) {
        if (type === 'percent') {
            discV.value = ((parseFloat(discP.value || 0) / 100) * subtotal).toFixed(2);
        } else {
            discP.value = ((parseFloat(discV.value || 0) / subtotal) * 100).toFixed(2);
        }
    }
    calculateGrandTotal();
}

// Calculates final amount including VAT and Discounts
function calculateGrandTotal() {
    let subtotal = 0;
    document.querySelectorAll('.row-total').forEach(i => subtotal += parseFloat(i.value) || 0);
    
    const vatP = parseFloat(document.getElementsByName('vat')[0].value) || 0;
    const discV = parseFloat(document.getElementsByName('discount_val')[0].value) || 0;
    
    let total = (subtotal + (subtotal * (vatP / 100))) - discV;
    document.getElementById('grand-total').value = total.toFixed(2);
    calculateChange();
}

// Calculates change based on the amount tendered
function calculateChange() {
    const total = parseFloat(document.getElementById('grand-total').value) || 0;
    const tendered = parseFloat(document.getElementById('tendered').value) || 0;
    document.getElementById('change-due').value = (tendered - total).toFixed(2);
}

// Function to clear the entire order with a confirmation prompt
function confirmClearOrder() {
    if (confirm("Are you sure you want to clear the entire order? All added items and customer details will be removed.")) {
        const form = document.querySelector('form[action="process_transaction.php"]');
        
        // 1. Reset standard form fields (Customer info, VAT, etc.)
        form.reset();

        // 2. Remove all rows except the first one
        const rows = document.querySelectorAll('.item-row');
        for (let i = 1; i < rows.length; i++) {
            rows[i].remove();
        }

        // 3. Reset the first row's searchable dropdown
        const firstSelect = $('.product-select').first();
        firstSelect.val(null).trigger('change');

        // 4. Reset calculations
        calculateGrandTotal();
        
        // 5. Make all items available in the dropdown again
        if (typeof updateAvailableOptions === "function") {
            updateAvailableOptions();
        }
        
        alert("Order has been cleared.");
    }
}

/**
 * Final Validation before submitting the order
 */
function validateOrder() {
    const totalAmount = parseFloat(document.getElementById('grand-total').value) || 0;
    const tendered = parseFloat(document.getElementById('tendered').value) || 0;
    
    // 1. Ensure at least one product is selected with a quantity
    let hasItems = false;
    document.querySelectorAll('.item-row').forEach(row => {
        const productId = row.querySelector('select[name="product_id[]"]').value;
        const qty = parseFloat(row.querySelector('.row-qty').value) || 0;
        if (productId !== "" && qty > 0) {
            hasItems = true;
        }
    });

    if (!hasItems) {
        alert("Error: You must select at least one item with a quantity greater than zero.");
        return false; // Blocks form submission
    }

    // 2. Ensure payment is sufficient
    if (tendered < totalAmount) {
        alert("Error: Amount Tendered is less than the Grand Total. Please check the payment.");
        document.getElementById('tendered').focus();
        return false; // Blocks form submission
    }

    // 3. Final Confirmation Prompt
    return confirm("Are you sure you want to confirm this order? Total Amount: ₱" + totalAmount.toFixed(2));
}