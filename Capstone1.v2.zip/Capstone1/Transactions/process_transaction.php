<?php
include '../db.php';
include 'functions.php'; // Link the new functions file

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $receipt = generateReceiptNo();
    
    $store_id = isset($_POST['store_id']) ? (int)$_POST['store_id'] : 0;

    // --- NEW NAME LOGIC ---
    $manual_name = trim($_POST['cust_name']);
    $customer_name = "";

    if (!empty($manual_name)) {
        // 1. If you typed a name for a "random person", use that first
        $customer_name = $manual_name;
    } elseif ($store_id > 0) {
        // 2. If no name was typed but a Store was selected, get the Store Name from DB
        $store_query = $conn->prepare("SELECT store_name FROM stores WHERE id = ?");
        $store_query->bind_param("i", $store_id);
        $store_query->execute();
        $result = $store_query->get_result();
        if ($row = $result->fetch_assoc()) {
            $customer_name = $row['store_name'];
        }
    } else {
        // 3. If everything is empty, default to Walk-in
        $customer_name = "Walk-in Customer";
    }
    // Collect VAT from the form
    $vat_percent = isset($_POST['vat']) ? (float)$_POST['vat'] : 0;
    $total_amount = (float)$_POST['total_amount'];
    
    // Calculate how much of that total was actually VAT
    // (If your total already includes VAT, use this math)
    $vat_amount = calculateVATAmount($total_amount, $vat_percent);

    $tendered = $_POST['tendered'];
    $change   = $_POST['change'];
    $pay_mode = $_POST['payment_mode'];
    $name     = !empty($_POST['cust_name']) ? $_POST['cust_name'] : 'Walk-in Customer';    
    $phone    = $_POST['cust_phone'];
    $email    = $_POST['cust_email'];

    $conn->begin_transaction();

    try {
            // Use $customer_name in the bind_param
            $stmt = $conn->prepare("INSERT INTO transactions (store_id, receipt_no, total_amount, vat_amount, amount_tendered, change_due, mode_of_payment, customer_name, customer_phone, customer_email) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            
            $stmt->bind_param("isddddssss", $store_id, $receipt, $total_amount, $vat_amount, $tendered, $change, $pay_mode, $customer_name, $phone, $email);
            $stmt->execute();
            
            $last_id = $conn->insert_id;

        // 4. Update Product Stock and Record Items
        foreach ($_POST['product_id'] as $key => $prod_id) {
            $qty = (int)$_POST['qty'][$key];
            
            if ($qty > 0) {
                // --- ADDED STOCK CHECK ---
                // Fetch current stock and price to verify availability
                $check_query = $conn->prepare("SELECT stock, price, name FROM products WHERE id = ?");
                $check_query->bind_param("i", $prod_id);
                $check_query->execute();
                $product = $check_query->get_result()->fetch_assoc();

                if ($product['stock'] < $qty) {
                    // This will trigger the catch block below and roll back all changes
                    throw new Exception("Insufficient stock for item: " . $product['name'] . ". Available: " . $product['stock']);
                }
                // --- END OF STOCK CHECK ---

                $current_price = $product['price'];

                // Record the specific item sold
                $item_stmt = $conn->prepare("INSERT INTO transaction_items (transaction_id, product_id, quantity, price_at_sale) VALUES (?, ?, ?, ?)");
                $item_stmt->bind_param("iiid", $last_id, $prod_id, $qty, $current_price);
                $item_stmt->execute();

                // Deduct stock and increment earnings
                $update_stmt = $conn->prepare("UPDATE products SET 
                                            stock = stock - ?, 
                                            total_sold = total_sold + ?,
                                            total_earned_on_item = total_earned_on_item + (? * ?)
                                            WHERE id = ?");
                $update_stmt->bind_param("iiddi", $qty, $qty, $current_price, $qty, $prod_id);
                $update_stmt->execute();
            }
        }

        $conn->commit();
                header("Location: print_receipt.php?id=" . $last_id);
                exit(); 
            } catch (Exception $e) {
                $conn->rollback();
                die("Transaction failed: " . $e->getMessage());
            }
} else {
    echo $last_id; 
    exit();
}
?>