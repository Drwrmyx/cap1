<?php
include '../auth.php'; // This handles session_start() and the login check
include '../db.php';

// The rest of your code...

// ... (rest of your search logic) ...

// Search logic
$search = isset($_GET['search']) ? mysqli_real_escape_string($conn, $_GET['search']) : '';
$query = "SELECT * FROM transactions WHERE receipt_no LIKE '%$search%' OR customer_name LIKE '%$search%' ORDER BY date_created DESC";
$result = $conn->query($query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Transaction Logs</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="style.css">
</head>
<body>

<nav class="navbar no-print">
    <ul class="navbar-links">
        <li><a href="../Dashboard/dashboard.php"><i class="fa fa-tachometer-alt"></i> Dashboard</a></li>
        <li><a href="transaction.php"><i class="fa fa-exchange-alt"></i> New Transaction</a></li>
        <li><a href="sales_report.php"><i class="fa fa-chart-line"></i> Daily Report</a></li>
        <li><a href="transaction_logs.php"><i class="fa fa-history"></i> Transaction Logs</a></li>
        <li>
    <a href="void_logs.php" style="color: #e74c3c;">
        <i class="fa fa-ban"></i> Void Logs
    </a>
</li>
    </ul>
</nav>

<div class="table-area">
    <div class="table-header">
        <span><i class="fa fa-history"></i> ALL TRANSACTION LOGS</span>
        <form method="GET" style="display: flex; gap: 5px;">
            <input type="text" name="search" placeholder="Search Receipt/Customer..." value="<?= htmlspecialchars($search) ?>" style="padding: 5px; border-radius: 4px; border: 1px solid #ddd;">
            <button type="submit" class="btn btn-blue">Search</button>
        </form>
    </div>

    <table>
        <thead>
            <tr>
                <th>Receipt No.</th>
                <th>Date & Time</th>
                <th>Staff</th>
                <th>Customer</th>
                <th>Total</th>
                <th>Payment</th>
                <th>Action</th>
            </tr>
        </thead>
<tbody>
    <?php if($result->num_rows > 0): ?>
        <?php while($row = $result->fetch_assoc()): ?>
        <tr style="<?= $row['status'] == 'voided' ? 'opacity: 0.5; background: #f9f9f9;' : '' ?>">
            <td style="font-weight:bold;"><?= $row['receipt_no'] ?></td>
            <td><?= date('M d, Y', strtotime($row['date_created'])) ?></td>
            <td><?= $row['staff_name'] ?></td>
            <td>
                <?php if($row['status'] == 'voided'): ?>
                    <span style="color:red; font-weight:bold;">[VOIDED]</span>
                <?php else: ?>
                    <?= htmlspecialchars($row['customer_name']) ?>
                <?php endif; ?>
            </td>
            <td>₱<?= number_format($row['total_amount'], 2) ?></td>
            
            <td><?= $row['mode_of_payment'] ?></td>

            <td>
                <a href="print_receipt.php?id=<?= $row['id'] ?>" class="btn btn-blue" style="padding:4px 8px;">View</a>
                
                <?php if(isset($_SESSION['role']) && $_SESSION['role'] == 'admin' && $row['status'] == 'completed'): ?>
                    <a href="#" 
                       onclick="voidWithReason(<?= $row['id'] ?>)" 
                       class="btn" style="background:#e74c3c; color:white; padding:4px 8px;">Void</a>
                <?php endif; ?>
            </td>
        </tr>
        <?php endwhile; ?>
    <?php else: ?>
        <tr><td colspan="7" align="center">No transactions found.</td></tr>
    <?php endif; ?>
</tbody>

<script>
function voidWithReason(id) {
    // Ask the user for the reason
    let reason = prompt("Please enter the reason for voiding this transaction:", "Customer Return");
    
    // If the user didn't hit 'Cancel' and the reason isn't empty
    if (reason != null && reason.trim() !== "") {
        // Send the ID and the Reason to your PHP file
        window.location.href = "void_transaction.php?id=" + id + "&reason=" + encodeURIComponent(reason);
    } else if (reason != null) {
        alert("Action canceled. You must provide a reason to void a transaction.");
    }
}
</script>
    </table>
</div>

</body>
</html>