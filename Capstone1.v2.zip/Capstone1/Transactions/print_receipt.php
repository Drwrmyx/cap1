<?php
include '../db.php';
include 'functions.php'; // Link the new functions file

// 1. Get Transaction ID
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

// 2. Fetch Transaction Details
$stmt = $conn->prepare("SELECT * FROM transactions WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$res = $stmt->get_result();

if ($res->num_rows == 0) {
    die("Error: Transaction not found.");
}
$data = $res->fetch_assoc();

// 3. Fetch Sold Items
$items_query = "SELECT ti.*, p.name 
                FROM transaction_items ti 
                JOIN products p ON ti.product_id = p.id 
                WHERE ti.transaction_id = $id";
$items_res = $conn->query($items_query);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Receipt - <?php echo $data['receipt_no']; ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="style.css">
    <style>
        /* This ensures the receipt looks like a paper slip on screen */
        #receipt-print-area {
            width: 350px;
            margin: 30px auto;
            padding: 20px;
            background: #fff;
            border: 1px solid #ddd;
            position: relative;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
            font-family: 'Courier New', Courier, monospace;
        }

        .void-stamp {
            position: absolute;
            top: 45%;
            left: 50%;
            transform: translate(-50%, -50%) rotate(-45deg);
            color: rgba(231, 76, 60, 0.2);
            font-size: 60px;
            font-weight: bold;
            border: 6px solid rgba(231, 76, 60, 0.2);
            padding: 10px;
            z-index: 100;
            pointer-events: none;
            text-transform: uppercase;
        }

        .text-center { text-align: center; }
        .text-right { text-align: right; }
        .divider { border-top: 1px dashed #000; margin: 10px 0; }
        
        /* Button Styling */
        .receipt-actions { text-align: center; margin-bottom: 50px; }
        .btn-print { background-color: #2ecc71; color: white; padding: 12px 24px; font-size: 16px; border: none; border-radius: 4px; cursor: pointer; }
        .btn-print:hover { background-color: #27ae60; }

        /* Hide everything except the receipt during printing */
        @media print {
            .no-print { display: none !important; }
            body { background: white; margin: 0; padding: 0; }
            #receipt-print-area { 
                border: none; 
                box-shadow: none; 
                margin: 0; 
                width: 100%; 
            }
        }
    </style>
</head>
<body>

    <div id="receipt-print-area">
        
        <?php if(isset($data['status']) && $data['status'] == 'voided'): ?>
            <div class="void-stamp">VOIDED</div>
        <?php endif; ?>

        <div class="text-center">
            <h2 style="margin:0;">POS SYSTEM</h2>
            <p style="margin:5px 0;">Official Receipt</p>
        </div>
        
        <div class="divider"></div>
        
        <table style="width: 100%; font-size: 14px;">
            <tr><td>Receipt No:</td><td class="text-right"><strong><?php echo $data['receipt_no']; ?></strong></td></tr>
            <tr><td>Date:</td><td class="text-right"><?php echo date('M d, Y H:i', strtotime($data['date_created'])); ?></td></tr>
            <tr><td>Staff:</td><td class="text-right"><?php echo htmlspecialchars($data['staff_name']); ?></td></tr>
        </table>
        
        <div class="divider"></div>

        <table style="width: 100%; border-collapse: collapse; font-size: 14px;">
            <thead>
                <tr style="border-bottom: 1px solid #000;">
                    <th style="text-align:left;">Item</th>
                    <th style="text-align:center;">Qty</th>
                    <th style="text-align:right;">Total</th>
                </tr>
            </thead>
            <tbody>
                <?php while($item = $items_res->fetch_assoc()): ?>
                <tr>
                    <td style="padding: 5px 0;"><?php echo htmlspecialchars($item['name']); ?></td>
                    <td style="text-align:center;"><?php echo $item['quantity']; ?></td>
                    <td class="text-right">₱<?php echo number_format($item['quantity'] * $item['price_at_sale'], 2); ?></td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
        
        <div class="divider"></div>
        
        <table style="width: 100%; font-size: 15px;">
            <tr>
                <td><strong>GRAND TOTAL:</strong></td>
                <td class="text-right"><strong>₱<?php echo number_format($data['total_amount'], 2); ?></strong></td>
            </tr>
            <tr>
                <td>Cash Tendered:</td>
                <td class="text-right">₱<?php echo number_format($data['amount_tendered'], 2); ?></td>
            </tr>
            <tr>
                <td><strong>Change:</strong></td>
                <td class="text-right"><strong>₱<?php echo number_format($data['change_due'], 2); ?></strong></td>
            </tr>
            <tr>
                <td>Subtotal (Excl. VAT):</td>
                <td class="text-right"><?php echo formatPeso($data['total_amount'] - $data['vat_amount']); ?></td>
            </tr>
            <tr>
                <td>VAT Amount:</td>
                <td class="text-right"><?php echo formatPeso($data['vat_amount']); ?></td>
            </tr>
        </table>
        
        <div class="divider"></div>
        
        <div class="text-center" style="font-size: 12px; margin-top: 15px;">
            <p>Customer: <?php echo htmlspecialchars($data['customer_name']); ?></p>
            <p>Thank you for your patronage!</p>
        </div>
    </div>

    <div class="receipt-actions no-print">
        <button class="btn-print" onclick="window.print()">
            <i class="fa fa-print"></i> PRINT RECEIPT
        </button>
        <div style="margin-top: 15px;">
            <a href="transaction.php" class="btn btn-blue" style="text-decoration:none;">New Sale</a>
            <a href="transaction_logs.php" class="btn" style="background:#95a5a6; color:white; text-decoration:none; padding:8px 15px; border-radius:4px; margin-left:10px;">Logs</a>
        </div>
    </div>

</body>
</html>