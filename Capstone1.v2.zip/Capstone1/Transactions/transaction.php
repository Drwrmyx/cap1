<?php 
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit();
}
include '../db.php'; 
include 'functions.php'; // Link the new functions file

// --- 1. Logic for Search, Sort, and Pagination ---
$search = isset($_GET['search']) ? $conn->real_escape_string($_GET['search']) : '';
$sort = isset($_GET['sort']) ? $_GET['sort'] : 'date_desc';
$limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 10;

$sort_options = [
    'date_desc'   => "date_created DESC",
    'date_asc'    => "date_created ASC",
    'amount_high' => "total_amount DESC",
    'amount_low'  => "total_amount ASC",
    'name_asc'    => "customer_name ASC"
];
$sort_sql = $sort_options[$sort] ?? "date_created DESC";

$query = "SELECT * FROM transactions 
          WHERE receipt_no LIKE '%$search%' 
          OR customer_name LIKE '%$search%' 
          ORDER BY $sort_sql LIMIT $limit";
$history = $conn->query($query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Transaction System</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="style.css">
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>

    <style>
        /* Adjust height to match your theme */
        .select2-container .select2-selection--single {
            height: 38px !important;
            border: 1px solid #ddd !important;
        }
        .select2-container--default .select2-selection--single .select2-selection__rendered {
            line-height: 38px !important;
        }
    </style>
</head>
<body>

    <nav class="navbar">
        <a href="#" class="navbar-brand"></a>
        <ul class="navbar-links">
            <li><a href="../Dashboard/dashboard.php"><i class="fa fa-tachometer-alt"></i> Dashboard</a></li>
            
            <li><a href="../Products/products.php"><i class="fa fa-boxes"></i> Inventory</a></li>
            
            <li><a href="../Transactions/transaction.php" class="active"><i class="fa fa-exchange-alt"></i> Transactions</a></li>
            <li><a href="sales_report.php"><i class="fa fa-chart-line"></i> Sales Report</a></li>
                    <li><a href="transaction_logs.php"><i class="fa fa-history"></i> Transaction Logs</a></li>
                    <li style="margin-left: auto;">
    <a href="/Capstone1/logout.php" style="color: #e74c3c; font-weight: bold;" onclick="return confirm('Are you sure you want to logout?')">
        <i class="fa fa-sign-out-alt"></i> Logout (<?= htmlspecialchars($_SESSION['username']) ?>)
    </a>
</li>

        </ul>
    </nav>


<div class="card">
    <form id="transaction-form" action="process_transaction.php" method="POST" onsubmit="return validateOrder()">
        <div id="item-list">
            <div class="item-row">
                <div>
                    <label>Item</label>
                    <select name="product_id[]" class="product-select" required style="width: 100%;">
                        <option value="">Select Item</option>
                        <?php
                        $prods = $conn->query("SELECT * FROM products WHERE stock > 0");
                        while($p = $prods->fetch_assoc()) {
                            echo "<option value='{$p['id']}' data-price='{$p['price']}' data-stock='{$p['stock']}'>{$p['name']}</option>";
                        }
                        ?>
                    </select>
                </div>
                <div><label>Available</label><input type="text" class="row-stock" readonly style="background:#fff;"></div>
                <div><label>Unit Price</label><input type="text" class="row-price" readonly style="background:#fff;"></div>
                <div><label>Quantity</label><input type="number" name="qty[]" class="row-qty" oninput="calculateRow(this)" value="0" min="1"></div>
                <div><label>Total Price</label><input type="text" class="row-total" value="0.00" readonly style="background:#fff;"></div>
                <div><button type="button" class="btn btn-red" onclick="removeRow(this)" title="Remove Item"><i class="fa fa-trash-alt"></i></button></div>
            </div>
        </div>

        <button type="button" class="btn btn-blue" onclick="addItemRow()" style="margin-top: 10px;">+ Add Item</button>

        <div class="summary-grid">
            <div><label>VAT(%)</label><input type="number" name="vat" value="0" oninput="calculateGrandTotal()"></div>
            <div><label>Discount(%)</label><input type="number" name="discount_percent" value="0" oninput="syncDiscount('percent')"></div>
            <div><label>Discount(Value)</label><input type="number" step="0.01" name="discount_val" value="0.00" oninput="syncDiscount('value')"></div>
            <div>
                <label>Payment Mode</label>
                <select name="payment_mode">
                    <option>Cash</option>
                    <option>POS</option>
                    <option>Transfer</option>
                </select>
            </div>
        </div>

        <div class="full-row">
            <div><label>Cumulative Amount</label><input type="text" id="grand-total" name="total_amount" value="0.00" readonly style="background:#fff; font-weight:bold; color: #337ab7;"></div>
            <div><label>Amount Tendered</label><input type="number" id="tendered" name="tendered" oninput="calculateChange()" required></div>
            <div><label>Change Due</label><input type="text" id="change-due" name="change" value="0.00" readonly style="background:#fff;"></div>
        </div>


                
            <div class="full-row">
                <div>
                    <label>Registered Store</label>
                    <select name="store_id" class="product-select" style="width: 100%;">
                        <option value="0">-- Select Store (Optional) --</option>
                        <?php
                        $store_list = $conn->query("SELECT id, store_name FROM stores WHERE status = 'Active' ORDER BY store_name ASC");
                        while($st = $store_list->fetch_assoc()) {
                            echo "<option value='{$st['id']}'>".htmlspecialchars($st['store_name'])."</option>";
                        }
                        ?>
                    </select>
                </div>
                <div>
                    <label>Manual Name (For Random Person)</label>
                    <input type="text" name="cust_name" placeholder="Type name here to override store name">
                </div>
                <div>
                    <label>Phone #</label>
                    <input type="text" name="cust_phone" placeholder="Contact number">
                </div>
            </div>
            <div>   
                <label>Email</label>
                <input type="email" name="cust_email" placeholder="Email">
            </div>

        </div>

        <div style="text-align: right; margin-top: 20px;">
            <button type="submit" class="btn btn-blue" style="padding: 10px 40px;">Confirm Order</button>
            <button type="button" class="btn btn-red" onclick="confirmClearOrder()">Clear Order</button>
        </div>
    </form>
</div>

<div class="filter-row">
    <div>
        Show 
        <select onchange="location.href='?limit='+this.value+'&sort=<?= $sort ?>&search=<?= $search ?>'">
            <option value="10" <?= $limit==10?'selected':'' ?>>10</option>
            <option value="25" <?= $limit==25?'selected':'' ?>>25</option>
            <option value="50" <?= $limit==50?'selected':'' ?>>50</option>
        </select> per page
    </div>
    <div>
        Sort by 
        <select onchange="location.href='?sort='+this.value+'&limit=<?= $limit ?>&search=<?= $search ?>'">
            <option value="date_desc" <?= $sort=='date_desc'?'selected':'' ?>>date(Latest First)</option>
            <option value="amount_high" <?= $sort=='amount_high'?'selected':'' ?>>Total Amount Spent (Highest first)</option>
            <option value="name_asc" <?= $sort=='name_asc'?'selected':'' ?>>Customer Name (A-Z)</option>
        </select>
    </div>
    <form method="GET" class="search-container">
        <i class="fa fa-search"></i>
        <input type="text" name="search" placeholder="Search Transactions" value="<?= htmlspecialchars($search) ?>">
    </form>
</div>

<div class="table-area">
    <div class="table-header">RECENT TRANSACTIONS</div>
    <table>
        <thead>
            <tr>
                <th>SN</th>
                <th>Receipt No</th>
                <th>Amount</th>
                <th>Tendered</th>
                <th>Change</th>
                <th>Customer</th>
                <th>Date</th>
                <th>Print</th> </tr>
        </thead>
        <tbody>
            <?php
            // DELETE OR COMMENT OUT THIS LINE BELOW:
            // $history = $conn->query("SELECT * FROM transactions ORDER BY date_created DESC LIMIT 10");
            
            $sn = 1;
            while($row = $history->fetch_assoc()): ?>
            <tr>
                <td><?= $sn++ ?>.</td>
                <td style="color:#337ab7; font-weight:bold;"><?= $row['receipt_no'] ?></td>
                <td>₱<?= number_format($row['total_amount'], 2) ?></td>
                <td>₱<?= number_format($row['amount_tendered'], 2) ?></td>
                <td>₱<?= number_format($row['change_due'], 2) ?></td>
                <td><?= htmlspecialchars($row['customer_name']) ?></td>
                <td><?= date('Y-m-d H:i', strtotime($row['date_created'])) ?></td>
                <td>
                    <a href="print_receipt.php?id=<?= $row['id'] ?>" target="_blank" style="color:#337ab7;">
                        <i class="fa fa-print"></i> Receipt
                    </a>
                </td>
            </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</div>

<script src="script.js"></script>

</body>
</html>