<?php
include '../db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $date = $_POST['expense_date'];
    $cat  = $_POST['category'];
    $amt  = $_POST['amount'];
    $desc = $_POST['description'];

    $stmt = $conn->prepare("INSERT INTO expenses (category, amount, description, expense_date) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("sdss", $cat, $amt, $desc, $date);

    if ($stmt->execute()) {
        header("Location: expenses.php?status=success");
    } else {
        echo "Error: " . $conn->error;
    }
}
?>