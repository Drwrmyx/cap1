<?php
include '../auth.php'; // Protect the page
include '../db.php';

// Fetch expenses for the current month
$current_month = date('Y-m');
$query = "SELECT * FROM expenses WHERE expense_date LIKE '$current_month%' ORDER BY expense_date DESC";
$result = $conn->query($query);

// Calculate total expenses for the month
$total_query = $conn->query("SELECT SUM(amount) as total FROM expenses WHERE expense_date LIKE '$current_month%'");
$month_total = $total_query->fetch_assoc()['total'] ?? 0;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Expense Management</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="../Transactions/style.css">
    <style>
        .expense-form { background: white; padding: 20px; border-radius: 8px; margin-bottom: 20px; box-shadow: 0 2px 5px rgba(0,0,0,0.1); }
        .stat-box { background: #e74c3c; color: white; padding: 15px; border-radius: 8px; margin-bottom: 20px; }
    </style>
</head>
<body>

<nav class="navbar">
    <ul class="navbar-links">
        <li><a href="../Dashboard/dashboard.php"><i class="fa fa-tachometer-alt"></i> Dashboard</a></li>
        <li><a href="../Transactions/transaction.php"><i class="fa fa-exchange-alt"></i> Sales</a></li>
        <li><a href="expenses.php" class="active"><i class="fa fa-wallet"></i> Expenses</a></li>
    </ul>
</nav>

<div class="table-area">
    <div class="stat-box">
        <h3>Monthly Expenses (<?= date('F Y') ?>)</h3>
        <p style="font-size: 24px; font-weight: bold;">₱<?= number_format($month_total, 2) ?></p>
    </div>

    <div class="expense-form">
        <h4><i class="fa fa-plus-circle"></i> Log New Expense</h4>
        <form action="process_expense.php" method="POST" style="display: grid; grid-template-columns: 1fr 1fr 1fr 2fr 100px; gap: 10px; align-items: end;">
            <div><label>Date</label><input type="date" name="expense_date" value="<?= date('Y-m-d') ?>" required></div>
            <div>
                <label>Category</label>
                <select name="category" required>
                    <option value="Payroll">Payroll</option>
                    <option value="Fuel">Fuel</option>
                    <option value="Gate Fee">Gate Fee</option>
                    <option value="Utilities">Utilities</option>
                    <option value="Other">Other</option>
                </select>
            </div>
            <div><label>Amount</label><input type="number" step="0.01" name="amount" required></div>
            <div><label>Description</label><input type="text" name="description" placeholder="e.g. Petron Fuel for Delivery"></div>
            <button type="submit" class="btn btn-blue">Save</button>
        </form>
    </div>

    <div class="table-header">Expense Logs</div>
    <table>
        <thead>
            <tr>
                <th>Date</th>
                <th>Category</th>
                <th>Description</th>
                <th>Amount</th>
            </tr>
        </thead>
        <tbody>
            <?php while($row = $result->fetch_assoc()): ?>
            <tr>
                <td><?= $row['expense_date'] ?></td>
                <td><span class="badge" style="background:#eee; color:#333; padding:2px 8px; border-radius:4px;"><?= $row['category'] ?></span></td>
                <td><?= htmlspecialchars($row['description']) ?></td>
                <td style="color:#e74c3c; font-weight:bold;">₱<?= number_format($row['amount'], 2) ?></td>
            </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</div>

</body>
</html>