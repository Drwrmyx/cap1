<?php
include '../db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // 1. Collect and Clean the Data
    $store_name = $conn->real_escape_string($_POST['store_name']);
    $owner_name = $conn->real_escape_string($_POST['owner_name']);
    
    // NOTE: This matches name="contact" from your form
    $contact    = $conn->real_escape_string($_POST['contact']); 
    
    $address    = $conn->real_escape_string($_POST['address']);
    $route      = $conn->real_escape_string($_POST['route']);

    // 2. Prepared Statement to prevent SQL injection
    $stmt = $conn->prepare("INSERT INTO stores (store_name, owner_name, contact_number, address, route) VALUES (?, ?, ?, ?, ?)");
    
    // "sssss" means we are passing 5 Strings
    $stmt->bind_param("sssss", $store_name, $owner_name, $contact, $address, $route);

    if ($stmt->execute()) {
        // Redirect back to the stores list with a success message
        header("Location: stores.php?msg=StoreRegistered");
        exit();
    } else {
        // If it fails, show the specific error
        die("Registration Error: " . $conn->error);
    }
} else {
    // If someone tries to access this file directly, send them back
    header("Location: stores.php");
    exit();
}
?>