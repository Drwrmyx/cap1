<?php
include '../auth.php';
include '../db.php';

// Search and Filter
$search = isset($_GET['search']) ? $conn->real_escape_string($_GET['search']) : '';
$route_filter = isset($_GET['route']) ? $conn->real_escape_string($_GET['route']) : '';

$where = "WHERE 1=1";
if($search) $where .= " AND (store_name LIKE '%$search%' OR owner_name LIKE '%$search%')";
if($route_filter) $where .= " AND route = '$route_filter'";

$stores = $conn->query("SELECT * FROM stores $where ORDER BY store_name ASC");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Store Database (CRM)</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="../Transactions/style.css">
</head>
<body>

<nav class="navbar">
    <ul class="navbar-links">
        <li><a href="../Dashboard/dashboard.php"><i class="fa fa-tachometer-alt"></i> Dashboard</a></li>
        <li><a href="stores.php" class="active"><i class="fa fa-store"></i> Stores</a></li>
        <li><a href="../Transactions/transaction.php"><i class="fa fa-exchange-alt"></i> Transactions</a></li>
    </ul>
</nav>

<div class="table-area">
    <div class="table-header">
        <i class="fa fa-plus-circle"></i> Add New Store
    </div>
    <form action="process_store.php" method="POST" style="padding: 20px; display: grid; grid-template-columns: repeat(3, 1fr); gap: 15px; background: #fff;">
        <div><label>Store Name</label><input type="text" name="store_name" required></div>
        <div><label>Owner Name</label><input type="text" name="owner_name"></div>
        <div><label>Contact #</label><input type="text" name="contact"></div>
        <div style="grid-column: span 2;"><label>Full Address</label><input type="text" name="address"></div>
        <div>
            <label>Route</label>
            <select name="route">
                <option value="">Select Route</option>
                <?php for($i=1; $i<=7; $i++) echo "<option value='Route $i'>Route $i</option>"; ?>
            </select>
        </div>
        <div style="grid-column: span 3; text-align: right;">
            <button type="submit" class="btn btn-blue">Register Store</button>
        </div>
    </form>

    <div class="filter-row" style="margin-top: 20px;">
        <form method="GET" style="display: flex; gap: 10px; width: 100%;">
            <input type="text" name="search" placeholder="Search Store or Owner..." value="<?= $search ?>" style="flex: 2;">
            <select name="route" style="flex: 1;">
                <option value="">All Routes</option>
                <?php for($i=1; $i<=7; $i++): ?>
                    <option value="Route <?= $i ?>" <?= $route_filter == "Route $i" ? 'selected' : '' ?>>Route <?= $i ?></option>
                <?php endfor; ?>
            </select>
            <button type="submit" class="btn btn-blue">Filter</button>
        </form>
    </div>

    <table>
        <thead>
            <tr>
                <th>Store Name</th>
                <th>Owner</th>
                <th>Route</th>
                <th>Contact</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody>
            <?php while($s = $stores->fetch_assoc()): ?>
            <tr>
                <td><strong><?= htmlspecialchars($s['store_name']) ?></strong></td>
                <td><?= htmlspecialchars($s['owner_name']) ?></td>
                <td><span class="badge" style="background: #3498db; color: white; padding: 2px 8px; border-radius: 4px;"><?= $s['route'] ?></span></td>
                <td><?= $s['contact_number'] ?></td>
                <td>
                    <span style="color: <?= $s['status'] == 'Active' ? '#27ae60' : '#e74c3c' ?>; font-weight: bold;">
                        <?= $s['status'] ?>
                    </span>
                </td>
            </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</div>

</body>
</html>