<?php 
include '../db.php'; 
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Trash Bin - Inventory System</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>

    <div class="sidebar">
        <h2 style="color: white; text-align: center; margin-top: 20px;">Menu</h2>
        <a href="products.php" style="color: white; text-decoration: none; display: block; padding: 10px; margin-bottom: 5px;">
            <i class="fa fa-box"></i> Inventory
        </a>
        <a href="logs.php" style="color: white; text-decoration: none; display: block; padding: 10px; margin-bottom: 5px;">
            <i class="fa fa-history"></i> Activity Logs
        </a>
        <a href="trash.php" style="color: white; text-decoration: none; display: block; padding: 10px; background-color: #c0392b; border-radius: 4px;">
            <i class="fa fa-trash"></i> Trash Bin
        </a>
    </div>

    <div class="main-content" style="padding: 20px;">
        
        <?php if (isset($_SESSION['alert_message'])): ?>
            <div id="sys-alert" class="alert alert-<?php echo $_SESSION['alert_type']; ?>" 
                 style="padding: 15px; margin-bottom: 20px; border-radius: 4px; text-align: center; 
                 <?php echo ($_SESSION['alert_type'] === 'error') ? 'background-color: #f8d7da; color: #721c24;' : 'background-color: #d4edda; color: #155724;'; ?>">
                <?php echo $_SESSION['alert_message']; ?>
            </div>
            <?php 
            unset($_SESSION['alert_message']); 
            unset($_SESSION['alert_type']);
            ?>
        <?php endif; ?>

        <div class="header" style="margin-bottom: 20px; border-bottom: 2px solid #eee; padding-bottom: 10px;">
            <h1><i class="fa fa-trash" style="color: #c0392b;"></i> Trash Bin (Deleted Items)</h1>
            <p style="color: #666;">These items are hidden from the main inventory. You can restore them here.</p>
        </div>

        <div class="table-container" style="background: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 5px rgba(0,0,0,0.05);">
            <table style="width: 100%; border-collapse: collapse; text-align: left;">
                <thead>
                    <tr style="background-color: #f8f9fa; border-bottom: 2px solid #ddd;">
                        <th style="padding: 12px;">Item Code</th>
                        <th style="padding: 12px;">Name</th>
                        <th style="padding: 12px;">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    // Query ONLY items where is_deleted = 1
                    $query = "SELECT * FROM products WHERE is_deleted = 1 ORDER BY name ASC";
                    $res = $conn->query($query);

                    if ($res && $res->num_rows > 0) {
                        while ($row = $res->fetch_assoc()) {
                            echo "<tr style='border-bottom: 1px solid #eee;'>
                                    <td style='padding: 12px; font-weight: bold;'>" . htmlspecialchars($row['item_code']) . "</td>
                                    <td style='padding: 12px;'>" . htmlspecialchars($row['name']) . "</td>
                                    <td style='padding: 12px;'>
                                        <a href='process_restore.php?id=" . $row['id'] . "' class='btn-blue' style='text-decoration: none; padding: 6px 12px; border-radius: 4px; color: white; background-color: #28a745;' onclick=\"return confirm('Are you sure you want to restore this item?');\">
                                            <i class='fa fa-undo'></i> Restore
                                        </a>
                                    </td>
                                  </tr>";
                        }
                    } else {
                        echo "<tr><td colspan='3' style='text-align: center; padding: 20px; color: #888;'>The trash bin is empty.</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
    
    <script src="script.js"></script>
</body>
</html>