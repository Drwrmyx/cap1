<?php
include '../db.php';
include 'functions.php';

// session_start(); // Only uncomment if it's NOT already in your db.php

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = (int)$_POST['id'];
    $max_stock = (int)$_POST['max_stock']; // Add this line
    $name = trim($_POST['name']);
    $code = trim($_POST['item_code']);
    $price = (float)$_POST['price'];
    $desc = trim($_POST['description']);

    // 1. GUARD: Check if price is negative
    if ($price < 0) {
        $_SESSION['alert_message'] = "Error: Price cannot be a negative value.";
        $_SESSION['alert_type'] = "error";
        header("Location: products.php");
        exit();
    }

    $image_path = null;
    $upload_success = false;

    // 2. HANDLE IMAGE UPDATE
    if (isset($_FILES['product_image']) && $_FILES['product_image']['error'] === UPLOAD_ERR_OK) {
        
        $allowed_exts = ['jpg', 'jpeg', 'png', 'webp', 'gif', 'avif'];
        $file_tmp = $_FILES['product_image']['tmp_name'];
        $file_name = $_FILES['product_image']['name'];
        $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));

        if (in_array($file_ext, $allowed_exts)) {
            // Create unique name
            $new_file_name = uniqid('img_', true) . '.' . $file_ext;
            $dest_path = 'uploads/' . $new_file_name;

            if (move_uploaded_file($file_tmp, $dest_path)) {
                $image_path = $dest_path;
                $upload_success = true;

                // CLEANUP: Fetch and delete the old image file from the server
                $old_img_query = $conn->prepare("SELECT image_path FROM products WHERE id = ?");
                $old_img_query->bind_param("i", $id);
                $old_img_query->execute();
                $old_img_query->bind_result($old_path);
                $old_img_query->fetch();
                $old_img_query->close();

                if (!empty($old_path) && file_exists($old_path)) {
                    unlink($old_path); // Physically deletes the old file
                }
            }
        }
    }

    // 3. SECURE UPDATE (Conditional SQL)
    // Update the SQL queries to include max_stock
    if ($upload_success) {
        $stmt = $conn->prepare("UPDATE products SET name=?, item_code=?, price=?, max_stock=?, description=?, image_path=? WHERE id=?");
        $stmt->bind_param("ssdisii", $name, $code, $price, $max_stock, $desc, $image_path, $id);
    } else {
        $stmt = $conn->prepare("UPDATE products SET name=?, item_code=?, price=?, max_stock=?, description=? WHERE id=?");
        $stmt->bind_param("ssdisi", $name, $code, $price, $max_stock, $desc, $id);
    }

    if ($stmt->execute()) {
        // 4. LOGGING LOGIC
        log_activity($conn, $id, $code, 'Item Edited', "Updated details for item: $name.");

        $_SESSION['alert_message'] = "Item details updated!";
        $_SESSION['alert_type'] = "success"; 
        header("Location: products.php");
        exit();
    } else {
        $_SESSION['alert_message'] = "Database Error: " . $stmt->error;
        $_SESSION['alert_type'] = "error";
        header("Location: products.php");
        exit();
    }
}
?>