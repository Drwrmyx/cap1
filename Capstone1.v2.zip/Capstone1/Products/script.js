/**
 * Opens the Stock Update Modal and populates it with existing product data.
 */
function openUpdateModal(data) {
    document.getElementById('up_id').value = data.id;
    document.getElementById('up_name').value = data.name;
    document.getElementById('up_code').value = data.item_code;
    document.getElementById('up_stock').value = data.stock;
    document.getElementById('updateModal').style.display = "block";
}

/**
 * Opens the Edit Item Modal and populates it with existing product data.
 */
function openEditModal(data) {
    document.getElementById('edit_id').value = data.id;
    document.getElementById('edit_name').value = data.name;
    document.getElementById('edit_code').value = data.item_code;
    document.getElementById('edit_price').value = data.price;
    document.getElementById('edit_max_stock').value = data.max_stock; 
    document.getElementById('edit_desc').value = data.description;
    document.getElementById('editModal').style.display = "block";
}

/**
 * Closes all active modals.
 */
function closeModals() {
    document.getElementById('updateModal').style.display = "none";
    document.getElementById('editModal').style.display = "none";
}

/**
 * Closes the modal if the user clicks anywhere outside of the modal content box.
 */
window.onclick = function(e) { 
    if(e.target.className === 'modal') { 
        closeModals();
    } 
}

// Add this to your script.js to catch errors before submission
document.addEventListener('input', function (e) {
    if (e.target.name === 'price' || e.target.name === 'new_qty') {
        if (e.target.value < 0) {
            e.target.style.borderColor = "red";
            // Optional: alert("Value cannot be negative");
        } else {
            e.target.style.borderColor = "#ccc";
        }
    }
});


document.addEventListener("DOMContentLoaded", function() {
    
    // 1. Validate the Add Item Form
    const addForm = document.querySelector('.sidebar form');
    if (addForm) {
        addForm.addEventListener('submit', function(e) {
            const stock = parseFloat(addForm.querySelector('input[name="stock"]').value);
            const price = parseFloat(addForm.querySelector('input[name="price"]').value);
            
            if (stock < 0 || price < 0) {
                e.preventDefault(); // This stops the form from submitting!
                alert("Please ensure stock and price are not negative values.");
            }
        });
    }

    // 2. Validate the Edit Modal Form
    const editForm = document.querySelector('#editModal form');
    if (editForm) {
        editForm.addEventListener('submit', function(e) {
            const price = parseFloat(document.getElementById('edit_price').value);
            
            if (price < 0) {
                e.preventDefault();
                alert("Price cannot be negative.");
                document.getElementById('edit_price').style.borderColor = 'red';
            }
        });
    }

    // 3. Validate the Update Stock Modal Form
    const updateForm = document.querySelector('#updateModal form');
    if (updateForm) {
        updateForm.addEventListener('submit', function(e) {
            const qty = parseFloat(document.getElementById('update_qty').value);
            
            if (qty <= 0 || isNaN(qty)) {
                e.preventDefault();
                alert("Please enter a valid quantity greater than zero.");
                document.getElementById('update_qty').style.borderColor = 'red';
            }
        });
    }
});

// Auto-hide system alerts after 3 seconds
document.addEventListener("DOMContentLoaded", function() {
    const alertBox = document.getElementById('sys-alert');
    if (alertBox) {
        setTimeout(function() {
            alertBox.style.opacity = '0';
            setTimeout(function() {
                alertBox.style.display = 'none';
            }, 500); // Wait for the fade-out transition to finish
        }, 3000); // 3000 milliseconds = 3 seconds
    }
});