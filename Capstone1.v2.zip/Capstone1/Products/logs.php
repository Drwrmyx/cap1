<?php 
include '../db.php'; 
include 'functions.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Activity Logs - Inventory System</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>

    <div class="sidebar">
        <h2 style="color: white; text-align: center; margin-top: 20px;">Menu</h2>
        <a href="products.php" style="color: white; text-decoration: none; display: block; padding: 10px; margin-bottom: 5px;">
            <i class="fa fa-box"></i> Inventory
        </a>
        <a href="logs.php" style="color: white; text-decoration: none; display: block; padding: 10px; background-color: #34495e; border-radius: 4px;">
            <i class="fa fa-history"></i> Activity Logs
        </a>
        <a href="trash.php" style="color: white; text-decoration: none; display: block; padding: 10px; margin-bottom: 5px;">
            <i class="fa fa-trash"></i> Trash Bin
        </a>
    </div>

    <div class="main-content" style="padding: 20px;">
        <div class="header" style="margin-bottom: 20px; border-bottom: 2px solid #eee; padding-bottom: 10px;">
            <h2>System Activity Logs</h2>
            <p style="color: #666; font-size: 0.9em;">A chronological record of all inventory changes.</p>
        </div>

        <div class="table-container" style="background: white; padding: 15px; border-radius: 8px; box-shadow: 0 2px 5px rgba(0,0,0,0.1);">
            <table class="log-table" style="width: 100%; border-collapse: collapse;">
                <thead>
                    <tr style="text-align: left; border-bottom: 2px solid #ddd;">
                        <th style="padding: 12px;">Date & Time</th>
                        <th style="padding: 12px;">Item Code</th>
                        <th style="padding: 12px;">Action</th>
                        <th style="padding: 12px;">Description</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    // Fetch logs from the database, newest first. Limit to 200 so the page doesn't lag over time.
                    $query = "SELECT * FROM product_logs ORDER BY created_at DESC LIMIT 200";
                    $result = $conn->query($query);

                    if ($result->num_rows > 0) {
                        while ($row = $result->fetch_assoc()) {
                            
                            // 1. Format the Date (e.g., "Oct 24, 2023, 2:30 pm")
                            $date = date("M j, Y, g:i a", strtotime($row['created_at']));
                            
                            // 2. Determine Badge Color based on Action Type
                            $badge_class = 'badge-stock'; // Default
                            if (strpos($row['action_type'], 'Created') !== false) {
                                $badge_class = 'badge-create';
                            } elseif (strpos($row['action_type'], 'Edited') !== false) {
                                $badge_class = 'badge-edit';
                            } elseif (strpos($row['action_type'], 'Deleted') !== false) {
                                $badge_class = 'badge-delete';
                            }

                            // 3. Render the Row
                            echo "<tr style='border-bottom: 1px solid #eee;'>
                                    <td style='padding: 12px; font-size: 0.9em; color: #777;'>{$date}</td>
                                    <td style='padding: 12px; font-weight: bold;'>" . htmlspecialchars($row['item_code']) . "</td>
                                    <td style='padding: 12px;'>
                                        <span class='badge {$badge_class}'>{$row['action_type']}</span>
                                    </td>
                                    <td style='padding: 12px;' class='log-desc'>" . htmlspecialchars($row['description']) . "</td>
                                  </tr>";
                        }
                    } else {
                        echo "<tr><td colspan='4' style='text-align: center; padding: 20px; color: #888;'>No activity logs found. Try adding or editing an item!</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>

</body>
</html>